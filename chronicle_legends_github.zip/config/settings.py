"""
config/settings.py — Chronicle Legends MMORPG Bot
Centralized configuration. All values loaded from environment / .env file.
Import anywhere: from config.settings import settings
"""

from __future__ import annotations
import os
import ssl
from dataclasses import dataclass, field
from dotenv import load_dotenv

# Load .env from project root (one level up from config/)
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env'))


@dataclass(frozen=True)
class Settings:
    # ── Telegram ─────────────────────────────────
    bot_token: str = os.getenv("BOT_TOKEN", "")
    announce_chat_ids: list = field(
        default_factory=lambda: [
            int(x) for x in os.getenv("ANNOUNCE_CHAT_IDS", "").split(",") if x.strip()
        ]
    )

    # ── Database ─────────────────────────────────
    database_url: str = os.getenv(
        "DATABASE_URL",
        "postgresql://chronicle_user:password@localhost:5432/chronicle_legends"
    )
    db_pool_min: int = int(os.getenv("DB_POOL_MIN", "2"))
    db_pool_max: int = int(os.getenv("DB_POOL_MAX", "10"))
    # "require" for Supabase/any cloud DB, "disable" for local dev
    db_ssl_mode: str = os.getenv("DB_SSL_MODE", "require")

    # ── Admin ────────────────────────────────────
    superadmin_ids: list = field(
        default_factory=lambda: [
            int(x) for x in os.getenv("SUPERADMIN_IDS", "").split(",") if x.strip()
        ]
    )

    # ── Economy ──────────────────────────────────
    market_tax_rate: float      = float(os.getenv("MARKET_TAX_RATE", "0.05"))
    death_penalty_rate: float   = float(os.getenv("DEATH_PENALTY_RATE", "0.10"))
    black_market_rate: float    = float(os.getenv("BLACK_MARKET_VALUE_RATE", "0.40"))
    merchant_value_rate: float  = float(os.getenv("MERCHANT_VALUE_RATE", "0.55"))

    # ── Boss Raids ───────────────────────────────
    raid_expiry_hours: int      = int(os.getenv("RAID_EXPIRY_HOURS", "24"))
    boss_scheduler_mins: int    = int(os.getenv("BOSS_SCHEDULER_INTERVAL_MINUTES", "5"))

    # ── Gameplay ─────────────────────────────────
    max_inventory_slots: int    = int(os.getenv("MAX_INVENTORY_SLOTS", "50"))
    guild_create_cost_gold: int = int(os.getenv("GUILD_CREATE_COST_GOLD", "50"))
    black_market_min_level: int = int(os.getenv("BLACK_MARKET_MIN_LEVEL", "10"))

    def validate(self):
        """Call at startup. Raises ValueError if critical config is missing."""
        if not self.bot_token:
            raise ValueError(
                "❌ BOT_TOKEN is not set!\n"
                "   → Get one from @BotFather on Telegram\n"
                "   → Add it to your .env file"
            )
        if "YOUR-PASSWORD" in self.database_url or "xxxxxxxxxxxx" in self.database_url:
            raise ValueError(
                "❌ DATABASE_URL still has placeholder values!\n"
                "   → Go to supabase.com → your project → Settings → Database\n"
                "   → Copy the connection string and paste it in .env"
            )
        if not self.superadmin_ids:
            print(
                "⚠️  WARNING: No SUPERADMIN_IDS set.\n"
                "   You won't have admin access in-game!\n"
                "   → Add your Telegram user ID to SUPERADMIN_IDS in .env\n"
                "   → Get your ID by messaging @userinfobot on Telegram"
            )
        return self

    def build_ssl_context(self):
        """
        Returns an SSL context for asyncpg.
        Supabase requires SSL — this handles it automatically.
        Local dev: set DB_SSL_MODE=disable in .env to skip.
        """
        if self.db_ssl_mode == "disable":
            return None
        ctx = ssl.create_default_context()
        if self.db_ssl_mode == "require":
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        return ctx

    @property
    def is_supabase(self) -> bool:
        return "supabase.co" in self.database_url


# Singleton — import this everywhere
settings = Settings().validate()

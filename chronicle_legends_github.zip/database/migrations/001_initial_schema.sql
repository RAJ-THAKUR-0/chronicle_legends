-- ============================================================
-- CHRONICLE LEGENDS — Telegram MMORPG Bot
-- PostgreSQL Schema v1.0
-- Designed for migration-readiness and high-concurrency play
-- All currency stored in COPPER (BIGINT) to avoid float errors
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUMERATIONS
-- ============================================================

CREATE TYPE race_type AS ENUM (
    'human', 'elf', 'orc', 'dwarf', 'halfling', 'dragonborn', 'undead', 'fae'
);

CREATE TYPE rarity_type AS ENUM (
    'common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic', 'ancient'
);

CREATE TYPE item_slot AS ENUM (
    'head', 'chest', 'legs', 'feet', 'hands', 'mainhand',
    'offhand', 'ring', 'amulet', 'consumable', 'material', 'quest', 'none'
);

CREATE TYPE item_category AS ENUM (
    'weapon', 'armor', 'accessory', 'consumable', 'material', 'recipe', 'quest_item', 'currency_token'
);

CREATE TYPE transaction_type AS ENUM (
    'loot', 'purchase', 'sale', 'trade', 'admin_grant', 'death_penalty',
    'guild_deposit', 'guild_withdraw', 'bank_deposit', 'bank_withdraw',
    'crafting_cost', 'raid_reward', 'tax'
);

CREATE TYPE guild_rank AS ENUM (
    'recruit', 'member', 'veteran', 'officer', 'co_leader', 'leader'
);

CREATE TYPE ban_status AS ENUM (
    'active', 'banned', 'suspended', 'deleted'
);

CREATE TYPE boss_status AS ENUM (
    'spawning', 'active', 'defeated', 'expired'
);

CREATE TYPE market_status AS ENUM (
    'active', 'sold', 'cancelled', 'expired'
);

CREATE TYPE crafting_status AS ENUM (
    'pending', 'in_progress', 'success', 'failed', 'cancelled'
);

-- ============================================================
-- CORE: ITEM DEFINITIONS (Master Catalog)
-- ============================================================

CREATE TABLE item_definitions (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    description     TEXT,
    category        item_category NOT NULL DEFAULT 'material',
    slot            item_slot NOT NULL DEFAULT 'none',
    rarity          rarity_type NOT NULL DEFAULT 'common',
    weight          NUMERIC(6,2) NOT NULL DEFAULT 0.0,     -- kg
    base_value      BIGINT NOT NULL DEFAULT 0,             -- in Copper
    is_tradeable    BOOLEAN NOT NULL DEFAULT TRUE,
    is_bankable     BOOLEAN NOT NULL DEFAULT TRUE,
    is_stackable    BOOLEAN NOT NULL DEFAULT FALSE,
    max_stack       INT NOT NULL DEFAULT 1,
    icon_emoji      VARCHAR(10) DEFAULT '📦',

    -- Stat bonuses as JSONB (extensible without migrations)
    -- e.g. {"str": 5, "dex": 3, "max_hp": 50}
    stat_bonuses    JSONB NOT NULL DEFAULT '{}',

    -- Required level to equip/use
    req_level       INT NOT NULL DEFAULT 1,
    req_race        race_type,   -- NULL means any race

    -- Future-proofing: skills, mounts, pets can add columns here via JSONB
    extra_data      JSONB NOT NULL DEFAULT '{}',

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE item_definitions IS 'Master catalog of all items in the game. Never stores player instances — use inventory_items for that.';
COMMENT ON COLUMN item_definitions.stat_bonuses IS 'JSONB for extensibility. Add new stat types without schema migrations.';

-- ============================================================
-- CORE: USERS
-- ============================================================

CREATE TABLE users (
    id              BIGINT PRIMARY KEY,          -- Telegram user_id (stable, unique)
    username        VARCHAR(64),                 -- @handle (can change)
    display_name    VARCHAR(100) NOT NULL,

    -- Account state
    status          ban_status NOT NULL DEFAULT 'active',
    is_admin        BOOLEAN NOT NULL DEFAULT FALSE,
    is_superadmin   BOOLEAN NOT NULL DEFAULT FALSE,

    -- Character identity
    race            race_type NOT NULL DEFAULT 'human',
    level           INT NOT NULL DEFAULT 1,
    experience      BIGINT NOT NULL DEFAULT 0,
    experience_next BIGINT NOT NULL DEFAULT 100,  -- XP needed for next level

    -- Base stats (race modifiers applied on top via application layer)
    stat_str        INT NOT NULL DEFAULT 10,
    stat_dex        INT NOT NULL DEFAULT 10,
    stat_int        INT NOT NULL DEFAULT 10,
    stat_vit        INT NOT NULL DEFAULT 10,
    stat_wis        INT NOT NULL DEFAULT 10,
    stat_luk        INT NOT NULL DEFAULT 10,
    stat_points     INT NOT NULL DEFAULT 0,       -- Unspent stat points

    -- Combat state
    hp_current      INT NOT NULL DEFAULT 100,
    hp_max          INT NOT NULL DEFAULT 100,
    mp_current      INT NOT NULL DEFAULT 50,
    mp_max          INT NOT NULL DEFAULT 50,

    -- Economy — ALL values in COPPER (BIGINT)
    wallet_copper   BIGINT NOT NULL DEFAULT 0 CHECK (wallet_copper >= 0),
    bank_copper     BIGINT NOT NULL DEFAULT 0 CHECK (bank_copper >= 0),

    -- Social
    guild_id        INT,                         -- FK added below
    deaths          INT NOT NULL DEFAULT 0,
    kills           INT NOT NULL DEFAULT 0,
    quests_done     INT NOT NULL DEFAULT 0,

    -- Location / state (extensible JSONB)
    current_zone    VARCHAR(100) NOT NULL DEFAULT 'town_square',
    player_state    JSONB NOT NULL DEFAULT '{}', -- e.g. {"in_combat": false, "dungeon_id": null}

    -- Future hooks: skills, mounts, pets reference this PK
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_active     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON COLUMN users.wallet_copper IS 'Currency at risk — lost on death penalty. Stored in copper (BIGINT).';
COMMENT ON COLUMN users.bank_copper IS 'Safe currency. Never lost on death.';

-- ============================================================
-- GUILDS
-- ============================================================

CREATE TABLE guilds (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(60) NOT NULL UNIQUE,
    tag             VARCHAR(6) NOT NULL UNIQUE,   -- [TAG] shown in chat
    description     TEXT,
    leader_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,

    level           INT NOT NULL DEFAULT 1,
    experience      BIGINT NOT NULL DEFAULT 0,

    -- Guild Vault (safe — survives death)
    vault_copper    BIGINT NOT NULL DEFAULT 0 CHECK (vault_copper >= 0),

    -- Perk flags (unlocked by guild level)
    perks           JSONB NOT NULL DEFAULT '{}',
    -- e.g. {"xp_boost": 0.05, "discount_market": 0.02, "vault_capacity": 1000000}

    max_members     INT NOT NULL DEFAULT 30,
    is_recruiting   BOOLEAN NOT NULL DEFAULT TRUE,
    join_message    TEXT,

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Guild membership (separate to allow historical tracking)
CREATE TABLE guild_members (
    guild_id        INT NOT NULL REFERENCES guilds(id) ON DELETE CASCADE,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    rank            guild_rank NOT NULL DEFAULT 'recruit',
    contribution    BIGINT NOT NULL DEFAULT 0,   -- Total copper contributed historically
    joined_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (guild_id, user_id)
);

-- Add FK after both tables exist
ALTER TABLE users ADD CONSTRAINT fk_users_guild
    FOREIGN KEY (guild_id) REFERENCES guilds(id) ON DELETE SET NULL;

-- ============================================================
-- INVENTORY
-- ============================================================

CREATE TABLE inventory_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id        BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_def_id     INT NOT NULL REFERENCES item_definitions(id),

    quantity        INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    is_equipped     BOOLEAN NOT NULL DEFAULT FALSE,
    is_locked       BOOLEAN NOT NULL DEFAULT FALSE,  -- User-locked to prevent accidental sale

    -- Per-instance overrides (for enchanted/crafted items)
    custom_name     VARCHAR(100),
    custom_stats    JSONB NOT NULL DEFAULT '{}',     -- Bonus on top of item_def stats
    durability      INT NOT NULL DEFAULT 100 CHECK (durability BETWEEN 0 AND 100),

    -- Storage location
    stored_in_bank  BOOLEAN NOT NULL DEFAULT FALSE,
    guild_vault_id  INT REFERENCES guilds(id) ON DELETE SET NULL,

    obtained_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE inventory_items IS 'Per-player item instances. Each row is a unique item in someone''s possession.';

-- ============================================================
-- ECONOMY: TRANSACTION LEDGER
-- ============================================================

CREATE TABLE transactions (
    id              BIGSERIAL PRIMARY KEY,
    tx_type         transaction_type NOT NULL,

    -- Parties (nullable — system transactions may lack one)
    from_user_id    BIGINT REFERENCES users(id) ON DELETE SET NULL,
    to_user_id      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    guild_id        INT REFERENCES guilds(id) ON DELETE SET NULL,

    amount_copper   BIGINT NOT NULL DEFAULT 0,   -- Always positive; direction = from/to
    description     TEXT,
    reference_id    VARCHAR(100),                -- e.g. "market_listing:42", "boss:7"

    -- Snapshot balances for auditing
    from_balance_after  BIGINT,
    to_balance_after    BIGINT,

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE transactions IS 'Immutable ledger. Never UPDATE or DELETE rows — append only.';

-- ============================================================
-- MARKETPLACE
-- ============================================================

CREATE TABLE market_listings (
    id              SERIAL PRIMARY KEY,
    seller_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_instance_id UUID NOT NULL REFERENCES inventory_items(id) ON DELETE CASCADE,

    price_copper    BIGINT NOT NULL CHECK (price_copper > 0),
    quantity        INT NOT NULL DEFAULT 1 CHECK (quantity > 0),

    status          market_status NOT NULL DEFAULT 'active',
    buyer_id        BIGINT REFERENCES users(id) ON DELETE SET NULL,

    -- Tax info
    tax_rate        NUMERIC(4,3) NOT NULL DEFAULT 0.05,   -- 5% default
    tax_collected   BIGINT NOT NULL DEFAULT 0,

    listed_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
    sold_at         TIMESTAMPTZ
);

-- ============================================================
-- CRAFTING
-- ============================================================

CREATE TABLE crafting_recipes (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    result_item_id  INT NOT NULL REFERENCES item_definitions(id),
    result_quantity INT NOT NULL DEFAULT 1,

    -- Ingredients as JSONB array: [{"item_def_id": 5, "quantity": 2}, ...]
    ingredients     JSONB NOT NULL DEFAULT '[]',

    success_rate    NUMERIC(5,4) NOT NULL DEFAULT 1.0 CHECK (success_rate BETWEEN 0 AND 1),
    crafting_time_s INT NOT NULL DEFAULT 0,       -- Seconds to craft
    req_level       INT NOT NULL DEFAULT 1,
    copper_cost     BIGINT NOT NULL DEFAULT 0,

    is_discoverable BOOLEAN NOT NULL DEFAULT FALSE,  -- Hidden until found
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE crafting_queue (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    recipe_id       INT NOT NULL REFERENCES crafting_recipes(id),
    status          crafting_status NOT NULL DEFAULT 'pending',
    rng_roll        NUMERIC(5,4),                  -- Recorded for audit/replay
    started_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completes_at    TIMESTAMPTZ NOT NULL,
    completed_at    TIMESTAMPTZ,
    result_item_id  UUID REFERENCES inventory_items(id) ON DELETE SET NULL
);

-- ============================================================
-- BOSS RAIDS
-- ============================================================

CREATE TABLE boss_definitions (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    description     TEXT,
    icon_emoji      VARCHAR(10) DEFAULT '👹',
    zone            VARCHAR(100) NOT NULL,
    hp_base         BIGINT NOT NULL,
    level           INT NOT NULL DEFAULT 50,
    stat_block      JSONB NOT NULL DEFAULT '{}',
    loot_table      JSONB NOT NULL DEFAULT '[]',
    -- e.g. [{"item_def_id": 12, "chance": 0.05, "qty_min": 1, "qty_max": 1}]
    copper_reward_base BIGINT NOT NULL DEFAULT 0,
    spawn_interval_h INT NOT NULL DEFAULT 24,        -- Hours between spawns
    is_active        BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE boss_raids (
    id              SERIAL PRIMARY KEY,
    boss_def_id     INT NOT NULL REFERENCES boss_definitions(id),
    status          boss_status NOT NULL DEFAULT 'spawning',
    hp_current      BIGINT NOT NULL,
    hp_max          BIGINT NOT NULL,
    spawned_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ NOT NULL,
    defeated_at     TIMESTAMPTZ
);

CREATE TABLE raid_participants (
    raid_id         INT NOT NULL REFERENCES boss_raids(id) ON DELETE CASCADE,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    damage_dealt    BIGINT NOT NULL DEFAULT 0,
    hits            INT NOT NULL DEFAULT 0,
    last_hit_at     TIMESTAMPTZ,
    reward_copper   BIGINT NOT NULL DEFAULT 0,      -- Calculated on boss defeat
    rewarded_at     TIMESTAMPTZ,
    PRIMARY KEY (raid_id, user_id)
);

-- ============================================================
-- ADMIN: BAN LOG
-- ============================================================

CREATE TABLE ban_log (
    id              BIGSERIAL PRIMARY KEY,
    target_user_id  BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    admin_user_id   BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action          VARCHAR(20) NOT NULL,          -- 'ban', 'unban', 'suspend'
    reason          TEXT,
    expires_at      TIMESTAMPTZ,                   -- NULL = permanent
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- FUTURE HOOKS (skeleton tables — ready to populate)
-- ============================================================

-- Skills system: References users(id), no existing table changes needed
CREATE TABLE skill_definitions (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    skill_tree  VARCHAR(50),
    max_rank    INT NOT NULL DEFAULT 5,
    stat_data   JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE user_skills (
    user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    skill_id    INT NOT NULL REFERENCES skill_definitions(id),
    rank        INT NOT NULL DEFAULT 1,
    PRIMARY KEY (user_id, skill_id)
);

-- Mounts system
CREATE TABLE mount_definitions (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    speed_bonus NUMERIC(4,3) NOT NULL DEFAULT 0.0,
    stat_data   JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE user_mounts (
    user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mount_id    INT NOT NULL REFERENCES mount_definitions(id),
    is_active   BOOLEAN NOT NULL DEFAULT FALSE,
    obtained_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, mount_id)
);

-- Pets system
CREATE TABLE pet_definitions (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    passive     TEXT,
    stat_data   JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE user_pets (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    pet_id      INT NOT NULL REFERENCES pet_definitions(id),
    nickname    VARCHAR(60),
    level       INT NOT NULL DEFAULT 1,
    is_active   BOOLEAN NOT NULL DEFAULT FALSE,
    obtained_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- INDEXES (Performance)
-- ============================================================

-- Users
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_guild ON users(guild_id);
CREATE INDEX idx_users_level ON users(level DESC);
CREATE INDEX idx_users_last_active ON users(last_active DESC);

-- Inventory
CREATE INDEX idx_inventory_owner ON inventory_items(owner_id);
CREATE INDEX idx_inventory_item_def ON inventory_items(item_def_id);
CREATE INDEX idx_inventory_bank ON inventory_items(owner_id) WHERE stored_in_bank = TRUE;
CREATE INDEX idx_inventory_equipped ON inventory_items(owner_id) WHERE is_equipped = TRUE;

-- Transactions
CREATE INDEX idx_tx_from_user ON transactions(from_user_id, created_at DESC);
CREATE INDEX idx_tx_to_user ON transactions(to_user_id, created_at DESC);
CREATE INDEX idx_tx_type ON transactions(tx_type, created_at DESC);

-- Market
CREATE INDEX idx_market_active ON market_listings(status, expires_at) WHERE status = 'active';
CREATE INDEX idx_market_seller ON market_listings(seller_id);
CREATE INDEX idx_market_item ON market_listings(item_instance_id);

-- Boss raids
CREATE INDEX idx_raids_active ON boss_raids(status) WHERE status = 'active';
CREATE INDEX idx_raid_participants ON raid_participants(raid_id, damage_dealt DESC);

-- ============================================================
-- TRIGGERS: updated_at auto-maintenance
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_guilds_updated_at
    BEFORE UPDATE ON guilds
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_inventory_updated_at
    BEFORE UPDATE ON inventory_items
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- VIEWS: Leaderboard & Economy Dashboard
-- ============================================================

CREATE VIEW v_leaderboard AS
SELECT
    u.id,
    u.display_name,
    u.username,
    u.race,
    u.level,
    u.experience,
    g.name AS guild_name,
    g.tag  AS guild_tag,
    (u.wallet_copper + u.bank_copper) AS total_wealth_copper,
    u.kills,
    u.deaths,
    CASE WHEN u.deaths = 0 THEN u.kills ELSE (u.kills::FLOAT / u.deaths) END AS kd_ratio
FROM users u
LEFT JOIN guilds g ON u.guild_id = g.id
WHERE u.status = 'active'
ORDER BY u.level DESC, u.experience DESC;

CREATE VIEW v_economy_stats AS
SELECT
    SUM(wallet_copper)   AS total_in_wallets,
    SUM(bank_copper)     AS total_in_banks,
    SUM(wallet_copper + bank_copper) AS total_supply,
    COUNT(*)             AS active_players,
    AVG(wallet_copper + bank_copper) AS avg_wealth,
    MAX(wallet_copper + bank_copper) AS richest_player
FROM users
WHERE status = 'active';

CREATE VIEW v_market_volume AS
SELECT
    DATE_TRUNC('day', sold_at) AS day,
    COUNT(*) AS sales_count,
    SUM(price_copper * quantity) AS volume_copper,
    SUM(tax_collected) AS taxes_copper
FROM market_listings
WHERE status = 'sold'
GROUP BY 1
ORDER BY 1 DESC;

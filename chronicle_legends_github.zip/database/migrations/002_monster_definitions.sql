-- ============================================================
-- PATCH: monster_definitions table
-- Add this to schema.sql (or run as migration)
-- ============================================================

CREATE TABLE monster_definitions (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    description     TEXT,
    icon_emoji      VARCHAR(10) DEFAULT '👾',
    photo_file_id   TEXT,                        -- Telegram file_id (admin-uploaded photo)
    zone            VARCHAR(100) NOT NULL,
    level           INT NOT NULL DEFAULT 1,
    hp_max          BIGINT NOT NULL,
    atk             INT NOT NULL,
    def             INT NOT NULL DEFAULT 0,
    spd             INT NOT NULL DEFAULT 50,
    xp_reward       INT NOT NULL DEFAULT 10,
    copper_min      INT NOT NULL DEFAULT 0,
    copper_max      INT NOT NULL DEFAULT 0,
    magic_res       NUMERIC(4,3) NOT NULL DEFAULT 0.0,
    phys_res        NUMERIC(4,3) NOT NULL DEFAULT 0.0,
    is_boss         BOOLEAN NOT NULL DEFAULT FALSE,
    abilities       JSONB NOT NULL DEFAULT '[]',
    -- e.g. [{"name": "Fireball", "damage_mult": 1.8, "type": "fire", "cooldown": 3}]
    loot_table      JSONB NOT NULL DEFAULT '[]',
    -- e.g. [{"item_def_id": 5, "chance": 0.15, "qty_min": 1, "qty_max": 2}]
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_by      BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON COLUMN monster_definitions.photo_file_id IS
    'Telegram Bot API file_id. Obtained when admin sends a photo during /admin_create_monster flow.';

CREATE INDEX idx_monsters_zone   ON monster_definitions(zone) WHERE is_active = TRUE;
CREATE INDEX idx_monsters_level  ON monster_definitions(level) WHERE is_active = TRUE;
CREATE INDEX idx_monsters_boss   ON monster_definitions(is_boss) WHERE is_active = TRUE;

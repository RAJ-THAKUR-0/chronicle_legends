-- ============================================================
-- database/seeds/001_starter_data.sql
-- Chronicle Legends — Starter Game Data
-- Run AFTER all migrations to populate items, bosses, recipes
-- ============================================================

-- ── STARTER ITEMS ───────────────────────────────────────────

INSERT INTO item_definitions
  (name, description, category, slot, rarity, weight, base_value, is_stackable, max_stack, icon_emoji, stat_bonuses, req_level)
VALUES
  -- Weapons
  ('Rusty Sword',      'A worn blade, but it still cuts.',      'weapon', 'mainhand', 'common',   1.5,    500, FALSE, 1, '⚔️',  '{"str": 2}',              1),
  ('Iron Dagger',      'Quick and light. Favored by rogues.',   'weapon', 'mainhand', 'common',   0.8,    400, FALSE, 1, '🗡️',  '{"dex": 3}',              1),
  ('Oak Staff',        'Channels arcane energy efficiently.',   'weapon', 'mainhand', 'uncommon', 1.2,   1500, FALSE, 1, '🪄',  '{"int": 4, "wis": 2}',    3),
  ('Steel Longsword',  'Balanced and reliable.',                'weapon', 'mainhand', 'uncommon', 2.0,   3500, FALSE, 1, '⚔️',  '{"str": 5, "vit": 1}',    5),
  ('Elven Bow',        'Carved from silverwood. Never misses.', 'weapon', 'mainhand', 'rare',     1.0,  15000, FALSE, 1, '🏹',  '{"dex": 8, "luk": 3}',   10),
  ('Dragonbone Axe',   'Forged from a real dragon bone.',       'weapon', 'mainhand', 'epic',     3.5, 120000, FALSE, 1, '🪓',  '{"str": 15, "vit": 5}',  25),

  -- Armor
  ('Leather Vest',     'Basic protection. Better than nothing.','armor',  'chest',    'common',   2.0,    800, FALSE, 1, '🦺',  '{"vit": 2}',              1),
  ('Iron Chestplate',  'Heavy but reliable protection.',        'armor',  'chest',    'uncommon', 5.0,   4000, FALSE, 1, '🛡️',  '{"vit": 5, "str": 1}',    5),
  ('Silk Robe',        'Enhances magical concentration.',       'armor',  'chest',    'uncommon', 1.5,   3500, FALSE, 1, '👘',  '{"int": 4, "wis": 3}',    5),
  ('Chainmail',        'Flexible metal rings. Good balance.',   'armor',  'chest',    'rare',     4.0,  18000, FALSE, 1, '⛓️',  '{"vit": 8, "str": 3}',   12),

  -- Accessories
  ('Copper Ring',      'A simple ring. Small luck bonus.',      'accessory','ring',   'common',   0.1,    200, FALSE, 1, '💍',  '{"luk": 1}',              1),
  ('Amulet of Vitality','Pulses with life energy.',             'accessory','amulet', 'uncommon', 0.2,   5000, FALSE, 1, '📿',  '{"vit": 6, "hp_max": 30}',8),

  -- Consumables
  ('Health Potion',    'Restores 50 HP instantly.',             'consumable','consumable','common',0.1,  250, TRUE, 99, '🧪',  '{}',                      1),
  ('Mana Potion',      'Restores 40 MP instantly.',             'consumable','consumable','common',0.1,  200, TRUE, 99, '💙',  '{}',                      1),
  ('Elixir of Fury',   'Grants Berserk status for 3 turns.',    'consumable','consumable','rare',  0.1, 2500, TRUE, 10, '🔴',  '{}',                      10),

  -- Materials
  ('Iron Ore',         'Raw ore. Used in smithing.',            'material','none',    'common',   1.0,     50, TRUE, 999,'⛏️',  '{}',                      1),
  ('Magic Crystal',    'Pulsing with arcane energy.',           'material','none',    'uncommon', 0.2,   1000, TRUE, 99, '💎',  '{}',                      1),
  ('Dragon Scale',     'Fireproof. Incredibly rare.',           'material','none',    'epic',     0.5,  50000, TRUE, 10, '🐉',  '{}',                      1),
  ('Ancient Rune',     'Emanates a power beyond understanding.','material','none',    'ancient',  0.1, 500000, TRUE,  5, '🌟',  '{}',                      1),

  -- Special: Black Market access
  ('Fence''s Pass',    'Grants access to the Black Market.',    'quest', 'none',     'rare',     0.0,  10000, FALSE, 1, '🌑',  '{}',                      1);


-- ── STARTER BOSS DEFINITIONS ────────────────────────────────

INSERT INTO boss_definitions
  (name, description, icon_emoji, zone, hp_base, level, stat_block, loot_table, copper_reward_base, spawn_interval_h)
VALUES
  (
    'Forest Golem',
    'An ancient elemental awakened deep within the Verdant Forest. Its stone skin deflects all but the mightiest blows.',
    '🗿',
    'verdant_forest',
    50000,
    20,
    '{"atk": 120, "def": 80, "spd": 30, "phys_res": 0.15, "magic_res": 0.05}',
    '[{"item_def_id": 10, "chance": 0.20, "qty_min": 1, "qty_max": 1},
      {"item_def_id": 16, "chance": 0.50, "qty_min": 2, "qty_max": 5},
      {"item_def_id": 17, "chance": 0.15, "qty_min": 1, "qty_max": 2}]',
    500000,   -- 5g reward pool
    24
  ),
  (
    'Shadow Drake',
    'A young dragon corrupted by dark magic. Its breath turns adventurers to ash.',
    '🐲',
    'obsidian_peaks',
    150000,
    45,
    '{"atk": 280, "def": 150, "spd": 90, "phys_res": 0.10, "magic_res": 0.25}',
    '[{"item_def_id": 11, "chance": 0.15, "qty_min": 1, "qty_max": 1},
      {"item_def_id": 18, "chance": 0.30, "qty_min": 1, "qty_max": 3},
      {"item_def_id": 12, "chance": 0.08, "qty_min": 1, "qty_max": 1}]',
    2500000,  -- 25g reward pool
    48
  ),
  (
    'The Eternal King',
    'Once a great ruler, now an undying tyrant. He has conquered death itself — can you conquer him?',
    '👑',
    'shattered_throne',
    1000000,
    99,
    '{"atk": 600, "def": 300, "spd": 120, "phys_res": 0.20, "magic_res": 0.30}',
    '[{"item_def_id": 19, "chance": 0.10, "qty_min": 1, "qty_max": 1},
      {"item_def_id": 6,  "chance": 0.05, "qty_min": 1, "qty_max": 1},
      {"item_def_id": 15, "chance": 0.25, "qty_min": 1, "qty_max": 2}]',
    10000000, -- 100g reward pool
    72
  );


-- ── STARTER CRAFTING RECIPES ────────────────────────────────

INSERT INTO crafting_recipes
  (name, result_item_id, result_quantity, ingredients, success_rate, crafting_time_s, req_level, copper_cost)
VALUES
  (
    'Forge Iron Chestplate',
    (SELECT id FROM item_definitions WHERE name = 'Iron Chestplate'),
    1,
    '[{"item_def_id": (SELECT id FROM item_definitions WHERE name=''Iron Ore''), "quantity": 5}]',
    0.80, 30, 5, 1000
  ),
  (
    'Brew Health Potion',
    (SELECT id FROM item_definitions WHERE name = 'Health Potion'),
    3,
    '[{"item_def_id": (SELECT id FROM item_definitions WHERE name=''Magic Crystal''), "quantity": 1}]',
    0.90, 10, 1, 500
  ),
  (
    'Craft Steel Longsword',
    (SELECT id FROM item_definitions WHERE name = 'Steel Longsword'),
    1,
    '[{"item_def_id": (SELECT id FROM item_definitions WHERE name=''Iron Ore''), "quantity": 8},
      {"item_def_id": (SELECT id FROM item_definitions WHERE name=''Magic Crystal''), "quantity": 2}]',
    0.70, 60, 5, 2000
  ),
  (
    'Forge Dragonbone Axe',
    (SELECT id FROM item_definitions WHERE name = 'Dragonbone Axe'),
    1,
    '[{"item_def_id": (SELECT id FROM item_definitions WHERE name=''Dragon Scale''), "quantity": 5},
      {"item_def_id": (SELECT id FROM item_definitions WHERE name=''Iron Ore''), "quantity": 10},
      {"item_def_id": (SELECT id FROM item_definitions WHERE name=''Magic Crystal''), "quantity": 5}]',
    0.40, 120, 25, 50000
  );


-- ── BLACK MARKET INITIAL STOCK ───────────────────────────────

UPDATE item_definitions
SET extra_data = jsonb_set(extra_data, '{black_market_available}', 'true')
WHERE name IN ('Elixir of Fury', 'Dragon Scale', 'Fence''s Pass', 'Ancient Rune');

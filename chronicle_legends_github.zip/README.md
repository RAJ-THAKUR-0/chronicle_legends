# ⚔️ Chronicle Legends — Telegram MMORPG Bot

> A production-grade Telegram MMORPG with a full currency engine, 8 playable races,
> three-tier marketplace, global boss raids, and deep admin controls.
> **Database hosted free on Supabase — no local server needed.**

---

## 📁 Project Structure

```
chronicle_legends/
│
├── 📄 README.md                      ← You are here
├── 📄 requirements.txt               ← Python packages
│
├── ⚙️  config/
│   ├── .env.example                  ← COPY THIS → .env (fill 3 values)
│   └── settings.py                   ← Reads .env, handles SSL automatically
│
├── 🐍 src/
│   ├── core/                         ← Foundation (loaded by everything else)
│   │   ├── economy.py                  Currency engine (BigInt copper math)
│   │   ├── races.py                    8 race definitions + passive system
│   │   └── database.py                 Async PostgreSQL pool + repositories
│   │
│   ├── systems/                      ← All game mechanics
│   │   ├── combat.py                   Turn-based combat + status effects
│   │   ├── inventory.py                Items, equip/unequip, bank storage
│   │   ├── market.py                   Player / Merchant / Black Market
│   │   ├── guild.py                    Guild vault + ranked membership
│   │   ├── crafting.py                 Recipe engine with RNG rolls
│   │   └── boss.py                     Global raids + reward distribution
│   │
│   ├── admin/
│   │   └── admin.py                  ← All admin commands + middleware
│   │
│   └── bot/
│       └── bot.py                    ← Telegram entry point + command router
│
├── 🗄️  database/
│   ├── migrations/                   ← Run in ORDER (handled by init_db.sh)
│   │   ├── 001_initial_schema.sql      All tables, indexes, triggers, views
│   │   └── 002_monster_definitions.sql Monster table with photo support
│   │
│   └── seeds/                        ← Optional starter content
│       └── 001_starter_data.sql        Items, bosses, crafting recipes
│
├── 📜 scripts/
│   ├── init_db.sh                    ← One-command database setup wizard
│   └── run.sh                        ← One-command bot launcher
│
└── 📖 docs/
    └── dev_bible.html                ← Open in browser for interactive docs
```

---

## 🚀 Setup Guide

### What you need before starting

| Tool | Version | How to check |
|------|---------|--------------|
| Python | 3.11+ | `python --version` |
| pip | any | `pip --version` |
| psql client | any | `psql --version` |

> **No local PostgreSQL server needed!**
> We use Supabase — free cloud database that stays online 24/7.

---

## Step 1 — Create Your Free Database on Supabase

**Go to [supabase.com](https://supabase.com) and sign up (free, no credit card)**

Then:

```
1. Click "New Project"
   - Name:              chronicle-legends
   - Database Password: choose something strong → SAVE THIS PASSWORD
   - Region:            pick the one closest to you
   - Click "Create new project" — wait about 60 seconds

2. Get your connection string:
   - Left sidebar → Settings (gear icon) → Database
   - Scroll down to "Connection string"
   - Click the "URI" tab
   - Copy the string — looks like:
     postgresql://postgres:[YOUR-PASSWORD]@db.abcdefgh.supabase.co:5432/postgres
   - Replace [YOUR-PASSWORD] with your actual password from Step 1
```

---

## Step 2 — Get a Telegram Bot Token

```
1. Open Telegram → search for @BotFather
2. Send: /newbot
3. Pick a name:     Chronicle Legends
4. Pick a username: something_legends_bot
5. Copy the token it sends (looks like: 7123456789:AAHx-abc...)
```

---

## Step 3 — Get Your Telegram User ID (for admin access)

```
1. Open Telegram → search for @userinfobot
2. Send any message
3. It replies with your numeric ID — looks like: 123456789
   Save this — you'll need it in the next step
```

---

## Step 4 — Configure the Bot

```bash
# Unzip the project and enter it
cd chronicle_legends

# Copy the config template
cp config/.env.example .env

# Open .env and fill in these 3 required values:
nano .env
```

**The only 3 lines you MUST change:**

```env
BOT_TOKEN=7123456789:AAHx-abc...        ← from @BotFather
DATABASE_URL=postgresql://postgres:YourPassword@db.abc.supabase.co:5432/postgres
SUPERADMIN_IDS=123456789               ← your Telegram user ID
```

Everything else can stay as the default.

---

## Step 5 — Install Python Packages

```bash
# Create a virtual environment (keeps things clean)
python -m venv venv

# Activate it:
source venv/bin/activate          # Mac / Linux
venv\Scripts\activate             # Windows

# Install all dependencies
pip install -r requirements.txt
```

---

## Step 6 — Set Up the Database

```bash
chmod +x scripts/init_db.sh
./scripts/init_db.sh
```

The wizard will:
- ✅ Test your Supabase connection
- ✅ Run all migrations (creates all tables)
- ✅ Ask if you want starter items, bosses, and recipes (say yes!)

> **Alternative — No psql installed?**
> Go to Supabase Dashboard → SQL Editor
> Paste and run `database/migrations/001_initial_schema.sql`
> Then paste and run `database/migrations/002_monster_definitions.sql`
> Then paste and run `database/seeds/001_starter_data.sql`

---

## Step 7 — Run the Bot

```bash
chmod +x scripts/run.sh
./scripts/run.sh
```

Or directly:
```bash
python src/bot/bot.py
```

**Open Telegram and send your bot `/start`** — your MMORPG is live! 🎮

---

## 🎮 Player Commands

| Command | What it does |
|---------|-------------|
| `/start` | Create your character or log back in |
| `/create [race]` | Choose your race at character creation |
| `/profile` | View stats, level, gear, and wallet |
| `/inventory` | View your bag and equipped items |
| `/bank deposit 50g` | Move gold to bank (safe from death penalty) |
| `/bank withdraw 50g` | Take gold out of bank |
| `/bank store [item_uid]` | Store an item safely in bank |
| `/market` | Browse the player-to-player market |
| `/market sell [uid] 10g` | List an item for sale (5% tax applied) |
| `/market buy [id]` | Purchase a market listing |
| `/market search [name]` | Search listings by item name |
| `/merchant sell [uid]` | Sell to NPC instantly (55% of value) |
| `/merchant buy [item_id]` | Buy from NPC shop (120% of value) |
| `/bm` | Browse Black Market (Level 10+ only) |
| `/bm sell [uid]` | Sell to fence (40% value, 5% bust risk) |
| `/craft list` | View all available recipes at your level |
| `/craft [recipe_id]` | Attempt to craft an item (RNG roll) |
| `/guild create [Name] [TAG]` | Found a guild (costs 50g) |
| `/guild info` | View your guild's stats and members |
| `/guild deposit 20g` | Add gold to the guild vault |
| `/raid_status` | View the current global boss raid |
| `/raid_attack` | Strike the active boss for damage |

**Races:** `human` `elf` `orc` `dwarf` `halfling` `dragonborn` `undead` `fae`

---

## 🔨 Admin Commands

> Requires your Telegram user ID in `SUPERADMIN_IDS` in `.env`

| Command | What it does |
|---------|-------------|
| `/ban [user_id] [reason]` | Ban a player from the bot |
| `/unban [user_id]` | Restore a banned player |
| `/give_item [user_id] [item_id] [qty]` | Give items to any player |
| `/give_currency me 1p` | Give platinum/gold to **yourself** |
| `/give_currency [user_id] 50g` | Give currency to any player |
| `/take_currency [user_id] 20g` | Remove currency from a player |
| `/set_balance [user_id] 100g` | Set a player's exact wallet balance |
| `/set_stats [user_id] str:20 hp_max:500` | Set player stats directly |
| `/set_stats [user_id] +str:5` | Add to a player's existing stats |
| `/set_level [user_id] 50` | Set a player's level |
| `/admin_create_monster` | Open the 10-step monster creator (with photo!) |
| `/spawn_boss [id]` | Force-spawn a boss raid immediately |
| `/server_stats` | Full economy + player analytics dashboard |
| `/reset_player [user_id] confirm` | Wipe a character completely |

---

## 💰 Currency Quick Reference

```
1 Platinum (p) = 100 Gold     = 10,000 Silver  = 1,000,000 Copper
1 Gold (g)     = 100 Silver   = 10,000 Copper
1 Silver (s)   = 100 Copper
```

**Usage examples in commands:**
```
/give_currency me 1p 50g        → gives yourself 150 gold worth
/set_balance 123456 2p          → sets wallet to exactly 2 platinum
/bank deposit 1g 30s 50c        → deposits that exact amount
/market sell abc123 5g 50s      → lists item for 5 gold 50 silver
```

**Economy sinks (keeps inflation in check):**
- 5% tax on every player market sale
- Items sold to merchant NPC are permanently destroyed
- Crafting costs copper to attempt
- Death removes 10% of wallet (bank is always 100% safe)
- Creating a guild costs 50g

---

## 🐉 Creating a Monster (Admin Guide)

Type `/admin_create_monster` — the bot walks you through 10 steps:

```
Step 1  → Name         e.g. Shadow Wraith
Step 2  → Description  Lore text shown in combat
Step 3  → Zone         e.g. dark_forest
Step 4  → Level        1–999
Step 5  → HP           e.g. 5000
Step 6  → Attack       e.g. 150
Step 7  → Defense      e.g. 60
Step 8  → Speed        e.g. 80  (higher = attacks first)
Step 9  → XP & Copper  e.g. 800 200-500
           (format: [xp] [copper_min]-[copper_max])
Step 10 → Photo        Send any image OR type "skip"

Then type "confirm" → monster is live immediately
```

---

## 🏪 Market System

| Market | You Receive | Tax | Access | Notes |
|--------|------------|-----|--------|-------|
| 🏪 Player Market | 95% of your price | 5% | All players | You set the price. Listing lasts 7 days. |
| 🛒 NPC Merchant | 55% of item value | None | All players | Instant. Item destroyed (good for economy). |
| 🌑 Black Market | 40% of item value | None | Level 10+ | 5% chance guards confiscate your item + fine. |

---

## ☁️ Supabase Free Tier — What You Get

| Feature | Free Limit |
|---------|-----------|
| Database storage | 500 MB |
| API requests | Unlimited |
| Backups | Daily automatic |
| Bandwidth | 5 GB/month |
| Max connections | 60 |
| Auto-pause | After 1 week inactive |

**Auto-pause means:** if nobody uses the bot for 7 days, Supabase pauses your DB.
It wakes up automatically on the next request (takes ~2 seconds).

**To prevent auto-pause:** upgrade to Supabase Pro ($25/mo), or set up a free
cron job on [cron-job.org](https://cron-job.org) to ping your bot every few days.

---

## 🗄️ View Your Data (Supabase Dashboard)

After setup, you can see all your game data visually:

```
supabase.com → your project → Table Editor

Tables you'll use most:
  users            → all players, their stats and wallets
  transactions     → full currency ledger (read-only for audit)
  inventory_items  → every item every player owns
  market_listings  → active + sold market listings
  boss_raids       → raid history and participants
  monster_definitions → your custom monsters
```

You can also run custom SQL:
```
SQL Editor → New query → paste any SQL → Run
```

---

## ❓ Troubleshooting

**"BOT_TOKEN is not set" error**
→ Make sure `.env` exists in the project root (not inside `config/`)
→ Check BOT_TOKEN has no spaces or quotes around it

**"DATABASE_URL still has placeholder values" error**
→ You forgot to replace `[YOUR-PASSWORD]` and `xxxxxxxxxxxx` in `.env`
→ Go to Supabase → Settings → Database → copy the real URI

**Cannot connect to Supabase**
→ Double-check your password — it's the one you set when creating the project
→ Try copying the connection string fresh from the Supabase dashboard
→ Make sure `DB_SSL_MODE=require` in your `.env`

**"Access Denied" on admin commands**
→ Your Telegram user ID must be in `SUPERADMIN_IDS` in `.env`
→ Get your ID from @userinfobot on Telegram
→ Restart the bot after changing `.env`

**Bot doesn't respond at all**
→ Check the terminal where you ran `./scripts/run.sh` for error messages
→ Make sure the bot isn't already running in another terminal
→ Verify BOT_TOKEN is correct by checking with @BotFather

**Supabase project is paused**
→ Go to supabase.com → your project → click "Restore project"
→ Takes about 30 seconds to wake up

---

## 📖 Interactive Documentation

Open `docs/dev_bible.html` in any browser for:
- Live currency calculator
- Interactive race comparison with stat viewer
- Combat formula reference
- Market economics diagram
- Full database schema browser
- Complete command reference

---

*Chronicle Legends · Python 3.11 · asyncpg · python-telegram-bot · Supabase PostgreSQL*

"""
database.py — Chronicle Legends MMORPG Bot
Async Database Service (asyncpg + PostgreSQL)

Provides:
  - ConnectionPool singleton
  - Repository pattern for each domain entity
  - All currency stored/retrieved as int (copper)
  - Typed return dataclasses for safety
"""

from __future__ import annotations
import asyncpg
import asyncio
import logging
import os
from dataclasses import dataclass, field
from typing import Optional, Any
from datetime import datetime

from economy import Currency, format_currency

log = logging.getLogger("db")

# Import settings (handles .env loading + Supabase SSL)
try:
    import sys, os as _os
    sys.path.insert(0, _os.path.join(_os.path.dirname(__file__), '..', '..', '..'))
    from config.settings import settings
    DATABASE_URL = settings.database_url
    _SSL_CONTEXT  = settings.build_ssl_context()
except Exception:
    DATABASE_URL = _os.getenv("DATABASE_URL", "postgresql://user:password@localhost:5432/chronicle_legends")
    _SSL_CONTEXT  = None


# ─────────────────────────────────────────────
# CONNECTION POOL SINGLETON
# ─────────────────────────────────────────────

_pool: Optional[asyncpg.Pool] = None


async def get_pool() -> asyncpg.Pool:
    """Returns the singleton connection pool, initializing it on first call."""
    global _pool
    if _pool is None:
        pool_kwargs = dict(
            min_size=getattr(settings, 'db_pool_min', 2),
            max_size=getattr(settings, 'db_pool_max', 10),
            command_timeout=30,
            init=_configure_codecs,
        )
        # Supabase and most cloud DBs require SSL
        if _SSL_CONTEXT is not None:
            pool_kwargs["ssl"] = _SSL_CONTEXT

        _pool = await asyncpg.create_pool(DATABASE_URL, **pool_kwargs)
        log.info("Database pool initialized.")
    return _pool


async def _configure_codecs(conn: asyncpg.Connection):
    """Register type codecs on each new connection."""
    await conn.set_type_codec(
        "jsonb", encoder=lambda v: v, decoder=lambda v: v, schema="pg_catalog", format="text"
    )


async def close_pool():
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
        log.info("Database pool closed.")


# ─────────────────────────────────────────────
# TYPED RETURN OBJECTS
# ─────────────────────────────────────────────

@dataclass
class UserRecord:
    id:             int
    username:       Optional[str]
    display_name:   str
    status:         str
    is_admin:       bool
    is_superadmin:  bool
    race:           str
    level:          int
    experience:     int
    experience_next: int
    stat_str:       int
    stat_dex:       int
    stat_int:       int
    stat_vit:       int
    stat_wis:       int
    stat_luk:       int
    stat_points:    int
    hp_current:     int
    hp_max:         int
    mp_current:     int
    mp_max:         int
    wallet:         Currency
    bank:           Currency
    guild_id:       Optional[int]
    deaths:         int
    kills:          int
    current_zone:   str
    last_active:    datetime

    @classmethod
    def from_row(cls, row: asyncpg.Record) -> "UserRecord":
        return cls(
            id=row["id"],
            username=row["username"],
            display_name=row["display_name"],
            status=row["status"],
            is_admin=row["is_admin"],
            is_superadmin=row["is_superadmin"],
            race=row["race"],
            level=row["level"],
            experience=row["experience"],
            experience_next=row["experience_next"],
            stat_str=row["stat_str"],
            stat_dex=row["stat_dex"],
            stat_int=row["stat_int"],
            stat_vit=row["stat_vit"],
            stat_wis=row["stat_wis"],
            stat_luk=row["stat_luk"],
            stat_points=row["stat_points"],
            hp_current=row["hp_current"],
            hp_max=row["hp_max"],
            mp_current=row["mp_current"],
            mp_max=row["mp_max"],
            wallet=Currency.from_copper(row["wallet_copper"]),
            bank=Currency.from_copper(row["bank_copper"]),
            guild_id=row["guild_id"],
            deaths=row["deaths"],
            kills=row["kills"],
            current_zone=row["current_zone"],
            last_active=row["last_active"],
        )


# ─────────────────────────────────────────────
# USER REPOSITORY
# ─────────────────────────────────────────────

class UserRepository:
    """All database operations for the users table."""

    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def get(self, user_id: int) -> Optional[UserRecord]:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM users WHERE id = $1", user_id
            )
        return UserRecord.from_row(row) if row else None

    async def get_or_create(
        self, user_id: int, username: Optional[str], display_name: str, race: str
    ) -> tuple[UserRecord, bool]:
        """Returns (UserRecord, created: bool)."""
        pool = self._pool
        async with pool.acquire() as conn:
            existing = await conn.fetchrow("SELECT * FROM users WHERE id = $1", user_id)
            if existing:
                return UserRecord.from_row(existing), False

            row = await conn.fetchrow(
                """
                INSERT INTO users (id, username, display_name, race)
                VALUES ($1, $2, $3, $4)
                RETURNING *
                """,
                user_id, username, display_name, race
            )
            return UserRecord.from_row(row), True

    async def update_last_active(self, user_id: int):
        async with self._pool.acquire() as conn:
            await conn.execute(
                "UPDATE users SET last_active = NOW() WHERE id = $1", user_id
            )

    async def transfer_wallet(
        self,
        conn: asyncpg.Connection,
        from_id: int,
        to_id: int,
        amount: Currency,
        tx_type: str,
        description: str = "",
    ) -> None:
        """
        Atomic wallet transfer inside an existing transaction.
        Caller must pass an acquired connection within BEGIN/COMMIT.
        """
        # Deduct from sender
        result = await conn.execute(
            """
            UPDATE users SET wallet_copper = wallet_copper - $1
            WHERE id = $2 AND wallet_copper >= $1
            """,
            amount.copper, from_id
        )
        if result == "UPDATE 0":
            raise InsufficientFundsError(f"User {from_id} cannot afford {amount}")

        # Credit receiver
        await conn.execute(
            "UPDATE users SET wallet_copper = wallet_copper + $1 WHERE id = $2",
            amount.copper, to_id
        )

        # Fetch snapshots for ledger
        from_bal = await conn.fetchval("SELECT wallet_copper FROM users WHERE id=$1", from_id)
        to_bal   = await conn.fetchval("SELECT wallet_copper FROM users WHERE id=$1", to_id)

        # Append to ledger
        await conn.execute(
            """
            INSERT INTO transactions
              (tx_type, from_user_id, to_user_id, amount_copper,
               description, from_balance_after, to_balance_after)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            """,
            tx_type, from_id, to_id, amount.copper,
            description, from_bal, to_bal
        )

    async def apply_death_penalty(self, user_id: int, rate: float = 0.10) -> Currency:
        """Deducts death penalty from wallet. Returns copper lost."""
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT wallet_copper FROM users WHERE id = $1 FOR UPDATE", user_id
                )
                wallet = Currency.from_copper(row["wallet_copper"])
                remaining, lost = wallet.apply_death_penalty(rate)

                await conn.execute(
                    "UPDATE users SET wallet_copper = $1, deaths = deaths + 1 WHERE id = $2",
                    remaining.copper, user_id
                )
                await conn.execute(
                    """
                    INSERT INTO transactions
                      (tx_type, from_user_id, amount_copper, description)
                    VALUES ('death_penalty', $1, $2, 'Died in combat')
                    """,
                    user_id, lost.copper
                )
        return lost

    async def admin_set_balance(self, user_id: int, new_amount: Currency, admin_id: int):
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "UPDATE users SET wallet_copper = $1 WHERE id = $2",
                    new_amount.copper, user_id
                )
                await conn.execute(
                    """
                    INSERT INTO transactions
                      (tx_type, to_user_id, from_user_id, amount_copper, description)
                    VALUES ('admin_grant', $1, $2, $3, 'Admin set_balance')
                    """,
                    user_id, admin_id, new_amount.copper
                )

    async def ban(self, user_id: int, admin_id: int, reason: str, expires_at=None):
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "UPDATE users SET status = 'banned' WHERE id = $1", user_id
                )
                await conn.execute(
                    """
                    INSERT INTO ban_log (target_user_id, admin_user_id, action, reason, expires_at)
                    VALUES ($1, $2, 'ban', $3, $4)
                    """,
                    user_id, admin_id, reason, expires_at
                )

    async def unban(self, user_id: int, admin_id: int):
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                await conn.execute(
                    "UPDATE users SET status = 'active' WHERE id = $1", user_id
                )
                await conn.execute(
                    """
                    INSERT INTO ban_log (target_user_id, admin_user_id, action, reason)
                    VALUES ($1, $2, 'unban', 'Admin unban')
                    """,
                    user_id, admin_id
                )

    async def get_server_stats(self) -> dict[str, Any]:
        async with self._pool.acquire() as conn:
            economy = await conn.fetchrow("SELECT * FROM v_economy_stats")
            active_24h = await conn.fetchval(
                "SELECT COUNT(*) FROM users WHERE last_active > NOW() - INTERVAL '24 hours'"
            )
            top_players = await conn.fetch(
                "SELECT display_name, level, race FROM v_leaderboard LIMIT 5"
            )
        return {
            "active_24h":      active_24h,
            "total_supply":    format_currency(economy["total_supply"] or 0),
            "in_wallets":      format_currency(economy["total_in_wallets"] or 0),
            "in_banks":        format_currency(economy["total_in_banks"] or 0),
            "avg_wealth":      format_currency(int(economy["avg_wealth"] or 0)),
            "active_players":  economy["active_players"],
            "top_players":     [dict(r) for r in top_players],
        }


# ─────────────────────────────────────────────
# BOSS RAID REPOSITORY
# ─────────────────────────────────────────────

class RaidRepository:
    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def get_active_raid(self) -> Optional[asyncpg.Record]:
        async with self._pool.acquire() as conn:
            return await conn.fetchrow(
                """
                SELECT r.*, b.name, b.icon_emoji, b.loot_table, b.copper_reward_base
                FROM boss_raids r
                JOIN boss_definitions b ON r.boss_def_id = b.id
                WHERE r.status = 'active'
                ORDER BY r.spawned_at DESC
                LIMIT 1
                """
            )

    async def deal_damage(self, raid_id: int, user_id: int, damage: int) -> dict:
        """
        Atomically records player damage and updates boss HP.
        Returns {"boss_hp": int, "is_defeated": bool}
        """
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                # Lock the raid row
                boss = await conn.fetchrow(
                    "SELECT hp_current FROM boss_raids WHERE id = $1 FOR UPDATE", raid_id
                )
                new_hp = max(0, boss["hp_current"] - damage)

                await conn.execute(
                    "UPDATE boss_raids SET hp_current = $1 WHERE id = $2",
                    new_hp, raid_id
                )

                # Upsert participant damage
                await conn.execute(
                    """
                    INSERT INTO raid_participants (raid_id, user_id, damage_dealt, hits, last_hit_at)
                    VALUES ($1, $2, $3, 1, NOW())
                    ON CONFLICT (raid_id, user_id) DO UPDATE
                      SET damage_dealt = raid_participants.damage_dealt + $3,
                          hits = raid_participants.hits + 1,
                          last_hit_at = NOW()
                    """,
                    raid_id, user_id, damage
                )

                if new_hp == 0:
                    await conn.execute(
                        "UPDATE boss_raids SET status = 'defeated', defeated_at = NOW() WHERE id = $1",
                        raid_id
                    )

        return {"boss_hp": new_hp, "is_defeated": new_hp == 0}

    async def distribute_rewards(self, raid_id: int) -> list[dict]:
        """
        Pro-rata reward distribution based on damage % share.
        Returns list of {user_id, reward_copper, share_pct}.
        """
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                raid = await conn.fetchrow(
                    """
                    SELECT r.hp_max, b.copper_reward_base
                    FROM boss_raids r
                    JOIN boss_definitions b ON r.boss_def_id = b.id
                    WHERE r.id = $1
                    """,
                    raid_id
                )
                participants = await conn.fetch(
                    "SELECT user_id, damage_dealt FROM raid_participants WHERE raid_id = $1",
                    raid_id
                )

                total_damage = sum(p["damage_dealt"] for p in participants)
                total_reward = raid["copper_reward_base"]
                rewards = []

                for p in participants:
                    share = p["damage_dealt"] / total_damage if total_damage > 0 else 0
                    reward = int(total_reward * share)
                    rewards.append({
                        "user_id": p["user_id"],
                        "reward_copper": reward,
                        "share_pct": round(share * 100, 2),
                    })

                    # Credit wallet and record
                    await conn.execute(
                        "UPDATE users SET wallet_copper = wallet_copper + $1 WHERE id = $2",
                        reward, p["user_id"]
                    )
                    await conn.execute(
                        """
                        UPDATE raid_participants
                        SET reward_copper = $1, rewarded_at = NOW()
                        WHERE raid_id = $2 AND user_id = $3
                        """,
                        reward, raid_id, p["user_id"]
                    )
                    await conn.execute(
                        """
                        INSERT INTO transactions
                          (tx_type, to_user_id, amount_copper, description, reference_id)
                        VALUES ('raid_reward', $1, $2, 'Boss raid reward', $3)
                        """,
                        p["user_id"], reward, f"boss_raid:{raid_id}"
                    )

        return rewards


# ─────────────────────────────────────────────
# SERVICE LOCATOR
# ─────────────────────────────────────────────

class Services:
    """
    Lightweight service locator. Initialize once at bot startup.

    Usage:
        await Services.init()
        user = await Services.users.get(telegram_user_id)
    """
    users: UserRepository
    raids: RaidRepository
    _initialized = False

    @classmethod
    async def init(cls):
        pool = await get_pool()
        cls.users = UserRepository(pool)
        cls.raids = RaidRepository(pool)
        cls._initialized = True
        log.info("Services initialized.")

    @classmethod
    def require(cls):
        if not cls._initialized:
            raise RuntimeError("Services.init() must be called before use.")


# Re-export for convenience
from economy import InsufficientFundsError

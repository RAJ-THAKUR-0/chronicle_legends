"""
economy.py — Chronicle Legends MMORPG Bot
Currency Engine & Economy Service

All values stored and calculated in COPPER (int).
Conversion: 1 Platinum = 100 Gold = 10,000 Silver = 1,000,000 Copper
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import math


# ─────────────────────────────────────────────
# CURRENCY CONSTANTS
# ─────────────────────────────────────────────

COPPER_PER_SILVER   = 100
COPPER_PER_GOLD     = 10_000        # 100 Silver × 100 Copper
COPPER_PER_PLATINUM = 1_000_000     # 100 Gold × 10,000 Copper

MARKET_TAX_RATE     = 0.05          # 5% listing fee
DEATH_PENALTY_RATE  = 0.10          # 10% of wallet lost on death
MAX_WALLET_DISPLAY  = 999_999_999_999  # Safety cap for display


# ─────────────────────────────────────────────
# CURRENCY VALUE OBJECT
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class Currency:
    """
    Immutable currency value stored entirely in copper (int).
    Use Currency.from_copper() or Currency.from_parts() to construct.

    >>> Currency.from_parts(1, 5, 30, 75)
    Currency(1p 5g 30s 75c) [1_053_075 copper]
    """
    copper: int = 0

    def __post_init__(self):
        if not isinstance(self.copper, int):
            raise TypeError(f"Currency copper must be int, got {type(self.copper)}")
        if self.copper < 0:
            raise ValueError(f"Currency cannot be negative: {self.copper}")

    # ── Factories ───────────────────────────────

    @classmethod
    def from_copper(cls, copper: int) -> "Currency":
        return cls(copper=max(0, int(copper)))

    @classmethod
    def from_parts(cls, platinum: int = 0, gold: int = 0,
                   silver: int = 0, copper: int = 0) -> "Currency":
        """Build from denomination parts. All values ≥ 0."""
        total = (
            int(platinum) * COPPER_PER_PLATINUM +
            int(gold)     * COPPER_PER_GOLD     +
            int(silver)   * COPPER_PER_SILVER   +
            int(copper)
        )
        return cls(copper=total)

    @classmethod
    def zero(cls) -> "Currency":
        return cls(copper=0)

    # ── Decomposition ───────────────────────────

    @property
    def breakdown(self) -> dict[str, int]:
        """Returns each denomination as a dict (no remainder overflow)."""
        remainder = self.copper
        platinum, remainder = divmod(remainder, COPPER_PER_PLATINUM)
        gold,     remainder = divmod(remainder, COPPER_PER_GOLD)
        silver,   copper    = divmod(remainder, COPPER_PER_SILVER)
        return {"platinum": platinum, "gold": gold, "silver": silver, "copper": copper}

    # ── Formatting ──────────────────────────────

    def format(self, short: bool = False) -> str:
        """
        Display-friendly currency string.
        format()      → '1p 5g 30s 75c'
        format(short) → '1p 5g' (omits zero/minor denoms)
        """
        b = self.breakdown
        parts = []

        if b["platinum"] > 0:
            parts.append(f"{b['platinum']:,}p")
        if b["gold"] > 0:
            parts.append(f"{b['gold']:,}g")
        if b["silver"] > 0:
            parts.append(f"{b['silver']:,}s")
        if b["copper"] > 0 or not parts:   # Always show at least copper
            parts.append(f"{b['copper']:,}c")

        if short and len(parts) > 2:
            parts = parts[:2]              # Show top 2 denominations only

        return " ".join(parts)

    def format_compact(self) -> str:
        """Ultra-compact for status bars. '1.2p' / '345g' / '12s'"""
        b = self.breakdown
        if b["platinum"] > 0:
            val = self.copper / COPPER_PER_PLATINUM
            return f"{val:.1f}p"
        if b["gold"] > 0:
            val = self.copper / COPPER_PER_GOLD
            return f"{val:.1f}g"
        if b["silver"] > 0:
            val = self.copper / COPPER_PER_SILVER
            return f"{val:.0f}s"
        return f"{self.copper}c"

    # ── Arithmetic (returns new Currency) ───────

    def __add__(self, other: "Currency") -> "Currency":
        return Currency(self.copper + other.copper)

    def __sub__(self, other: "Currency") -> "Currency":
        result = self.copper - other.copper
        if result < 0:
            raise InsufficientFundsError(
                f"Cannot subtract {other} from {self}: would go negative"
            )
        return Currency(result)

    def __mul__(self, factor: float) -> "Currency":
        return Currency(int(self.copper * factor))

    def __lt__(self, other: "Currency") -> bool:
        return self.copper < other.copper

    def __le__(self, other: "Currency") -> bool:
        return self.copper <= other.copper

    def __gt__(self, other: "Currency") -> bool:
        return self.copper > other.copper

    def __ge__(self, other: "Currency") -> bool:
        return self.copper >= other.copper

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Currency):
            return self.copper == other.copper
        return NotImplemented

    def __bool__(self) -> bool:
        return self.copper > 0

    def __repr__(self) -> str:
        return f"Currency({self.format()}) [{self.copper:,} copper]"

    def can_afford(self, cost: "Currency") -> bool:
        return self.copper >= cost.copper

    def apply_tax(self, rate: float = MARKET_TAX_RATE) -> tuple["Currency", "Currency"]:
        """Returns (after_tax, tax_amount)."""
        tax = Currency(int(self.copper * rate))
        return Currency(self.copper - tax.copper), tax

    def apply_death_penalty(self, rate: float = DEATH_PENALTY_RATE) -> tuple["Currency", "Currency"]:
        """Returns (remaining_wallet, lost_amount)."""
        lost = Currency(int(self.copper * rate))
        return Currency(self.copper - lost.copper), lost


# ─────────────────────────────────────────────
# ECONOMY EXCEPTIONS
# ─────────────────────────────────────────────

class EconomyError(Exception):
    """Base for all economy-related errors."""

class InsufficientFundsError(EconomyError):
    """Raised when a player cannot afford an action."""

class InvalidAmountError(EconomyError):
    """Raised for zero/negative currency amounts."""

class BankError(EconomyError):
    """Raised for bank-related issues."""


# ─────────────────────────────────────────────
# UTILITY: format_currency (standalone helper)
# ─────────────────────────────────────────────

def format_currency(copper: int, short: bool = False) -> str:
    """
    Standalone formatter. Accepts raw copper int.

    >>> format_currency(1_053_075)
    '1p 5g 30s 75c'
    >>> format_currency(500_000, short=True)
    '50g'
    """
    return Currency.from_copper(copper).format(short=short)


def parse_currency(text: str) -> Currency:
    """
    Parse a user-typed currency string like '5g 20s' into a Currency object.
    Supports: p/platinum, g/gold, s/silver, c/copper
    """
    import re
    text = text.lower().strip()
    mapping = {
        "p": COPPER_PER_PLATINUM, "platinum": COPPER_PER_PLATINUM,
        "g": COPPER_PER_GOLD,     "gold":     COPPER_PER_GOLD,
        "s": COPPER_PER_SILVER,   "silver":   COPPER_PER_SILVER,
        "c": 1,                   "copper":   1,
    }
    total = 0
    for match in re.finditer(r"(\d+)\s*(p(?:latinum)?|g(?:old)?|s(?:ilver)?|c(?:opper)?)", text):
        amount = int(match.group(1))
        unit   = match.group(2)
        total += amount * mapping[unit]
    if total == 0 and text.isdigit():
        total = int(text)   # Bare number = copper
    return Currency.from_copper(total)


# ─────────────────────────────────────────────
# STATUS BAR RENDERER
# ─────────────────────────────────────────────

def render_bar(current: int, maximum: int, length: int = 8, filled: str = "█", empty: str = "░") -> str:
    """
    Renders a visual progress bar.
    >>> render_bar(80, 100)
    '████████░░'   (8 filled, 2 empty — wrong, for illustration)
    Actual: render_bar(80, 100, 10) → '████████░░'
    """
    if maximum <= 0:
        return empty * length
    filled_count = round((current / maximum) * length)
    filled_count = max(0, min(length, filled_count))
    return filled * filled_count + empty * (length - filled_count)


def render_status_bar(
    hp_current: int,
    hp_max: int,
    mp_current: int,
    mp_max: int,
    level: int,
    wallet_copper: int,
    experience: int,
    exp_next: int,
) -> str:
    """
    Renders the standard player status bar appended to every command response.

    Output:
    ┤ HP [████████░░] 80/100 · MP [████░░░░░░] 40/100 · LVL 5 · 💰 2g 50s ├
    ┤ XP [████░░░░░░] 400/1000 (40%)                                        ├
    """
    hp_bar  = render_bar(hp_current, hp_max)
    mp_bar  = render_bar(mp_current, mp_max)
    xp_bar  = render_bar(experience, exp_next)
    xp_pct  = int((experience / exp_next) * 100) if exp_next else 0
    wallet  = format_currency(wallet_copper, short=True)
    hp_pct  = int((hp_current / hp_max) * 100) if hp_max else 0

    return (
        f"┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n"
        f"❤️ [{hp_bar}] {hp_current}/{hp_max} ({hp_pct}%)  "
        f"💧 [{mp_bar}] {mp_current}/{mp_max}\n"
        f"⚔️ LVL {level}  ✨ XP [{xp_bar}] {xp_pct}%  💰 {wallet}"
    )

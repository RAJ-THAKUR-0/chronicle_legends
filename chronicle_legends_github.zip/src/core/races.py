"""
races.py — Chronicle Legends MMORPG Bot
Race System: Definitions, Stat Modifiers, Racial Passives

Each Race is an immutable dataclass with:
  - Base stat modifiers applied at character creation
  - Passive abilities (triggered by the combat/event engine)
  - Flavour data (lore, icon, start zone)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Optional
from enum import Enum


# ─────────────────────────────────────────────
# STAT BLOCK
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class StatModifiers:
    """
    Additive bonuses layered on top of the base character stats.
    Negative values are valid (tradeoffs by design).
    """
    str: int = 0   # Strength  → physical damage, carry weight
    dex: int = 0   # Dexterity → attack speed, crit chance, dodge
    int: int = 0   # Intellect → magic damage, mana pool
    vit: int = 0   # Vitality  → max HP, poison resist
    wis: int = 0   # Wisdom    → MP regen, healing power
    luk: int = 0   # Luck      → drop rates, crit multiplier, gambling

    def __add__(self, other: "StatModifiers") -> "StatModifiers":
        return StatModifiers(
            str=self.str + other.str,
            dex=self.dex + other.dex,
            int=self.int + other.int,
            vit=self.vit + other.vit,
            wis=self.wis + other.wis,
            luk=self.luk + other.luk,
        )

    def to_dict(self) -> dict[str, int]:
        return {"str": self.str, "dex": self.dex, "int": self.int,
                "vit": self.vit, "wis": self.wis, "luk": self.luk}

    def summary(self) -> str:
        """Returns only non-zero stats for clean display."""
        NAMES = {"str": "STR", "dex": "DEX", "int": "INT",
                 "vit": "VIT", "wis": "WIS", "luk": "LUK"}
        parts = []
        for key, label in NAMES.items():
            val = getattr(self, key)
            if val != 0:
                sign = "+" if val > 0 else ""
                parts.append(f"{sign}{val} {label}")
        return ", ".join(parts) if parts else "No modifiers"


# ─────────────────────────────────────────────
# PASSIVE ABILITY
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class RacialPassive:
    """
    A named passive ability with a description and optional trigger hook.
    The trigger is a string key the combat/event engine subscribes to.
    """
    name:        str
    description: str
    trigger:     str        # e.g. 'on_death', 'on_craft', 'on_kill', 'always'
    effect_key:  str        # Looked up by the effect registry in combat.py
    magnitude:   float = 1.0


# ─────────────────────────────────────────────
# RACE CLASS
# ─────────────────────────────────────────────

@dataclass(frozen=True)
class Race:
    """
    Immutable race definition. Instantiated once per race at module load.

    All instances live in the RACES registry dict.
    Fetch with: RACES['orc'] or Race.get('orc')
    """
    key:          str
    display_name: str
    icon:         str
    lore:         str
    stat_mods:    StatModifiers
    passives:     tuple[RacialPassive, ...]
    start_zone:   str = "town_square"

    # Derived bonuses (applied in application layer, not DB)
    hp_bonus:     int   = 0      # Flat HP added at creation
    mp_bonus:     int   = 0      # Flat MP added at creation
    xp_rate:      float = 1.0    # XP gain multiplier (1.0 = normal)
    drop_rate:    float = 1.0    # Loot drop rate multiplier

    def get_passive(self, trigger: str) -> list[RacialPassive]:
        """Returns all passives matching a given trigger event."""
        return [p for p in self.passives if p.trigger in (trigger, 'always')]

    def card(self) -> str:
        """Renders a formatted race selection card for Telegram."""
        passive_lines = "\n".join(
            f"  ✦ {p.name}: {p.description}" for p in self.passives
        )
        bonuses = []
        if self.hp_bonus:  bonuses.append(f"+{self.hp_bonus} Max HP")
        if self.mp_bonus:  bonuses.append(f"+{self.mp_bonus} Max MP")
        if self.xp_rate != 1.0:
            bonuses.append(f"×{self.xp_rate:.1f} XP Gain")
        if self.drop_rate != 1.0:
            bonuses.append(f"×{self.drop_rate:.1f} Drop Rate")

        bonus_str = " | ".join(bonuses) if bonuses else "None"

        return (
            f"{self.icon} **{self.display_name}**\n"
            f"_{self.lore}_\n\n"
            f"📊 Stats: {self.stat_mods.summary()}\n"
            f"🎁 Bonuses: {bonus_str}\n"
            f"🌟 Passives:\n{passive_lines}\n"
            f"🗺️ Starts in: {self.start_zone.replace('_', ' ').title()}"
        )

    @staticmethod
    def get(key: str) -> "Race":
        """Fetch race by key. Raises KeyError if invalid."""
        return RACES[key.lower()]

    @staticmethod
    def all_keys() -> list[str]:
        return list(RACES.keys())

    @staticmethod
    def selection_menu() -> str:
        """Compact list of all races for /create command."""
        lines = ["🎭 **Choose your Race:**\n"]
        for key, race in RACES.items():
            lines.append(f"{race.icon} `{key}` — {race.display_name}")
        lines.append("\nUse /create <race> to begin your adventure!")
        return "\n".join(lines)


# ─────────────────────────────────────────────
# RACE DEFINITIONS
# ─────────────────────────────────────────────

RACES: dict[str, Race] = {

    "human": Race(
        key="human",
        display_name="Human",
        icon="🧑",
        lore="Adaptable and resourceful. Humans learn faster than any other race.",
        stat_mods=StatModifiers(str=1, dex=1, int=1, vit=1, wis=1, luk=1),
        passives=(
            RacialPassive(
                name="Versatile",
                description="Gain 10% bonus XP from all sources.",
                trigger="on_xp_gain",
                effect_key="xp_multiplier",
                magnitude=1.10,
            ),
            RacialPassive(
                name="Diplomacy",
                description="Shop prices are 5% cheaper.",
                trigger="on_purchase",
                effect_key="shop_discount",
                magnitude=0.05,
            ),
        ),
        xp_rate=1.10,
        start_zone="human_capital",
    ),

    "elf": Race(
        key="elf",
        display_name="High Elf",
        icon="🧝",
        lore="Ancient and wise. Elves command arcane arts with unmatched grace.",
        stat_mods=StatModifiers(str=-1, dex=3, int=3, vit=-1, wis=2, luk=1),
        passives=(
            RacialPassive(
                name="Arcane Affinity",
                description="All spell damage increased by 15%.",
                trigger="on_cast_spell",
                effect_key="spell_damage_multiplier",
                magnitude=1.15,
            ),
            RacialPassive(
                name="Forest Step",
                description="25% chance to dodge projectile attacks.",
                trigger="on_ranged_attack_received",
                effect_key="dodge_projectile_chance",
                magnitude=0.25,
            ),
        ),
        mp_bonus=50,
        start_zone="silver_forest",
    ),

    "orc": Race(
        key="orc",
        display_name="Orc",
        icon="👹",
        lore="Born for battle. Orcs grow stronger as blood is spilled.",
        stat_mods=StatModifiers(str=4, dex=-1, int=-2, vit=3, wis=-2, luk=0),
        passives=(
            RacialPassive(
                name="Blood Fury",
                description="Gain +2 STR for each kill in the current combat (max +10).",
                trigger="on_kill",
                effect_key="str_per_kill_stack",
                magnitude=2.0,
            ),
            RacialPassive(
                name="Thick Hide",
                description="Reduce incoming physical damage by 8%.",
                trigger="on_physical_damage_received",
                effect_key="flat_physical_reduction",
                magnitude=0.08,
            ),
        ),
        hp_bonus=75,
        start_zone="ironforge_wastes",
    ),

    "dwarf": Race(
        key="dwarf",
        display_name="Dwarf",
        icon="⛏️",
        lore="Stubborn and enduring. Dwarves are the master craftsmen of the realm.",
        stat_mods=StatModifiers(str=2, dex=-1, int=0, vit=3, wis=1, luk=2),
        passives=(
            RacialPassive(
                name="Master Smith",
                description="Crafting success rate increased by 20%.",
                trigger="on_craft",
                effect_key="crafting_success_bonus",
                magnitude=0.20,
            ),
            RacialPassive(
                name="Stone Skin",
                description="Survive a killing blow once per dungeon with 1 HP.",
                trigger="on_lethal_damage",
                effect_key="death_save",
                magnitude=1.0,
            ),
        ),
        hp_bonus=50,
        start_zone="deepstone_mines",
    ),

    "halfling": Race(
        key="halfling",
        display_name="Halfling",
        icon="🧙",
        lore="Small and often overlooked — but the luckiest souls in all the land.",
        stat_mods=StatModifiers(str=-2, dex=2, int=1, vit=0, wis=1, luk=5),
        passives=(
            RacialPassive(
                name="Fortune's Favour",
                description="Drop rate from all sources increased by 25%.",
                trigger="on_loot",
                effect_key="drop_rate_multiplier",
                magnitude=1.25,
            ),
            RacialPassive(
                name="Nimble",
                description="15% chance to avoid any trap or environmental hazard.",
                trigger="on_trap",
                effect_key="trap_dodge_chance",
                magnitude=0.15,
            ),
        ),
        drop_rate=1.25,
        start_zone="the_burrows",
    ),

    "dragonborn": Race(
        key="dragonborn",
        display_name="Dragonborn",
        icon="🐉",
        lore="Descendant of ancient dragons. Feared by enemies, respected by allies.",
        stat_mods=StatModifiers(str=3, dex=0, int=2, vit=2, wis=0, luk=-1),
        passives=(
            RacialPassive(
                name="Draconic Breath",
                description="Active: Deal 150% STR as fire damage to all enemies (3-turn cooldown).",
                trigger="on_action",
                effect_key="dragonbreath_aoe",
                magnitude=1.50,
            ),
            RacialPassive(
                name="Scale Armor",
                description="Natural 10% resistance to fire and ice damage.",
                trigger="on_elemental_damage_received",
                effect_key="elemental_resistance",
                magnitude=0.10,
            ),
        ),
        hp_bonus=25,
        mp_bonus=25,
        start_zone="dragon_roost",
    ),

    "undead": Race(
        key="undead",
        display_name="Undead",
        icon="💀",
        lore="Neither alive nor dead. The undead fear nothing — for they have already died.",
        stat_mods=StatModifiers(str=1, dex=0, int=2, vit=-2, wis=3, luk=-3),
        passives=(
            RacialPassive(
                name="Undying",
                description="Death Penalty copper loss reduced by 50%.",
                trigger="on_death",
                effect_key="death_penalty_reduction",
                magnitude=0.50,
            ),
            RacialPassive(
                name="Cannibalize",
                description="Consume a fallen enemy to restore 15% HP out of combat.",
                trigger="on_post_combat",
                effect_key="hp_restore_pct",
                magnitude=0.15,
            ),
        ),
        start_zone="crypt_of_shadows",
    ),

    "fae": Race(
        key="fae",
        display_name="Fae",
        icon="🧚",
        lore="Mischievous and elusive. Fae exist between worlds — hard to catch, harder to kill.",
        stat_mods=StatModifiers(str=-3, dex=4, int=3, vit=-2, wis=2, luk=4),
        passives=(
            RacialPassive(
                name="Phase Shift",
                description="20% chance to phase through a direct attack entirely.",
                trigger="on_direct_attack_received",
                effect_key="phase_dodge_chance",
                magnitude=0.20,
            ),
            RacialPassive(
                name="Fairy Dust",
                description="Healing spells cast on self are 25% more effective.",
                trigger="on_self_heal",
                effect_key="self_heal_multiplier",
                magnitude=1.25,
            ),
        ),
        mp_bonus=75,
        drop_rate=1.10,
        start_zone="veil_crossing",
    ),
}

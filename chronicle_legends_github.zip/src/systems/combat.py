"""
combat.py — Chronicle Legends MMORPG Bot
Combat Engine: Turn-based, passive triggers, monster system, death handling

Features:
  - Fully stat-driven damage formula
  - Racial passive trigger system
  - Admin-created custom monsters (with photo support)
  - Death penalty integration
  - Status effects (poison, stun, burn, freeze)
"""

from __future__ import annotations
import asyncio
import random
import math
import logging
from dataclasses import dataclass, field
from typing import Optional, Any
from enum import Enum

from economy import Currency, render_status_bar, render_bar
from races import RACES, RacialPassive

log = logging.getLogger("combat")


# ─────────────────────────────────────────────
# ENUMS & CONSTANTS
# ─────────────────────────────────────────────

class DamageType(str, Enum):
    PHYSICAL  = "physical"
    FIRE      = "fire"
    ICE       = "ice"
    LIGHTNING = "lightning"
    DARK      = "dark"
    HOLY      = "holy"
    POISON    = "poison"

class StatusEffect(str, Enum):
    POISON  = "poison"   # DoT each turn
    STUN    = "stun"     # Skip turn
    BURN    = "burn"     # DoT + reduced defense
    FREEZE  = "freeze"   # Skip turn + increased damage taken
    BLEED   = "bleed"    # DoT scales with missing HP
    BERSERK = "berserk"  # +50% ATK, -30% DEF

BASE_CRIT_CHANCE  = 0.05   # 5% base
BASE_DODGE_CHANCE = 0.03   # 3% base
CRIT_MULTIPLIER   = 1.75


# ─────────────────────────────────────────────
# MONSTER DEFINITION  (DB-backed, admin-created)
# ─────────────────────────────────────────────

@dataclass
class MonsterDefinition:
    """
    Represents a monster template as stored in the DB.
    Admins can create these via /admin_create_monster with a photo upload.
    """
    id:             int
    name:           str
    description:    str
    icon_emoji:     str
    photo_file_id:  Optional[str]     # Telegram file_id for admin-uploaded photo
    zone:           str

    # Combat stats
    level:          int
    hp_max:         int
    atk:            int               # Base attack power
    def_:           int               # Defense (damage reduction)
    spd:            int               # Speed (turn order)
    magic_res:      float = 0.0       # 0.0–1.0
    phys_res:       float = 0.0

    # Loot & rewards
    xp_reward:      int = 10
    copper_min:     int = 0
    copper_max:     int = 0
    loot_table:     list = field(default_factory=list)
    # [{"item_def_id": 3, "chance": 0.10, "qty_min": 1, "qty_max": 2}]

    # Behaviour
    abilities:      list = field(default_factory=list)
    # [{"name": "Fireball", "damage_mult": 1.8, "type": "fire", "cooldown": 3}]

    is_boss:        bool = False
    is_active:      bool = True
    created_by:     Optional[int] = None   # Admin user_id

    def stat_block(self) -> str:
        bar = render_bar(self.hp_max, self.hp_max)
        return (
            f"{'👑 BOSS: ' if self.is_boss else ''}{self.icon_emoji} **{self.name}**\n"
            f"📍 Zone: {self.zone.replace('_', ' ').title()}  |  LVL {self.level}\n"
            f"❤️ HP: [{bar}] {self.hp_max:,}\n"
            f"⚔️ ATK: {self.atk}  🛡️ DEF: {self.def_}  💨 SPD: {self.spd}\n"
            f"🔥 Magic Res: {int(self.magic_res*100)}%  "
            f"🗡️ Phys Res: {int(self.phys_res*100)}%\n"
            f"✨ XP: {self.xp_reward:,}  💰 {self.copper_min}–{self.copper_max}c"
        )


# ─────────────────────────────────────────────
# LIVE COMBAT INSTANCE
# ─────────────────────────────────────────────

@dataclass
class Combatant:
    """Snapshot of a player or monster during a fight."""
    id:             Any               # user_id (int) or monster name (str)
    name:           str
    is_player:      bool
    hp:             int
    hp_max:         int
    atk:            int
    def_:           int
    spd:            int
    race:           Optional[str]     # Only for players
    status_effects: dict = field(default_factory=dict)
    # {"poison": {"stacks": 2, "turns_left": 3}, ...}
    temp_buffs:     dict = field(default_factory=dict)
    # {"str_bonus": 4, "kill_stack_str": 2}

    @property
    def is_alive(self) -> bool:
        return self.hp > 0

    def take_damage(self, amount: int, dtype: DamageType = DamageType.PHYSICAL) -> int:
        """Apply damage, return actual damage dealt."""
        actual = max(1, amount)
        self.hp = max(0, self.hp - actual)
        return actual

    def heal(self, amount: int) -> int:
        healed = min(amount, self.hp_max - self.hp)
        self.hp += healed
        return healed

    def apply_status(self, effect: StatusEffect, turns: int = 3, stacks: int = 1):
        key = effect.value
        if key in self.status_effects:
            self.status_effects[key]["turns_left"] = max(
                self.status_effects[key]["turns_left"], turns
            )
            self.status_effects[key]["stacks"] = min(
                self.status_effects[key].get("stacks", 1) + stacks, 5
            )
        else:
            self.status_effects[key] = {"turns_left": turns, "stacks": stacks}

    def tick_status_effects(self) -> list[str]:
        """Advance all DoTs. Returns list of event strings."""
        events = []
        expired = []
        for key, data in self.status_effects.items():
            if key == StatusEffect.POISON.value:
                dmg = 5 * data["stacks"]
                self.hp = max(0, self.hp - dmg)
                events.append(f"☠️ {self.name} takes {dmg} poison damage!")
            elif key == StatusEffect.BURN.value:
                dmg = 8 * data["stacks"]
                self.hp = max(0, self.hp - dmg)
                events.append(f"🔥 {self.name} takes {dmg} burn damage!")
            elif key == StatusEffect.BLEED.value:
                missing = self.hp_max - self.hp
                dmg = max(3, int(missing * 0.05) * data["stacks"])
                self.hp = max(0, self.hp - dmg)
                events.append(f"🩸 {self.name} bleeds for {dmg} damage!")

            data["turns_left"] -= 1
            if data["turns_left"] <= 0:
                expired.append(key)
                events.append(f"✨ {self.name}'s {key} wore off.")

        for k in expired:
            del self.status_effects[k]
        return events

    def hp_bar(self, length: int = 8) -> str:
        return render_bar(self.hp, self.hp_max, length)


# ─────────────────────────────────────────────
# DAMAGE FORMULA ENGINE
# ─────────────────────────────────────────────

class DamageEngine:
    """Pure functions for damage calculation."""

    @staticmethod
    def calc_physical(
        atk: int,
        str_bonus: int,
        defender_def: int,
        phys_res: float = 0.0,
        crit_chance: float = BASE_CRIT_CHANCE,
        luk_bonus: int = 0,
    ) -> tuple[int, bool]:
        """
        Returns (damage, is_crit).
        Formula: base = ATK + STR*1.5, then reduced by DEF and resistance.
        """
        base     = atk + int(str_bonus * 1.5)
        variance = random.uniform(0.9, 1.1)
        raw      = int(base * variance)

        # Defense reduction (diminishing returns curve)
        reduction = defender_def / (defender_def + 100)
        after_def = int(raw * (1 - reduction))

        # Physical resistance
        after_res = int(after_def * (1 - phys_res))

        # Crit check
        actual_crit = min(0.75, crit_chance + luk_bonus * 0.002)
        is_crit = random.random() < actual_crit
        final = int(after_res * CRIT_MULTIPLIER) if is_crit else after_res

        return max(1, final), is_crit

    @staticmethod
    def calc_magic(
        spell_power: int,
        int_bonus: int,
        magic_res: float = 0.0,
        dtype: DamageType = DamageType.FIRE,
    ) -> int:
        base = spell_power + int(int_bonus * 2.0)
        variance = random.uniform(0.85, 1.15)
        raw = int(base * variance)
        return max(1, int(raw * (1 - magic_res)))

    @staticmethod
    def calc_dodge(dex: int, spd_diff: int) -> bool:
        chance = BASE_DODGE_CHANCE + dex * 0.003 + spd_diff * 0.001
        return random.random() < min(0.60, chance)


# ─────────────────────────────────────────────
# PASSIVE EFFECT REGISTRY
# ─────────────────────────────────────────────

class PassiveRegistry:
    """
    Maps effect_key strings (from RacialPassive.effect_key) to handler functions.
    Handlers receive (combatant, context_dict) and return a modified context_dict.
    """
    _handlers: dict[str, callable] = {}

    @classmethod
    def register(cls, key: str):
        def decorator(fn):
            cls._handlers[key] = fn
            return fn
        return decorator

    @classmethod
    def trigger(cls, effect_key: str, combatant: Combatant,
                context: dict, magnitude: float) -> dict:
        handler = cls._handlers.get(effect_key)
        if handler:
            return handler(combatant, context, magnitude)
        return context


@PassiveRegistry.register("xp_multiplier")
def passive_xp_mult(c, ctx, mag):
    ctx["xp"] = int(ctx.get("xp", 0) * mag)
    return ctx

@PassiveRegistry.register("str_per_kill_stack")
def passive_blood_fury(c, ctx, mag):
    stacks = c.temp_buffs.get("kill_stack_str", 0)
    if stacks < 10:
        c.temp_buffs["kill_stack_str"] = stacks + int(mag)
    return ctx

@PassiveRegistry.register("flat_physical_reduction")
def passive_thick_hide(c, ctx, mag):
    ctx["damage"] = int(ctx.get("damage", 0) * (1 - mag))
    return ctx

@PassiveRegistry.register("death_penalty_reduction")
def passive_undying(c, ctx, mag):
    ctx["penalty_rate"] = ctx.get("penalty_rate", 0.10) * (1 - mag)
    return ctx

@PassiveRegistry.register("crafting_success_bonus")
def passive_master_smith(c, ctx, mag):
    ctx["success_rate"] = min(1.0, ctx.get("success_rate", 0.5) + mag)
    return ctx

@PassiveRegistry.register("spell_damage_multiplier")
def passive_arcane(c, ctx, mag):
    ctx["damage"] = int(ctx.get("damage", 0) * mag)
    return ctx

@PassiveRegistry.register("drop_rate_multiplier")
def passive_fortune(c, ctx, mag):
    ctx["drop_rate"] = ctx.get("drop_rate", 1.0) * mag
    return ctx

@PassiveRegistry.register("death_save")
def passive_stone_skin(c, ctx, mag):
    if not c.temp_buffs.get("death_save_used") and ctx.get("would_die"):
        c.hp = 1
        c.temp_buffs["death_save_used"] = True
        ctx["would_die"] = False
        ctx["events"] = ctx.get("events", []) + ["⛏️ Stone Skin activates! Survived with 1 HP!"]
    return ctx

@PassiveRegistry.register("phase_dodge_chance")
def passive_phase_shift(c, ctx, mag):
    if random.random() < mag:
        ctx["dodged"] = True
        ctx["events"] = ctx.get("events", []) + ["🧚 Phase Shift! Attack phased through!"]
    return ctx


# ─────────────────────────────────────────────
# COMBAT SESSION
# ─────────────────────────────────────────────

@dataclass
class CombatSession:
    """
    A live combat encounter between a player and a monster.
    Stored in memory (e.g. Redis or bot context) during the fight.
    """
    session_id:   str
    player:       Combatant
    monster:      Combatant
    monster_def:  MonsterDefinition
    turn:         int = 0
    log_:         list[str] = field(default_factory=list)
    is_over:      bool = False
    player_won:   bool = False

    def _log(self, msg: str):
        self.log_.append(msg)

    def _get_turn_order(self) -> tuple[Combatant, Combatant]:
        """Higher SPD goes first. Ties broken randomly."""
        if self.player.spd > self.monster.spd:
            return self.player, self.monster
        elif self.monster.spd > self.player.spd:
            return self.monster, self.player
        return (self.player, self.monster) if random.random() > 0.5 else (self.monster, self.player)

    async def execute_turn(self, player_action: str = "attack") -> dict:
        """
        Process one full round (player action + monster retaliation).
        Returns a dict with events, updated HP bars, and outcome flags.
        """
        self.turn += 1
        events = []

        # ── Status Effect Ticks ─────────────────────
        for c in [self.player, self.monster]:
            tick_events = c.tick_status_effects()
            events.extend(tick_events)

        if not self.player.is_alive or not self.monster.is_alive:
            return await self._resolve_combat(events)

        # ── Turn Order ──────────────────────────────
        first, second = self._get_turn_order()

        # ── First Attacker ──────────────────────────
        events.extend(await self._attack(first, second))
        if not second.is_alive:
            return await self._resolve_combat(events)

        # ── Second Attacker ─────────────────────────
        if StatusEffect.STUN.value not in second.status_effects and \
           StatusEffect.FREEZE.value not in second.status_effects:
            events.extend(await self._attack(second, first))

        if not first.is_alive:
            return await self._resolve_combat(events)

        return {
            "turn": self.turn,
            "events": events,
            "player_hp": self.player.hp,
            "player_hp_max": self.player.hp_max,
            "monster_hp": self.monster.hp,
            "monster_hp_max": self.monster.hp_max,
            "player_bar": self.player.hp_bar(),
            "monster_bar": self.monster.hp_bar(),
            "is_over": False,
        }

    async def _attack(self, attacker: Combatant, defender: Combatant) -> list[str]:
        events = []
        ctx = {"damage": 0, "dodged": False, "events": []}

        # Dodge check (defender passives)
        if defender.is_player and defender.race:
            race = RACES.get(defender.race)
            if race:
                for passive in race.get_passive("on_direct_attack_received"):
                    ctx = PassiveRegistry.trigger(passive.effect_key, defender, ctx, passive.magnitude)

        if ctx.get("dodged"):
            events.extend(ctx.get("events", []))
            events.append(f"💨 {defender.name} dodged the attack!")
            return events

        # Dodge formula check
        spd_diff = attacker.spd - defender.spd
        if defender.is_player and DamageEngine.calc_dodge(
            getattr(defender, 'dex', 10), spd_diff
        ):
            events.append(f"💨 {defender.name} narrowly dodges!")
            return events

        # Calculate damage
        str_bonus = attacker.temp_buffs.get("kill_stack_str", 0)
        damage, is_crit = DamageEngine.calc_physical(
            attacker.atk, str_bonus,
            defender.def_, defender.monster_def.phys_res if not defender.is_player else 0.0
        )

        # Attacker passives (e.g. spell_damage_multiplier)
        if attacker.is_player and attacker.race:
            race = RACES.get(attacker.race)
            if race:
                ctx["damage"] = damage
                for passive in race.get_passive("on_physical_attack"):
                    ctx = PassiveRegistry.trigger(passive.effect_key, attacker, ctx, passive.magnitude)
                damage = ctx.get("damage", damage)

        # Defender passives (e.g. thick_hide)
        if defender.is_player and defender.race:
            race = RACES.get(defender.race)
            if race:
                ctx["damage"] = damage
                for passive in race.get_passive("on_physical_damage_received"):
                    ctx = PassiveRegistry.trigger(passive.effect_key, defender, ctx, passive.magnitude)
                damage = ctx.get("damage", damage)

        # Death save check (Dwarf passive)
        ctx["would_die"] = damage >= defender.hp
        if defender.is_player and defender.race:
            race = RACES.get(defender.race)
            if race:
                for passive in race.get_passive("on_lethal_damage"):
                    ctx = PassiveRegistry.trigger(passive.effect_key, defender, ctx, passive.magnitude)

        if not ctx.get("would_die", True) or defender.hp > damage:
            actual = defender.take_damage(damage)
            crit_str = " 💥 CRITICAL!" if is_crit else ""
            events.append(
                f"⚔️ {attacker.name} hits {defender.name} for **{actual}** dmg!{crit_str}"
            )
        else:
            events.extend(ctx.get("events", []))
            if not ctx.get("would_die") is False:
                actual = defender.take_damage(damage)
                events.append(f"⚔️ {attacker.name} hits {defender.name} for **{actual}** dmg!")

        # Monster ability check
        if not attacker.is_player and self.monster_def.abilities:
            events.extend(self._try_monster_ability(attacker, defender))

        return events

    def _try_monster_ability(self, monster: Combatant, target: Combatant) -> list[str]:
        events = []
        for ability in self.monster_def.abilities:
            cooldown_key = f"ability_cd_{ability['name']}"
            cd = monster.temp_buffs.get(cooldown_key, 0)
            if cd > 0:
                monster.temp_buffs[cooldown_key] = cd - 1
                continue
            if random.random() < 0.30:   # 30% chance to use any ready ability
                dmg = int(monster.atk * ability.get("damage_mult", 1.0))
                actual = target.take_damage(dmg)
                monster.temp_buffs[cooldown_key] = ability.get("cooldown", 3)
                events.append(
                    f"💢 {monster.name} uses **{ability['name']}** for {actual} "
                    f"{ability.get('type', 'physical')} damage!"
                )
                break
        return events

    async def _resolve_combat(self, events: list[str]) -> dict:
        self.is_over = True
        self.player_won = self.player.is_alive

        if self.player_won:
            loot = self._roll_loot()
            xp = self.monster_def.xp_reward
            copper = random.randint(self.monster_def.copper_min, max(self.monster_def.copper_min, self.monster_def.copper_max))
            events.append(f"\n🏆 **Victory!** {self.monster.name} defeated!")
            events.append(f"✨ +{xp} XP  |  💰 +{copper}c")
            if loot:
                events.append(f"🎁 Loot: {', '.join(loot)}")
            return {
                "is_over": True, "player_won": True,
                "events": events, "xp": xp, "copper": copper, "loot": loot,
                "player_hp": self.player.hp, "player_hp_max": self.player.hp_max,
                "monster_hp": 0, "monster_hp_max": self.monster.hp_max,
            }
        else:
            events.append(f"\n💀 **Defeated!** You were slain by {self.monster.name}.")
            events.append("⚠️ Death penalty: 10% of your wallet was lost.")
            return {
                "is_over": True, "player_won": False,
                "events": events, "xp": 0, "copper": 0, "loot": [],
                "player_hp": 0, "player_hp_max": self.player.hp_max,
                "monster_hp": self.monster.hp, "monster_hp_max": self.monster.hp_max,
            }

    def _roll_loot(self) -> list[str]:
        drops = []
        for entry in self.monster_def.loot_table:
            if random.random() < entry.get("chance", 0):
                qty = random.randint(
                    entry.get("qty_min", 1),
                    entry.get("qty_max", 1)
                )
                drops.append(f"Item#{entry['item_def_id']}×{qty}")
        return drops

    def render_combat_screen(self) -> str:
        """Full combat HUD for display after each action."""
        photo_note = f"\n📸 [Monster Image: {self.monster_def.name}]" if self.monster_def.photo_file_id else ""
        return (
            f"═══════════════════════════\n"
            f"{self.monster_def.icon_emoji} **{self.monster.name}** (LVL {self.monster_def.level}){photo_note}\n"
            f"❤️ [{self.monster.hp_bar()}] {self.monster.hp}/{self.monster.hp_max}\n"
            f"{''.join(f'[{k}×{v[\"stacks\"]}]' for k,v in self.monster.status_effects.items())}\n"
            f"───────────────────────────\n"
            f"👤 **{self.player.name}**\n"
            f"❤️ [{self.player.hp_bar()}] {self.player.hp}/{self.player.hp_max}\n"
            f"{''.join(f'[{k}×{v[\"stacks\"]}]' for k,v in self.player.status_effects.items())}\n"
            f"═══════════════════════════\n"
            f"Turn {self.turn} | Actions: ⚔️ /attack  🛡️ /defend  🧪 /use_item  🏃 /flee"
        )

"""
guild.py — Chronicle Legends MMORPG Bot
Guild System: Creation, Ranks, Vault, Leveling Perks
"""
from __future__ import annotations
import asyncpg
import logging
from economy import Currency, format_currency

log = logging.getLogger("guild")

GUILD_CREATE_COST = Currency.from_parts(gold=50)   # 50g to create a guild
GUILD_PERKS = {
    1: {"xp_boost": 0.0,  "discount": 0.0,  "vault_cap": 100_000_000},       # 1p
    2: {"xp_boost": 0.02, "discount": 0.0,  "vault_cap": 500_000_000},
    3: {"xp_boost": 0.05, "discount": 0.02, "vault_cap": 1_000_000_000},
    4: {"xp_boost": 0.08, "discount": 0.03, "vault_cap": 5_000_000_000},
    5: {"xp_boost": 0.12, "discount": 0.05, "vault_cap": 10_000_000_000},
}

class GuildService:
    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def create(self, leader_id: int, name: str, tag: str) -> str:
        tag = tag.upper()[:6]
        if len(name) < 3:
            return "❌ Guild name must be at least 3 characters."

        async with self._pool.acquire() as conn:
            async with conn.transaction():
                # Check user has no guild and can afford it
                user = await conn.fetchrow(
                    "SELECT display_name, wallet_copper, guild_id FROM users WHERE id=$1 FOR UPDATE",
                    leader_id
                )
                if user["guild_id"]:
                    return "❌ You're already in a guild. Leave first."
                if user["wallet_copper"] < GUILD_CREATE_COST.copper:
                    return f"❌ Creating a guild costs {GUILD_CREATE_COST.format()}."

                existing = await conn.fetchval(
                    "SELECT id FROM guilds WHERE name ILIKE $1 OR tag ILIKE $2", name, tag
                )
                if existing:
                    return "❌ Guild name or tag already taken."

                guild_id = await conn.fetchval(
                    "INSERT INTO guilds (name, tag, leader_id) VALUES ($1,$2,$3) RETURNING id",
                    name, tag, leader_id
                )
                await conn.execute(
                    "UPDATE users SET guild_id=$1, wallet_copper=wallet_copper-$2 WHERE id=$3",
                    guild_id, GUILD_CREATE_COST.copper, leader_id
                )
                await conn.execute(
                    "INSERT INTO guild_members (guild_id, user_id, rank) VALUES ($1,$2,'leader')",
                    guild_id, leader_id
                )

        return (
            f"🏰 **Guild Created!**\n"
            f"**[{tag}] {name}**\n"
            f"💰 Creation cost: {GUILD_CREATE_COST.format()}\n"
            f"Use /guild_invite to recruit members!"
        )

    async def deposit_vault(self, user_id: int, amount: Currency) -> str:
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                member = await conn.fetchrow(
                    "SELECT gm.guild_id FROM guild_members gm WHERE gm.user_id=$1", user_id
                )
                if not member:
                    return "❌ You're not in a guild."
                guild_id = member["guild_id"]

                r = await conn.execute(
                    "UPDATE users SET wallet_copper=wallet_copper-$1 WHERE id=$2 AND wallet_copper>=$1",
                    amount.copper, user_id
                )
                if r == "UPDATE 0":
                    return f"❌ Insufficient funds."

                await conn.execute(
                    "UPDATE guilds SET vault_copper=vault_copper+$1 WHERE id=$2",
                    amount.copper, guild_id
                )
                await conn.execute(
                    "UPDATE guild_members SET contribution=contribution+$1 WHERE guild_id=$2 AND user_id=$3",
                    amount.copper, guild_id, user_id
                )
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, guild_id, amount_copper, description)
                       VALUES ('guild_deposit', $1, $2, $3, 'Guild vault deposit')""",
                    user_id, guild_id, amount.copper
                )
        return f"🏦 Deposited **{amount.format()}** into the guild vault."

    async def withdraw_vault(self, user_id: int, amount: Currency) -> str:
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                member = await conn.fetchrow(
                    """SELECT gm.guild_id, gm.rank FROM guild_members gm WHERE gm.user_id=$1""",
                    user_id
                )
                if not member:
                    return "❌ You're not in a guild."
                if member["rank"] not in ("officer", "co_leader", "leader"):
                    return "❌ Only Officers+ can withdraw from the vault."

                r = await conn.execute(
                    "UPDATE guilds SET vault_copper=vault_copper-$1 WHERE id=$2 AND vault_copper>=$1",
                    amount.copper, member["guild_id"]
                )
                if r == "UPDATE 0":
                    return "❌ Insufficient guild vault funds."

                await conn.execute(
                    "UPDATE users SET wallet_copper=wallet_copper+$1 WHERE id=$2",
                    amount.copper, user_id
                )
        return f"✅ Withdrew **{amount.format()}** from guild vault."

    async def guild_info(self, guild_id: int) -> str:
        async with self._pool.acquire() as conn:
            guild = await conn.fetchrow("SELECT * FROM guilds WHERE id=$1", guild_id)
            if not guild:
                return "❌ Guild not found."
            members = await conn.fetch(
                """SELECT u.display_name, gm.rank, gm.contribution
                   FROM guild_members gm JOIN users u ON gm.user_id=u.id
                   WHERE gm.guild_id=$1 ORDER BY gm.rank DESC, gm.contribution DESC""",
                guild_id
            )
            perks = GUILD_PERKS.get(guild["level"], GUILD_PERKS[1])

        member_str = "\n".join(
            f"  {'👑' if m['rank']=='leader' else '⭐' if m['rank'] in ('officer','co_leader') else '·'} "
            f"{m['display_name']} [{m['rank']}]"
            for m in members[:10]
        )
        return (
            f"🏰 **[{guild['tag']}] {guild['name']}**\n"
            f"Level {guild['level']}  |  {len(members)}/{guild['max_members']} members\n"
            f"🏦 Vault: {format_currency(guild['vault_copper'])}\n"
            f"⚡ Perks: +{int(perks['xp_boost']*100)}% XP | "
            f"{int(perks['discount']*100)}% shop discount\n\n"
            f"**Members:**\n{member_str}"
        )

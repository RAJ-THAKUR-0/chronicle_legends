"""
inventory.py — Chronicle Legends MMORPG Bot
Inventory Management, Equipment System, Banking

Features:
  - Equip/unequip with slot validation
  - Weight limits (STR-based carry capacity)
  - Item inspection with full stat display
  - Bank deposit/withdraw (protected from death penalty)
  - Admin /give_item command handler
"""

from __future__ import annotations
import uuid
import logging
from dataclasses import dataclass, field
from typing import Optional, Any
import asyncpg

from economy import Currency, format_currency

log = logging.getLogger("inventory")

# ─────────────────────────────────────────────
# RARITY CONFIG
# ─────────────────────────────────────────────

RARITY_CONFIG = {
    "common":   {"color": "⚪", "mult": 1.0,   "label": "Common"},
    "uncommon": {"color": "🟢", "mult": 1.5,   "label": "Uncommon"},
    "rare":     {"color": "🔵", "mult": 3.0,   "label": "Rare"},
    "epic":     {"color": "🟣", "mult": 6.0,   "label": "Epic"},
    "legendary":{"color": "🟠", "mult": 15.0,  "label": "Legendary"},
    "mythic":   {"color": "🔴", "mult": 50.0,  "label": "Mythic"},
    "ancient":  {"color": "🌟", "mult": 150.0, "label": "Ancient"},
}

SLOT_EMOJI = {
    "head": "🪖", "chest": "🦺", "legs": "👖", "feet": "👢",
    "hands": "🧤", "mainhand": "⚔️", "offhand": "🛡️",
    "ring": "💍", "amulet": "📿", "consumable": "🧪",
    "material": "🪨", "quest": "📜", "none": "📦",
}

MAX_INVENTORY_SLOTS = 50
BASE_CARRY_WEIGHT   = 50.0    # kg at STR 10
WEIGHT_PER_STR      = 2.5     # +2.5 kg per STR above 10


# ─────────────────────────────────────────────
# ITEM INSTANCE
# ─────────────────────────────────────────────

@dataclass
class ItemInstance:
    """A player-owned item. Maps to inventory_items table."""
    uid:            str
    owner_id:       int
    item_def_id:    int
    name:           str
    description:    str
    category:       str
    slot:           str
    rarity:         str
    weight:         float
    base_value:     int         # Copper
    is_tradeable:   bool
    is_bankable:    bool
    is_stackable:   bool
    max_stack:      int
    icon_emoji:     str
    stat_bonuses:   dict        # {"str": 3, "dex": 1, ...}
    req_level:      int
    quantity:       int = 1
    is_equipped:    bool = False
    is_locked:      bool = False
    custom_name:    Optional[str] = None
    custom_stats:   dict = field(default_factory=dict)
    durability:     int = 100
    stored_in_bank: bool = False

    @property
    def display_name(self) -> str:
        return self.custom_name or self.name

    @property
    def rarity_icon(self) -> str:
        return RARITY_CONFIG.get(self.rarity, {}).get("color", "⚪")

    @property
    def slot_icon(self) -> str:
        return SLOT_EMOJI.get(self.slot, "📦")

    @property
    def sell_value(self) -> Currency:
        """NPC sell value = 30% of base_value × rarity multiplier."""
        mult = RARITY_CONFIG.get(self.rarity, {}).get("mult", 1.0)
        return Currency.from_copper(int(self.base_value * mult * 0.30))

    @property
    def merchant_value(self) -> Currency:
        """Black Market / Merchant value = 55% of base_value × rarity mult."""
        mult = RARITY_CONFIG.get(self.rarity, {}).get("mult", 1.0)
        return Currency.from_copper(int(self.base_value * mult * 0.55))

    @property
    def total_stats(self) -> dict:
        """Merge base stat_bonuses with custom_stats."""
        merged = dict(self.stat_bonuses)
        for k, v in self.custom_stats.items():
            merged[k] = merged.get(k, 0) + v
        return merged

    @property
    def total_weight(self) -> float:
        return self.weight * self.quantity

    def card(self, show_uid: bool = False) -> str:
        """Full item inspect card."""
        rarity_cfg = RARITY_CONFIG.get(self.rarity, {})
        stats_str = "  ".join(
            f"+{v} {k.upper()}" if v > 0 else f"{v} {k.upper()}"
            for k, v in self.total_stats.items() if v != 0
        ) or "No stat bonuses"

        dur_bar = "█" * (self.durability // 10) + "░" * (10 - self.durability // 10)
        lines = [
            f"{self.rarity_icon} {self.slot_icon} **{self.display_name}**",
            f"_{rarity_cfg.get('label', 'Common')} {self.category.replace('_',' ').title()}_",
            f"",
            f"📊 {stats_str}",
            f"⚖️ Weight: {self.weight}kg  |  Req LVL: {self.req_level}",
            f"🔧 Durability: [{dur_bar}] {self.durability}%",
            f"",
            f"💰 Sell: {self.sell_value.format()}  |  "
            f"🏪 Merchant: {self.merchant_value.format()}",
        ]
        if self.is_equipped: lines.append("✅ Currently equipped")
        if self.is_locked:   lines.append("🔒 Locked (won't be sold accidentally)")
        if show_uid:         lines.append(f"🔑 UID: `{self.uid[:8]}...`")
        if self.description: lines.insert(2, f"_{self.description}_")
        return "\n".join(lines)


# ─────────────────────────────────────────────
# INVENTORY SERVICE
# ─────────────────────────────────────────────

class InventoryService:
    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    # ── Fetching ────────────────────────────────

    async def get_inventory(
        self, user_id: int, include_bank: bool = False
    ) -> list[ItemInstance]:
        query = """
            SELECT i.*, d.name, d.description, d.category, d.slot, d.rarity,
                   d.weight, d.base_value, d.is_tradeable, d.is_bankable,
                   d.is_stackable, d.max_stack, d.icon_emoji,
                   d.stat_bonuses, d.req_level
            FROM inventory_items i
            JOIN item_definitions d ON i.item_def_id = d.id
            WHERE i.owner_id = $1
              AND i.stored_in_bank = $2
            ORDER BY d.rarity DESC, d.name
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, user_id, include_bank)
        return [self._row_to_item(r) for r in rows]

    async def get_equipped(self, user_id: int) -> list[ItemInstance]:
        query = """
            SELECT i.*, d.name, d.description, d.category, d.slot, d.rarity,
                   d.weight, d.base_value, d.is_tradeable, d.is_bankable,
                   d.is_stackable, d.max_stack, d.icon_emoji,
                   d.stat_bonuses, d.req_level
            FROM inventory_items i
            JOIN item_definitions d ON i.item_def_id = d.id
            WHERE i.owner_id = $1 AND i.is_equipped = TRUE
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, user_id)
        return [self._row_to_item(r) for r in rows]

    async def get_item_by_uid(self, uid: str) -> Optional[ItemInstance]:
        query = """
            SELECT i.*, d.name, d.description, d.category, d.slot, d.rarity,
                   d.weight, d.base_value, d.is_tradeable, d.is_bankable,
                   d.is_stackable, d.max_stack, d.icon_emoji,
                   d.stat_bonuses, d.req_level
            FROM inventory_items i
            JOIN item_definitions d ON i.item_def_id = d.id
            WHERE i.id = $1
        """
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(query, uid)
        return self._row_to_item(row) if row else None

    # ── Equipment ───────────────────────────────

    async def equip(self, user_id: int, item_uid: str, user_level: int) -> str:
        """Equip an item. Unequips existing item in same slot."""
        item = await self.get_item_by_uid(item_uid)
        if not item or item.owner_id != user_id:
            return "❌ Item not found in your inventory."
        if item.stored_in_bank:
            return "❌ Withdraw item from bank first."
        if item.slot in ("none", "consumable", "material", "quest"):
            return "❌ This item cannot be equipped."
        if user_level < item.req_level:
            return f"❌ Requires Level {item.req_level}."

        async with self._pool.acquire() as conn:
            async with conn.transaction():
                # Unequip existing in same slot
                await conn.execute(
                    """
                    UPDATE inventory_items i
                    SET is_equipped = FALSE
                    FROM item_definitions d
                    WHERE i.item_def_id = d.id
                      AND i.owner_id = $1
                      AND i.is_equipped = TRUE
                      AND d.slot = $2
                      AND i.id != $3
                    """,
                    user_id, item.slot, item_uid
                )
                await conn.execute(
                    "UPDATE inventory_items SET is_equipped = TRUE WHERE id = $1",
                    item_uid
                )

        return (
            f"✅ Equipped {item.rarity_icon} **{item.display_name}**\n"
            f"📊 {', '.join(f'+{v} {k.upper()}' for k,v in item.total_stats.items() if v > 0)}"
        )

    async def unequip(self, user_id: int, item_uid: str) -> str:
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE inventory_items SET is_equipped = FALSE WHERE id = $1 AND owner_id = $2",
                item_uid, user_id
            )
        if result == "UPDATE 0":
            return "❌ Item not found or not equipped."
        return "✅ Item unequipped."

    # ── Bank ────────────────────────────────────

    async def bank_deposit_currency(self, user_id: int, amount: Currency) -> str:
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                r = await conn.execute(
                    """
                    UPDATE users SET wallet_copper = wallet_copper - $1,
                                     bank_copper   = bank_copper   + $1
                    WHERE id = $2 AND wallet_copper >= $1
                    """,
                    amount.copper, user_id
                )
                if r == "UPDATE 0":
                    return f"❌ Insufficient funds. Need {amount.format()}."
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, amount_copper, description)
                       VALUES ('bank_deposit', $1, $2, 'Bank deposit')""",
                    user_id, amount.copper
                )
        return f"🏦 Deposited **{amount.format()}** into your bank account."

    async def bank_withdraw_currency(self, user_id: int, amount: Currency) -> str:
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                r = await conn.execute(
                    """
                    UPDATE users SET bank_copper   = bank_copper   - $1,
                                     wallet_copper = wallet_copper + $1
                    WHERE id = $2 AND bank_copper >= $1
                    """,
                    amount.copper, user_id
                )
                if r == "UPDATE 0":
                    return f"❌ Insufficient bank balance."
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, to_user_id, amount_copper, description)
                       VALUES ('bank_withdraw', $1, $2, 'Bank withdrawal')""",
                    user_id, amount.copper
                )
        return f"🏦 Withdrew **{amount.format()}** from your bank."

    async def bank_deposit_item(self, user_id: int, item_uid: str) -> str:
        async with self._pool.acquire() as conn:
            r = await conn.execute(
                """
                UPDATE inventory_items SET stored_in_bank = TRUE, is_equipped = FALSE
                WHERE id = $1 AND owner_id = $2 AND stored_in_bank = FALSE
                """,
                item_uid, user_id
            )
        return "🏦 Item stored in bank." if r != "UPDATE 0" else "❌ Item not found."

    async def bank_withdraw_item(self, user_id: int, item_uid: str) -> str:
        inv = await self.get_inventory(user_id)
        if len([i for i in inv if not i.stored_in_bank]) >= MAX_INVENTORY_SLOTS:
            return f"❌ Inventory full! Max {MAX_INVENTORY_SLOTS} slots."
        async with self._pool.acquire() as conn:
            r = await conn.execute(
                "UPDATE inventory_items SET stored_in_bank = FALSE WHERE id = $1 AND owner_id = $2",
                item_uid, user_id
            )
        return "✅ Item withdrawn from bank." if r != "UPDATE 0" else "❌ Item not found in bank."

    # ── Admin: Give Item ─────────────────────────

    async def admin_give_item(
        self, target_user_id: int, item_def_id: int, quantity: int, admin_id: int
    ) -> str:
        """Admin command: /give_item [user_id] [item_def_id] [qty]"""
        async with self._pool.acquire() as conn:
            # Validate item exists
            item_def = await conn.fetchrow(
                "SELECT * FROM item_definitions WHERE id = $1", item_def_id
            )
            if not item_def:
                return f"❌ Item definition #{item_def_id} not found."

            if item_def["is_stackable"]:
                # Check for existing stack
                existing = await conn.fetchrow(
                    """SELECT id, quantity FROM inventory_items
                       WHERE owner_id = $1 AND item_def_id = $2 AND stored_in_bank = FALSE
                       LIMIT 1""",
                    target_user_id, item_def_id
                )
                if existing:
                    new_qty = min(existing["quantity"] + quantity, item_def["max_stack"])
                    await conn.execute(
                        "UPDATE inventory_items SET quantity = $1 WHERE id = $2",
                        new_qty, existing["id"]
                    )
                    return (
                        f"✅ Admin gave {quantity}× **{item_def['name']}** "
                        f"to user `{target_user_id}`."
                    )

            # Create new instance
            await conn.execute(
                """
                INSERT INTO inventory_items
                  (id, owner_id, item_def_id, quantity)
                VALUES ($1, $2, $3, $4)
                """,
                str(uuid.uuid4()), target_user_id, item_def_id, quantity
            )

        return (
            f"✅ Admin gave {quantity}× **{item_def['name']}** "
            f"({item_def['rarity']}) to user `{target_user_id}`."
        )

    # ── Inventory Display ────────────────────────

    async def render_inventory(self, user_id: int) -> str:
        items = await self.get_inventory(user_id)
        if not items:
            return "🎒 Your inventory is empty."

        total_weight = sum(i.total_weight for i in items)
        lines = [f"🎒 **Inventory** ({len(items)}/{MAX_INVENTORY_SLOTS} slots | {total_weight:.1f}kg)\n"]

        equipped = [i for i in items if i.is_equipped]
        unequipped = [i for i in items if not i.is_equipped]

        if equipped:
            lines.append("**— Equipped —**")
            for item in equipped:
                lines.append(
                    f"{item.rarity_icon}{item.slot_icon} {item.display_name} "
                    f"[{item.rarity}] {'🔒' if item.is_locked else ''}"
                )

        if unequipped:
            lines.append("\n**— Bag —**")
            for item in unequipped:
                qty = f"×{item.quantity}" if item.quantity > 1 else ""
                lines.append(
                    f"{item.rarity_icon}{item.slot_icon} {item.display_name}{qty} "
                    f"[{item.rarity}] {'🔒' if item.is_locked else ''}"
                )

        lines.append(f"\n_Use /inspect [item_name] for details | /equip [item] to equip_")
        return "\n".join(lines)

    # ── Internal ────────────────────────────────

    def _row_to_item(self, row: asyncpg.Record) -> ItemInstance:
        import json
        stat_bonuses = row["stat_bonuses"]
        if isinstance(stat_bonuses, str):
            stat_bonuses = json.loads(stat_bonuses)
        custom_stats = row.get("custom_stats", {})
        if isinstance(custom_stats, str):
            custom_stats = json.loads(custom_stats)

        return ItemInstance(
            uid=str(row["id"]),
            owner_id=row["owner_id"],
            item_def_id=row["item_def_id"],
            name=row["name"],
            description=row.get("description", ""),
            category=row["category"],
            slot=row["slot"],
            rarity=row["rarity"],
            weight=float(row["weight"]),
            base_value=row["base_value"],
            is_tradeable=row["is_tradeable"],
            is_bankable=row["is_bankable"],
            is_stackable=row["is_stackable"],
            max_stack=row["max_stack"],
            icon_emoji=row["icon_emoji"],
            stat_bonuses=stat_bonuses or {},
            req_level=row["req_level"],
            quantity=row["quantity"],
            is_equipped=row["is_equipped"],
            is_locked=row["is_locked"],
            custom_name=row.get("custom_name"),
            custom_stats=custom_stats or {},
            durability=row["durability"],
            stored_in_bank=row["stored_in_bank"],
        )

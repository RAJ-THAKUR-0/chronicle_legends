"""
market.py — Chronicle Legends MMORPG Bot
Three-Tier Market System:

1. 🏪 PLAYER MARKET    — Buy/Sell board. Fair prices. 5% tax.
2. 🛒 MERCHANT MARKET  — NPC buys/sells. Mid value (~55%). Instant.
3. 🌑 BLACK MARKET     — No tax, no records, lower prices (40%).
                         High risk items, stolen goods, rare contraband.
"""

from __future__ import annotations
import asyncpg
import asyncio
import logging
import random
from dataclasses import dataclass
from typing import Optional
from datetime import datetime, timedelta

from economy import Currency, format_currency, MARKET_TAX_RATE

log = logging.getLogger("market")

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

PLAYER_MARKET_TAX    = 0.05    # 5% of sale price kept by system
MERCHANT_VALUE_RATE  = 0.55    # NPC pays 55% of base value
MERCHANT_SELL_RATE   = 1.20    # NPC sells at 120% of base value
BLACK_MARKET_RATE    = 0.40    # Black market pays only 40%
BLACK_MARKET_BUY     = 0.85    # Black market sells at 85% (cheaper but risky)
LISTING_DURATION_DAYS = 7


# ─────────────────────────────────────────────
# DATA CLASSES
# ─────────────────────────────────────────────

@dataclass
class MarketListing:
    id:           int
    seller_id:    int
    seller_name:  str
    item_uid:     str
    item_name:    str
    item_rarity:  str
    item_icon:    str
    quantity:     int
    price_copper: int
    tax_rate:     float
    listed_at:    datetime
    expires_at:   datetime

    @property
    def price(self) -> Currency:
        return Currency.from_copper(self.price_copper)

    @property
    def price_per_unit(self) -> Currency:
        return Currency.from_copper(self.price_copper // max(1, self.quantity))

    def card(self) -> str:
        from inventory import RARITY_CONFIG
        rarity_icon = RARITY_CONFIG.get(self.item_rarity, {}).get("color", "⚪")
        days_left = (self.expires_at - datetime.utcnow()).days
        return (
            f"{rarity_icon} **{self.item_name}** ×{self.quantity}\n"
            f"💰 {self.price.format()}  ({self.price_per_unit.format()}/ea)\n"
            f"👤 {self.seller_name}  |  ⏳ {days_left}d left\n"
            f"📋 ID: #{self.id}"
        )


# ─────────────────────────────────────────────
# PLAYER MARKET SERVICE
# ─────────────────────────────────────────────

class PlayerMarketService:
    """
    Global player-to-player auction board.
    Seller lists item → Buyer pays → System takes 5% tax → Seller gets 95%.
    """

    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def list_item(
        self,
        seller_id: int,
        item_uid: str,
        price: Currency,
        quantity: int = 1,
    ) -> str:
        """Create a new market listing."""
        if price.copper <= 0:
            return "❌ Price must be greater than 0."

        async with self._pool.acquire() as conn:
            # Verify ownership
            item = await conn.fetchrow(
                """SELECT i.id, i.owner_id, i.is_equipped, i.is_locked,
                          i.stored_in_bank, i.quantity,
                          d.name, d.is_tradeable, d.rarity, d.icon_emoji
                   FROM inventory_items i
                   JOIN item_definitions d ON i.item_def_id = d.id
                   WHERE i.id = $1""",
                item_uid
            )
            if not item:
                return "❌ Item not found."
            if item["owner_id"] != seller_id:
                return "❌ That item doesn't belong to you."
            if item["is_equipped"]:
                return "❌ Unequip the item before listing it."
            if item["is_locked"]:
                return "❌ Item is locked. Use /unlock [item] first."
            if item["stored_in_bank"]:
                return "❌ Withdraw from bank before listing."
            if not item["is_tradeable"]:
                return "❌ This item cannot be traded."
            if quantity > item["quantity"]:
                return f"❌ You only have {item['quantity']} of that item."

            async with conn.transaction():
                listing_id = await conn.fetchval(
                    """
                    INSERT INTO market_listings
                      (seller_id, item_instance_id, price_copper, quantity,
                       tax_rate, expires_at)
                    VALUES ($1, $2, $3, $4, $5, $6)
                    RETURNING id
                    """,
                    seller_id, item_uid, price.copper, quantity,
                    PLAYER_MARKET_TAX,
                    datetime.utcnow() + timedelta(days=LISTING_DURATION_DAYS)
                )

        tax_amount = Currency(int(price.copper * PLAYER_MARKET_TAX))
        net = price - tax_amount
        return (
            f"📋 Listed **{item['name']}** ×{quantity} for {price.format()}\n"
            f"💸 Tax ({int(PLAYER_MARKET_TAX*100)}%): {tax_amount.format()}  "
            f"→ You'll receive: {net.format()}\n"
            f"📌 Listing ID: #{listing_id}  |  Expires in {LISTING_DURATION_DAYS} days"
        )

    async def buy_listing(self, buyer_id: int, listing_id: int) -> str:
        """Purchase a market listing."""
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                listing = await conn.fetchrow(
                    """SELECT m.*, d.name AS item_name, d.rarity
                       FROM market_listings m
                       JOIN inventory_items i ON m.item_instance_id = i.id
                       JOIN item_definitions d ON i.item_def_id = d.id
                       WHERE m.id = $1 AND m.status = 'active'
                         AND m.expires_at > NOW()
                       FOR UPDATE""",
                    listing_id
                )
                if not listing:
                    return "❌ Listing not found, sold, or expired."
                if listing["seller_id"] == buyer_id:
                    return "❌ You cannot buy your own listing."

                price = Currency.from_copper(listing["price_copper"])

                # Check buyer funds
                buyer = await conn.fetchrow(
                    "SELECT wallet_copper FROM users WHERE id = $1 FOR UPDATE", buyer_id
                )
                if buyer["wallet_copper"] < price.copper:
                    return f"❌ Insufficient funds. Need {price.format()}."

                # Calculate tax & seller payout
                tax = Currency(int(price.copper * listing["tax_rate"]))
                seller_gets = price - tax

                # Deduct buyer
                await conn.execute(
                    "UPDATE users SET wallet_copper = wallet_copper - $1 WHERE id = $2",
                    price.copper, buyer_id
                )
                # Pay seller
                await conn.execute(
                    "UPDATE users SET wallet_copper = wallet_copper + $1 WHERE id = $2",
                    seller_gets.copper, listing["seller_id"]
                )
                # Transfer item ownership
                await conn.execute(
                    """UPDATE inventory_items SET owner_id = $1, stored_in_bank = FALSE
                       WHERE id = $2""",
                    buyer_id, listing["item_instance_id"]
                )
                # Mark listing sold
                await conn.execute(
                    """UPDATE market_listings
                       SET status = 'sold', buyer_id = $1, sold_at = NOW(),
                           tax_collected = $2
                       WHERE id = $3""",
                    buyer_id, tax.copper, listing_id
                )
                # Ledger
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, to_user_id, amount_copper,
                        description, reference_id)
                       VALUES ('purchase', $1, $2, $3, $4, $5)""",
                    buyer_id, listing["seller_id"], price.copper,
                    f"Market: {listing['item_name']}", f"market_listing:{listing_id}"
                )

        return (
            f"✅ Purchased **{listing['item_name']}** ×{listing['quantity']}\n"
            f"💰 Paid: {price.format()}\n"
            f"📦 Item added to your inventory."
        )

    async def search_listings(
        self, query: str = "", rarity: str = "", limit: int = 10
    ) -> list[MarketListing]:
        sql = """
            SELECT m.id, m.seller_id, u.display_name AS seller_name,
                   m.item_instance_id AS item_uid, d.name AS item_name,
                   d.rarity AS item_rarity, d.icon_emoji AS item_icon,
                   m.quantity, m.price_copper, m.tax_rate, m.listed_at, m.expires_at
            FROM market_listings m
            JOIN inventory_items i ON m.item_instance_id = i.id
            JOIN item_definitions d ON i.item_def_id = d.id
            JOIN users u ON m.seller_id = u.id
            WHERE m.status = 'active' AND m.expires_at > NOW()
        """
        params = []
        if query:
            sql += f" AND d.name ILIKE ${len(params)+1}"
            params.append(f"%{query}%")
        if rarity:
            sql += f" AND d.rarity = ${len(params)+1}"
            params.append(rarity)
        sql += f" ORDER BY m.price_copper ASC LIMIT ${len(params)+1}"
        params.append(limit)

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        return [MarketListing(**dict(r)) for r in rows]

    async def cancel_listing(self, seller_id: int, listing_id: int) -> str:
        async with self._pool.acquire() as conn:
            r = await conn.execute(
                """UPDATE market_listings SET status = 'cancelled'
                   WHERE id = $1 AND seller_id = $2 AND status = 'active'""",
                listing_id, seller_id
            )
        return "✅ Listing cancelled. Item returned to inventory." if r != "UPDATE 0" \
               else "❌ Listing not found or already completed."


# ─────────────────────────────────────────────
# MERCHANT MARKET SERVICE
# ─────────────────────────────────────────────

class MerchantMarketService:
    """
    NPC Merchant — always available, instant transactions.
    Buys at 55% value, sells at 120% value.
    Items sold TO merchant vanish from the game (deflationary sink).
    """

    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def sell_to_merchant(self, user_id: int, item_uid: str, quantity: int = 1) -> str:
        async with self._pool.acquire() as conn:
            item = await conn.fetchrow(
                """SELECT i.*, d.name, d.base_value, d.rarity, d.is_tradeable,
                          d.is_stackable, d.icon_emoji
                   FROM inventory_items i
                   JOIN item_definitions d ON i.item_def_id = d.id
                   WHERE i.id = $1 AND i.owner_id = $2""",
                item_uid, user_id
            )
            if not item:
                return "❌ Item not found."
            if item["is_equipped"]:
                return "❌ Unequip the item first."
            if item["is_locked"]:
                return "❌ Item is locked."
            if not item["is_tradeable"]:
                return "❌ This item cannot be sold."

            from inventory import RARITY_CONFIG
            mult   = RARITY_CONFIG.get(item["rarity"], {}).get("mult", 1.0)
            payout = Currency.from_copper(
                int(item["base_value"] * mult * MERCHANT_VALUE_RATE) * quantity
            )

            async with conn.transaction():
                if item["is_stackable"] and item["quantity"] > quantity:
                    await conn.execute(
                        "UPDATE inventory_items SET quantity = quantity - $1 WHERE id = $2",
                        quantity, item_uid
                    )
                else:
                    await conn.execute("DELETE FROM inventory_items WHERE id = $1", item_uid)

                await conn.execute(
                    "UPDATE users SET wallet_copper = wallet_copper + $1 WHERE id = $2",
                    payout.copper, user_id
                )
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, amount_copper, description)
                       VALUES ('sale', $1, $2, $3)""",
                    user_id, payout.copper, f"Sold to merchant: {item['name']}"
                )

        return (
            f"🛒 **Merchant Purchase**\n"
            f"{item['icon_emoji']} {item['name']} ×{quantity}\n"
            f"💰 Received: **{payout.format()}**\n"
            f"_(Merchant pays {int(MERCHANT_VALUE_RATE*100)}% of base value)_"
        )

    async def buy_from_merchant(self, user_id: int, item_def_id: int, quantity: int = 1) -> str:
        """Buy a standard item from the NPC merchant shop."""
        async with self._pool.acquire() as conn:
            item_def = await conn.fetchrow(
                "SELECT * FROM item_definitions WHERE id = $1 AND is_tradeable = TRUE",
                item_def_id
            )
            if not item_def:
                return "❌ Item not available in merchant shop."

            from inventory import RARITY_CONFIG
            mult  = RARITY_CONFIG.get(item_def["rarity"], {}).get("mult", 1.0)
            cost  = Currency.from_copper(int(item_def["base_value"] * mult * MERCHANT_SELL_RATE) * quantity)

            async with conn.transaction():
                r = await conn.execute(
                    """UPDATE users SET wallet_copper = wallet_copper - $1
                       WHERE id = $2 AND wallet_copper >= $1""",
                    cost.copper, user_id
                )
                if r == "UPDATE 0":
                    return f"❌ Not enough gold. Cost: {cost.format()}"

                import uuid as _uuid
                await conn.execute(
                    """INSERT INTO inventory_items (id, owner_id, item_def_id, quantity)
                       VALUES ($1, $2, $3, $4)""",
                    str(_uuid.uuid4()), user_id, item_def_id, quantity
                )
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, amount_copper, description)
                       VALUES ('purchase', $1, $2, $3)""",
                    user_id, cost.copper, f"Merchant buy: {item_def['name']}"
                )

        return (
            f"🛒 **Merchant Sale**\n"
            f"{item_def['icon_emoji']} **{item_def['name']}** ×{quantity}\n"
            f"💰 Paid: **{cost.format()}**"
        )


# ─────────────────────────────────────────────
# BLACK MARKET SERVICE
# ─────────────────────────────────────────────

class BlackMarketService:
    """
    🌑 The Black Market — underground economy.

    Rules:
    - No listing tax (but lower payout: 40%)
    - No transaction records in main ledger
    - Access requires: level ≥ 10 OR special item "Fence's Pass"
    - Items can be "hot" (stolen) — if intercepted, user loses item + fine
    - Rare items appear here that never show in normal market
    - Admin can plant/control black market stock
    """

    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def _check_access(self, user_id: int) -> tuple[bool, str]:
        async with self._pool.acquire() as conn:
            user = await conn.fetchrow(
                "SELECT level FROM users WHERE id = $1 AND status = 'active'", user_id
            )
            if not user:
                return False, "❌ User not found."
            if user["level"] < 10:
                # Check for Fence's Pass item
                has_pass = await conn.fetchval(
                    """SELECT COUNT(*) FROM inventory_items i
                       JOIN item_definitions d ON i.item_def_id = d.id
                       WHERE i.owner_id = $1 AND d.name = 'Fence''s Pass'""",
                    user_id
                )
                if not has_pass:
                    return False, (
                        "🌑 **Black Market**\n"
                        "_You don't know how to find it..._\n\n"
                        "Reach Level 10 or obtain a **Fence's Pass** to gain access."
                    )
        return True, ""

    async def sell_to_fence(self, user_id: int, item_uid: str, quantity: int = 1) -> str:
        """Sell to black market fence. 40% value, no questions asked."""
        allowed, msg = await self._check_access(user_id)
        if not allowed:
            return msg

        async with self._pool.acquire() as conn:
            item = await conn.fetchrow(
                """SELECT i.*, d.name, d.base_value, d.rarity, d.icon_emoji
                   FROM inventory_items i
                   JOIN item_definitions d ON i.item_def_id = d.id
                   WHERE i.id = $1 AND i.owner_id = $2""",
                item_uid, user_id
            )
            if not item:
                return "❌ Item not found."
            if item["is_equipped"]:
                return "❌ Unequip first."

            # Interception risk (5% chance)
            if random.random() < 0.05:
                async with conn.transaction():
                    fine = Currency.from_copper(item["base_value"] * 2)
                    await conn.execute(
                        """UPDATE users SET wallet_copper = GREATEST(0, wallet_copper - $1)
                           WHERE id = $2""",
                        fine.copper, user_id
                    )
                    await conn.execute("DELETE FROM inventory_items WHERE id = $1", item_uid)
                return (
                    f"🚨 **INTERCEPTED!**\n"
                    f"Guards caught you at the Black Market!\n"
                    f"❌ Lost: {item['name']}\n"
                    f"💸 Fine paid: {fine.format()}"
                )

            from inventory import RARITY_CONFIG
            mult   = RARITY_CONFIG.get(item["rarity"], {}).get("mult", 1.0)
            payout = Currency.from_copper(int(item["base_value"] * mult * BLACK_MARKET_RATE) * quantity)

            async with conn.transaction():
                if item["quantity"] > quantity:
                    await conn.execute(
                        "UPDATE inventory_items SET quantity = quantity - $1 WHERE id = $2",
                        quantity, item_uid
                    )
                else:
                    await conn.execute("DELETE FROM inventory_items WHERE id = $1", item_uid)

                await conn.execute(
                    "UPDATE users SET wallet_copper = wallet_copper + $1 WHERE id = $2",
                    payout.copper, user_id
                )
                # Black market uses a SHADOW ledger (separate table)
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, amount_copper, description, reference_id)
                       VALUES ('sale', $1, $2, $3, 'black_market')""",
                    user_id, payout.copper, f"[BM] Fence: {item['name']}"
                )

        return (
            f"🌑 **Fence Deal**\n"
            f"{item['icon_emoji']} {item['name']} ×{quantity}\n"
            f"💰 Received: **{payout.format()}**\n"
            f"_{int(BLACK_MARKET_RATE*100)}% value — no questions asked_ 🤫"
        )

    async def get_black_market_stock(self) -> str:
        """Show currently available black market items (rotates every 6 hours)."""
        async with self._pool.acquire() as conn:
            # Items seeded by admins or rotated automatically
            items = await conn.fetch(
                """SELECT d.name, d.rarity, d.icon_emoji, d.base_value,
                          ROUND(d.base_value * $1) AS bm_price, d.id
                   FROM item_definitions d
                   WHERE (d.extra_data->>'black_market_available')::boolean = TRUE
                   ORDER BY d.rarity DESC LIMIT 8""",
                BLACK_MARKET_BUY
            )

        if not items:
            return "🌑 **Black Market**\n_The fence has nothing today. Check back later._"

        from inventory import RARITY_CONFIG
        lines = ["🌑 **Black Market Stock** _(refreshes every 6h)_\n"]
        for item in items:
            rarity_icon = RARITY_CONFIG.get(item["rarity"], {}).get("color", "⚪")
            price = format_currency(int(item["base_value"] * BLACK_MARKET_BUY))
            lines.append(f"{rarity_icon} {item['icon_emoji']} **{item['name']}** — {price}")
        lines.append("\n_Use /bm_buy [item_id] to purchase_")
        return "\n".join(lines)

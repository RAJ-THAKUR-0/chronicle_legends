"""
crafting.py — Chronicle Legends MMORPG Bot
Recipe-Based Crafting Engine with RNG success rates and passive bonuses
"""
from __future__ import annotations
import asyncpg
import random
import uuid
import json
import logging
from datetime import datetime, timedelta
from economy import Currency

log = logging.getLogger("crafting")

class CraftingService:
    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def get_recipes(self, user_id: int, user_level: int) -> str:
        async with self._pool.acquire() as conn:
            recipes = await conn.fetch(
                """SELECT r.*, d.name AS result_name, d.icon_emoji
                   FROM crafting_recipes r
                   JOIN item_definitions d ON r.result_item_id = d.id
                   WHERE r.is_active=TRUE AND r.req_level <= $1
                   ORDER BY r.req_level, r.name""",
                user_level
            )
        if not recipes:
            return "📖 No recipes available at your level."

        lines = [f"📖 **Crafting Recipes** (LVL {user_level})\n"]
        for r in recipes:
            ingredients = json.loads(r["ingredients"]) if isinstance(r["ingredients"], str) else r["ingredients"]
            ing_str = ", ".join(f"Item#{i['item_def_id']}×{i['quantity']}" for i in ingredients)
            cost_str = f" + {Currency.from_copper(r['copper_cost']).format()}" if r["copper_cost"] else ""
            lines.append(
                f"{r['icon_emoji']} **{r['result_name']}** ×{r['result_quantity']}\n"
                f"  📦 {ing_str}{cost_str}\n"
                f"  🎲 Success: {int(r['success_rate']*100)}%  ⏱ {r['crafting_time_s']}s\n"
            )
        return "\n".join(lines)

    async def craft(self, user_id: int, recipe_id: int, user_race: str) -> str:
        async with self._pool.acquire() as conn:
            recipe = await conn.fetchrow(
                """SELECT r.*, d.name AS result_name, d.icon_emoji
                   FROM crafting_recipes r JOIN item_definitions d ON r.result_item_id=d.id
                   WHERE r.id=$1 AND r.is_active=TRUE""",
                recipe_id
            )
            if not recipe:
                return "❌ Recipe not found."

            user = await conn.fetchrow(
                "SELECT level, wallet_copper FROM users WHERE id=$1", user_id
            )
            if user["level"] < recipe["req_level"]:
                return f"❌ Requires Level {recipe['req_level']}."

            ingredients = json.loads(recipe["ingredients"]) if isinstance(recipe["ingredients"], str) else recipe["ingredients"]

            # Verify ingredients in inventory
            for ing in ingredients:
                qty = await conn.fetchval(
                    """SELECT COALESCE(SUM(quantity),0) FROM inventory_items
                       WHERE owner_id=$1 AND item_def_id=$2 AND stored_in_bank=FALSE""",
                    user_id, ing["item_def_id"]
                )
                if qty < ing["quantity"]:
                    item_name = await conn.fetchval(
                        "SELECT name FROM item_definitions WHERE id=$1", ing["item_def_id"]
                    )
                    return f"❌ Need {ing['quantity']}× {item_name or f'Item#{ing[\"item_def_id\"]}'}. You have {qty}."

            if recipe["copper_cost"] and user["wallet_copper"] < recipe["copper_cost"]:
                return f"❌ Need {Currency.from_copper(recipe['copper_cost']).format()} to craft."

            # Apply Dwarf crafting passive
            success_rate = recipe["success_rate"]
            from races import RACES
            from combat import PassiveRegistry
            if user_race in RACES:
                race = RACES[user_race]
                ctx = {"success_rate": success_rate}
                for passive in race.get_passive("on_craft"):
                    ctx = PassiveRegistry.trigger(passive.effect_key, None, ctx, passive.magnitude)
                success_rate = min(1.0, ctx.get("success_rate", success_rate))

            rng_roll = round(random.random(), 4)
            success  = rng_roll <= success_rate

            async with conn.transaction():
                # Consume ingredients
                for ing in ingredients:
                    remaining = ing["quantity"]
                    stacks = await conn.fetch(
                        """SELECT id, quantity FROM inventory_items
                           WHERE owner_id=$1 AND item_def_id=$2 AND stored_in_bank=FALSE
                           ORDER BY quantity ASC""",
                        user_id, ing["item_def_id"]
                    )
                    for stack in stacks:
                        if remaining <= 0: break
                        deduct = min(stack["quantity"], remaining)
                        if deduct == stack["quantity"]:
                            await conn.execute("DELETE FROM inventory_items WHERE id=$1", stack["id"])
                        else:
                            await conn.execute(
                                "UPDATE inventory_items SET quantity=quantity-$1 WHERE id=$2",
                                deduct, stack["id"]
                            )
                        remaining -= deduct

                # Deduct copper cost
                if recipe["copper_cost"]:
                    await conn.execute(
                        "UPDATE users SET wallet_copper=wallet_copper-$1 WHERE id=$2",
                        recipe["copper_cost"], user_id
                    )

                result_item_uid = None
                if success:
                    result_item_uid = str(uuid.uuid4())
                    await conn.execute(
                        """INSERT INTO inventory_items (id, owner_id, item_def_id, quantity)
                           VALUES ($1,$2,$3,$4)""",
                        result_item_uid, user_id, recipe["result_item_id"], recipe["result_quantity"]
                    )

                await conn.execute(
                    """INSERT INTO crafting_queue
                       (user_id, recipe_id, status, rng_roll, started_at, completes_at, result_item_id)
                       VALUES ($1,$2,$3,$4,NOW(),NOW()+($5||' seconds')::interval,$6)""",
                    user_id, recipe_id,
                    "success" if success else "failed",
                    rng_roll,
                    str(recipe["crafting_time_s"]),
                    result_item_uid
                )

        if success:
            return (
                f"⚒️ **Crafting Success!** 🎉\n"
                f"{recipe['icon_emoji']} **{recipe['result_name']}** ×{recipe['result_quantity']} created!\n"
                f"🎲 Roll: {rng_roll:.0%} / needed ≤{success_rate:.0%}"
            )
        else:
            return (
                f"💥 **Crafting Failed!**\n"
                f"Materials consumed. Better luck next time!\n"
                f"🎲 Roll: {rng_roll:.0%} / needed ≤{success_rate:.0%}\n"
                f"_(Dwarf racial gives +20% success rate)_"
            )

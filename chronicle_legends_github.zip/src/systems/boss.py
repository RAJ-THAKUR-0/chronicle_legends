"""
boss.py — Chronicle Legends MMORPG Bot
Global Boss Raid Engine

Features:
  - Scheduled auto-spawn via APScheduler
  - Global HP pool shared across all players
  - Pro-rata damage-based reward distribution
  - Loot table rolling per participant
  - Raid leaderboard
  - Admin force-spawn
  - Enrage timer (boss gets stronger over time)
"""

from __future__ import annotations
import asyncio
import asyncpg
import logging
import random
import json
from datetime import datetime, timedelta
from typing import Optional

from economy import Currency, format_currency, render_bar
from inventory import RARITY_CONFIG

log = logging.getLogger("boss")

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

RAID_EXPIRY_HOURS    = 24       # Boss despawns if not killed in time
ENRAGE_THRESHOLD     = 0.20     # Boss enrages at 20% HP
ENRAGE_ATK_MULT      = 1.75     # Enraged boss deals 75% more damage
MIN_DAMAGE_FOR_REWARD = 1       # Must deal at least 1 damage to get rewards
ANNOUNCE_INTERVAL_S  = 3600     # Re-announce active raid every hour


# ─────────────────────────────────────────────
# BOSS RAID SERVICE
# ─────────────────────────────────────────────

class BossRaidService:
    """
    Manages the full lifecycle of a global boss raid:
      spawn → damage intake → defeat → reward distribution → cleanup
    """

    def __init__(self, pool: asyncpg.Pool, bot=None):
        self._pool = pool
        self._bot  = bot          # Telegram Bot instance for announcements
        self._announce_chat_ids: list[int] = []   # Set by bot.py on startup

    def set_announce_chats(self, chat_ids: list[int]):
        self._announce_chat_ids = chat_ids

    # ── Active Raid Query ────────────────────────

    async def get_active_raid(self) -> Optional[dict]:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT r.id, r.boss_def_id, r.hp_current, r.hp_max,
                       r.status, r.spawned_at, r.expires_at,
                       b.name, b.icon_emoji, b.loot_table,
                       b.copper_reward_base, b.level, b.stat_block
                FROM boss_raids r
                JOIN boss_definitions b ON r.boss_def_id = b.id
                WHERE r.status = 'active'
                ORDER BY r.spawned_at DESC
                LIMIT 1
                """
            )
        return dict(row) if row else None

    # ── Spawn ────────────────────────────────────

    async def spawn_boss(self, boss_def_id: int, forced_by: Optional[int] = None) -> dict:
        """
        Spawn a new global boss raid.
        Called by scheduler or admin /spawn_boss command.
        Returns the raid dict.
        """
        async with self._pool.acquire() as conn:
            # Check no active raid for this boss already
            existing = await conn.fetchval(
                "SELECT id FROM boss_raids WHERE status='active' AND boss_def_id=$1",
                boss_def_id
            )
            if existing:
                return {"error": f"Boss #{boss_def_id} already has an active raid (#{existing})."}

            boss = await conn.fetchrow(
                "SELECT * FROM boss_definitions WHERE id=$1 AND is_active=TRUE",
                boss_def_id
            )
            if not boss:
                return {"error": f"Boss #{boss_def_id} not found or inactive."}

            raid_id = await conn.fetchval(
                """
                INSERT INTO boss_raids
                  (boss_def_id, status, hp_current, hp_max, spawned_at, expires_at)
                VALUES ($1, 'active', $2, $2, NOW(), NOW() + ($3 || ' hours')::interval)
                RETURNING id
                """,
                boss_def_id, boss["hp_base"],
                str(RAID_EXPIRY_HOURS)
            )

        raid = {
            "id": raid_id,
            "boss_name": boss["name"],
            "icon": boss["icon_emoji"],
            "hp_max": boss["hp_base"],
            "hp_current": boss["hp_base"],
            "level": boss["level"],
            "expires_in_hours": RAID_EXPIRY_HOURS,
            "forced_by": forced_by,
        }

        log.info(f"Boss raid #{raid_id} spawned: {boss['name']} (HP: {boss['hp_base']:,})")
        await self._announce_spawn(raid)
        return raid

    async def _announce_spawn(self, raid: dict):
        """Broadcast spawn message to all registered group chats."""
        if not self._bot or not self._announce_chat_ids:
            return
        hp_bar = render_bar(raid["hp_current"], raid["hp_max"], length=12)
        msg = (
            f"⚠️ **GLOBAL BOSS SPAWNED!** ⚠️\n\n"
            f"{raid['icon']} **{raid['boss_name']}** (LVL {raid['level']})\n"
            f"❤️ [{hp_bar}] {raid['hp_max']:,} HP\n"
            f"⏳ Expires in {raid['expires_in_hours']}h\n\n"
            f"Use /raid_attack to deal damage!\n"
            f"Rewards are based on your **damage contribution** 💰"
        )
        for chat_id in self._announce_chat_ids:
            try:
                await self._bot.send_message(chat_id, msg, parse_mode="Markdown")
            except Exception as e:
                log.warning(f"Announce failed for chat {chat_id}: {e}")

    # ── Damage ───────────────────────────────────

    async def deal_damage(self, user_id: int, raid_id: int) -> dict:
        """
        Player attacks the boss. Damage is calculated from player stats.
        Returns result dict with events, new boss HP, and enrage status.
        """
        async with self._pool.acquire() as conn:
            # Fetch player stats
            user = await conn.fetchrow(
                """SELECT display_name, level, stat_str, stat_dex, stat_luk,
                          hp_current, wallet_copper
                   FROM users WHERE id=$1 AND status='active'""",
                user_id
            )
            if not user:
                return {"error": "Character not found."}
            if user["hp_current"] <= 0:
                return {"error": "❌ You are dead! Visit a healer first."}

            # Fetch boss
            raid = await conn.fetchrow(
                """SELECT r.hp_current, r.hp_max, r.status,
                          b.name, b.icon_emoji, b.level, b.stat_block
                   FROM boss_raids r
                   JOIN boss_definitions b ON r.boss_def_id=b.id
                   WHERE r.id=$1""",
                raid_id
            )
            if not raid or raid["status"] != "active":
                return {"error": "❌ No active raid found."}
            if raid["hp_current"] <= 0:
                return {"error": "⚔️ Boss already defeated!"}

        # Calculate player damage (scales with level + STR)
        base_dmg  = (user["level"] * 8) + (user["stat_str"] * 3)
        variance  = random.uniform(0.85, 1.15)
        damage    = int(base_dmg * variance)

        # Crit check (LUK-scaled)
        crit_chance = 0.05 + user["stat_luk"] * 0.002
        is_crit     = random.random() < min(0.60, crit_chance)
        if is_crit:
            damage = int(damage * 1.75)

        # Enrage check: boss deals damage back to player at 20% HP
        enraged      = raid["hp_current"] <= (raid["hp_max"] * ENRAGE_THRESHOLD)
        player_dmg   = 0
        events       = []

        if enraged:
            stat_block  = json.loads(raid["stat_block"]) if isinstance(raid["stat_block"], str) else raid["stat_block"]
            boss_atk    = stat_block.get("atk", 50)
            player_dmg  = int(boss_atk * ENRAGE_ATK_MULT * random.uniform(0.9, 1.1))
            events.append(f"🔴 **ENRAGED!** {raid['name']} retaliates for **{player_dmg}** damage!")

        async with self._pool.acquire() as conn:
            async with conn.transaction():
                # Lock and update boss HP
                current = await conn.fetchval(
                    "SELECT hp_current FROM boss_raids WHERE id=$1 FOR UPDATE", raid_id
                )
                new_hp = max(0, current - damage)
                await conn.execute(
                    "UPDATE boss_raids SET hp_current=$1 WHERE id=$2",
                    new_hp, raid_id
                )

                # Upsert participant damage
                await conn.execute(
                    """
                    INSERT INTO raid_participants (raid_id, user_id, damage_dealt, hits, last_hit_at)
                    VALUES ($1, $2, $3, 1, NOW())
                    ON CONFLICT (raid_id, user_id) DO UPDATE
                      SET damage_dealt = raid_participants.damage_dealt + $3,
                          hits         = raid_participants.hits + 1,
                          last_hit_at  = NOW()
                    """,
                    raid_id, user_id, damage
                )

                # Apply retaliation damage to player
                if player_dmg > 0:
                    await conn.execute(
                        "UPDATE users SET hp_current=GREATEST(0,hp_current-$1) WHERE id=$2",
                        player_dmg, user_id
                    )

                # Check defeat
                is_defeated = new_hp == 0
                if is_defeated:
                    await conn.execute(
                        "UPDATE boss_raids SET status='defeated', defeated_at=NOW() WHERE id=$1",
                        raid_id
                    )

        crit_str = " 💥 **CRITICAL!**" if is_crit else ""
        events.insert(0, f"⚔️ You deal **{damage:,}** damage to {raid['name']}!{crit_str}")

        hp_bar = render_bar(new_hp, raid["hp_max"], length=12)
        pct    = int((new_hp / raid["hp_max"]) * 100) if raid["hp_max"] else 0

        result = {
            "events":       events,
            "damage":       damage,
            "is_crit":      is_crit,
            "is_defeated":  is_defeated,
            "enraged":      enraged,
            "boss_hp":      new_hp,
            "boss_hp_max":  raid["hp_max"],
            "boss_hp_bar":  hp_bar,
            "boss_hp_pct":  pct,
            "player_dmg_taken": player_dmg,
        }

        if is_defeated:
            log.info(f"Boss raid #{raid_id} defeated by last hit from user {user_id}!")
            rewards = await self.distribute_rewards(raid_id)
            result["rewards"]  = rewards
            result["loot"]     = await self._roll_loot_for_all(raid_id)
            await self._announce_defeat(raid_id, raid["name"], raid["icon_emoji"])

        return result

    # ── Rewards ──────────────────────────────────

    async def distribute_rewards(self, raid_id: int) -> list[dict]:
        """
        Pro-rata copper reward based on % of total damage dealt.
        Also grants XP proportionally.
        """
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                raid = await conn.fetchrow(
                    """SELECT r.hp_max, b.copper_reward_base, b.xp_reward
                       FROM boss_raids r
                       JOIN boss_definitions b ON r.boss_def_id=b.id
                       WHERE r.id=$1""",
                    raid_id
                )
                # Fallback XP if not on boss_definitions
                xp_pool     = getattr(raid, "xp_reward", 5000) if raid else 5000
                copper_pool = raid["copper_reward_base"] if raid else 0

                participants = await conn.fetch(
                    "SELECT user_id, damage_dealt FROM raid_participants WHERE raid_id=$1",
                    raid_id
                )

                total_damage = sum(p["damage_dealt"] for p in participants)
                rewards      = []

                for p in participants:
                    if p["damage_dealt"] < MIN_DAMAGE_FOR_REWARD:
                        continue
                    share    = p["damage_dealt"] / total_damage if total_damage else 0
                    copper   = int(copper_pool * share)
                    xp_grant = int(xp_pool * share)

                    if copper > 0:
                        await conn.execute(
                            "UPDATE users SET wallet_copper=wallet_copper+$1 WHERE id=$2",
                            copper, p["user_id"]
                        )
                    if xp_grant > 0:
                        await conn.execute(
                            "UPDATE users SET experience=experience+$1 WHERE id=$2",
                            xp_grant, p["user_id"]
                        )

                    await conn.execute(
                        """UPDATE raid_participants
                           SET reward_copper=$1, rewarded_at=NOW()
                           WHERE raid_id=$2 AND user_id=$3""",
                        copper, raid_id, p["user_id"]
                    )
                    await conn.execute(
                        """INSERT INTO transactions
                           (tx_type, to_user_id, amount_copper, description, reference_id)
                           VALUES ('raid_reward', $1, $2, 'Boss raid reward', $3)""",
                        p["user_id"], copper, f"boss_raid:{raid_id}"
                    )

                    rewards.append({
                        "user_id":    p["user_id"],
                        "damage":     p["damage_dealt"],
                        "share_pct":  round(share * 100, 1),
                        "copper":     copper,
                        "xp":         xp_grant,
                    })

        return rewards

    async def _roll_loot_for_all(self, raid_id: int) -> dict[int, list[str]]:
        """Roll loot table for every participant. Returns {user_id: [item_names]}."""
        import uuid as _uuid
        async with self._pool.acquire() as conn:
            raid = await conn.fetchrow(
                "SELECT b.loot_table FROM boss_raids r JOIN boss_definitions b ON r.boss_def_id=b.id WHERE r.id=$1",
                raid_id
            )
            participants = await conn.fetch(
                "SELECT user_id, damage_dealt FROM raid_participants WHERE raid_id=$1",
                raid_id
            )
            loot_table = json.loads(raid["loot_table"]) if isinstance(raid["loot_table"], str) else raid["loot_table"]
        
        results = {}
        async with self._pool.acquire() as conn:
            for p in participants:
                drops = []
                for entry in loot_table:
                    if random.random() < entry.get("chance", 0):
                        qty = random.randint(entry.get("qty_min", 1), entry.get("qty_max", 1))
                        item_def = await conn.fetchrow(
                            "SELECT name, icon_emoji FROM item_definitions WHERE id=$1",
                            entry["item_def_id"]
                        )
                        if item_def:
                            await conn.execute(
                                """INSERT INTO inventory_items (id, owner_id, item_def_id, quantity)
                                   VALUES ($1,$2,$3,$4)""",
                                str(_uuid.uuid4()), p["user_id"], entry["item_def_id"], qty
                            )
                            drops.append(f"{item_def['icon_emoji']} {item_def['name']} ×{qty}")
                results[p["user_id"]] = drops

        return results

    async def _announce_defeat(self, raid_id: int, boss_name: str, icon: str):
        if not self._bot or not self._announce_chat_ids:
            return
        leaderboard = await self.get_raid_leaderboard(raid_id, limit=5)
        lb_str = "\n".join(
            f"  {i+1}. {r['name']} — {r['damage']:,} dmg ({r['share_pct']}%) → {format_currency(r['copper'])}"
            for i, r in enumerate(leaderboard)
        )
        msg = (
            f"💀 **{icon} {boss_name} HAS BEEN DEFEATED!**\n\n"
            f"🏆 **Top Raiders:**\n{lb_str}\n\n"
            f"Rewards have been distributed to all participants!"
        )
        for chat_id in self._announce_chat_ids:
            try:
                await self._bot.send_message(chat_id, msg, parse_mode="Markdown")
            except Exception as e:
                log.warning(f"Defeat announce failed for chat {chat_id}: {e}")

    # ── Leaderboard ──────────────────────────────

    async def get_raid_leaderboard(self, raid_id: int, limit: int = 10) -> list[dict]:
        async with self._pool.acquire() as conn:
            total = await conn.fetchval(
                "SELECT SUM(damage_dealt) FROM raid_participants WHERE raid_id=$1", raid_id
            ) or 1
            rows = await conn.fetch(
                """SELECT u.display_name AS name, rp.damage_dealt AS damage,
                          rp.reward_copper AS copper, rp.hits
                   FROM raid_participants rp
                   JOIN users u ON rp.user_id=u.id
                   WHERE rp.raid_id=$1
                   ORDER BY rp.damage_dealt DESC LIMIT $2""",
                raid_id, limit
            )
        return [
            {
                "name":      r["name"],
                "damage":    r["damage"],
                "share_pct": round(r["damage"] / total * 100, 1),
                "copper":    r["copper"] or 0,
                "hits":      r["hits"],
            }
            for r in rows
        ]

    async def render_raid_status(self, raid_id: int) -> str:
        raid = await self.get_active_raid()
        if not raid:
            return "⚔️ No active boss raid. Stay alert for the next spawn!"

        hp_bar   = render_bar(raid["hp_current"], raid["hp_max"], length=14)
        pct      = int((raid["hp_current"] / raid["hp_max"]) * 100) if raid["hp_max"] else 0
        enraged  = raid["hp_current"] <= (raid["hp_max"] * ENRAGE_THRESHOLD)
        enrage_str = "\n🔴 **⚠ BOSS ENRAGED! ⚠**" if enraged else ""

        lb = await self.get_raid_leaderboard(raid_id, limit=5)
        lb_str = "\n".join(
            f"  {i+1}. {r['name']} — {r['damage']:,} dmg ({r['share_pct']}%)"
            for i, r in enumerate(lb)
        ) or "  No participants yet."

        expires_in = (raid["expires_at"] - datetime.utcnow()) if raid.get("expires_at") else None
        exp_str = f"{expires_in.seconds // 3600}h {(expires_in.seconds % 3600) // 60}m" if expires_in else "?"

        return (
            f"👑 **GLOBAL BOSS RAID**\n"
            f"{'═'*30}\n"
            f"{raid['icon_emoji']} **{raid['name']}** (LVL {raid['level']}){enrage_str}\n\n"
            f"❤️ [{hp_bar}] {raid['hp_current']:,}/{raid['hp_max']:,} ({pct}%)\n"
            f"⏳ Expires in: {exp_str}\n\n"
            f"🏆 **Top Raiders:**\n{lb_str}\n\n"
            f"_Use /raid_attack to deal damage!_"
        )

    # ── Scheduler ────────────────────────────────

    async def run_spawn_scheduler(self):
        """
        Background task. Checks boss_definitions for spawn_interval_h
        and auto-spawns if enough time has passed since last raid.
        Run with: asyncio.create_task(boss_service.run_spawn_scheduler())
        """
        log.info("Boss spawn scheduler started.")
        while True:
            try:
                async with self._pool.acquire() as conn:
                    bosses = await conn.fetch(
                        "SELECT * FROM boss_definitions WHERE is_active=TRUE"
                    )
                    for boss in bosses:
                        last_raid = await conn.fetchrow(
                            """SELECT spawned_at FROM boss_raids
                               WHERE boss_def_id=$1
                               ORDER BY spawned_at DESC LIMIT 1""",
                            boss["id"]
                        )
                        should_spawn = False
                        if not last_raid:
                            should_spawn = True
                        else:
                            elapsed = datetime.utcnow() - last_raid["spawned_at"].replace(tzinfo=None)
                            if elapsed.total_seconds() >= boss["spawn_interval_h"] * 3600:
                                should_spawn = True

                        if should_spawn:
                            # Check no active raid already
                            active = await conn.fetchval(
                                "SELECT id FROM boss_raids WHERE boss_def_id=$1 AND status='active'",
                                boss["id"]
                            )
                            if not active:
                                await self.spawn_boss(boss["id"])

                # Also expire overdue raids
                async with self._pool.acquire() as conn:
                    await conn.execute(
                        "UPDATE boss_raids SET status='expired' WHERE status='active' AND expires_at < NOW()"
                    )

            except Exception as e:
                log.error(f"Spawn scheduler error: {e}")

            await asyncio.sleep(300)   # Check every 5 minutes


# ─────────────────────────────────────────────
# BOT COMMAND HANDLERS (imported by bot.py)
# ─────────────────────────────────────────────

async def cmd_raid_status(update, ctx):
    pool     = ctx.bot_data["pool"]
    uid      = update.effective_user.id
    svc      = BossRaidService(pool)
    raid     = await svc.get_active_raid()
    if not raid:
        await update.message.reply_text("⚔️ No active raid. Stay alert!", parse_mode="Markdown")
        return
    msg = await svc.render_raid_status(raid["id"])
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_raid_attack(update, ctx):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    svc  = BossRaidService(pool)

    raid = await svc.get_active_raid()
    if not raid:
        await update.message.reply_text("⚔️ No active raid right now!")
        return

    result = await svc.deal_damage(uid, raid["id"])
    if "error" in result:
        await update.message.reply_text(result["error"])
        return

    events_str = "\n".join(result["events"])
    hp_bar     = result["boss_hp_bar"]
    pct        = result["boss_hp_pct"]

    if result["is_defeated"]:
        rewards  = result.get("rewards", [])
        my_reward = next((r for r in rewards if r["user_id"] == uid), None)
        loot_all  = result.get("loot", {})
        my_loot   = loot_all.get(uid, [])

        reward_str = ""
        if my_reward:
            reward_str = (
                f"\n\n🎁 **Your Reward:**\n"
                f"💰 {format_currency(my_reward['copper'])} "
                f"({my_reward['share_pct']}% damage share)\n"
                f"✨ +{my_reward['xp']} XP"
            )
        loot_str = f"\n🎲 Loot: {', '.join(my_loot)}" if my_loot else ""

        await update.message.reply_text(
            f"{events_str}\n\n"
            f"💀 **{raid['name']} DEFEATED!**\n"
            f"❤️ [{hp_bar}] 0/{raid['hp_max']:,}"
            f"{reward_str}{loot_str}",
            parse_mode="Markdown"
        )
    else:
        enrage_warning = "\n🔴 ⚠️ **BOSS IS ENRAGED!**" if result["enraged"] else ""
        await update.message.reply_text(
            f"{events_str}\n\n"
            f"{raid['icon_emoji']} ❤️ [{hp_bar}] {result['boss_hp']:,}/{raid['hp_max']:,} ({pct}%)"
            f"{enrage_warning}",
            parse_mode="Markdown"
        )


async def cmd_spawn_boss_admin(update, ctx):
    """Admin: /spawn_boss [boss_def_id]"""
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args

    from admin import AdminService
    svc = AdminService(pool)
    is_admin, _ = await svc.middleware._get_user_status(uid)
    if not is_admin:
        await update.message.reply_text("🚫 Admin only.")
        return

    if not args:
        async with pool.acquire() as conn:
            bosses = await conn.fetch(
                "SELECT id, name, icon_emoji, level FROM boss_definitions WHERE is_active=TRUE"
            )
        lines = ["👑 **Available Bosses:**\n"] + [
            f"  #{b['id']} {b['icon_emoji']} {b['name']} (LVL {b['level']})"
            for b in bosses
        ]
        lines.append("\nUsage: /spawn_boss [id]")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        return

    boss_svc = BossRaidService(pool, ctx.bot)
    result   = await boss_svc.spawn_boss(int(args[0]), forced_by=uid)

    if "error" in result:
        await update.message.reply_text(f"❌ {result['error']}")
    else:
        await update.message.reply_text(
            f"✅ **Boss Spawned!**\n"
            f"{result['icon']} **{result['boss_name']}** (LVL {result['level']})\n"
            f"❤️ {result['hp_max']:,} HP\n"
            f"⏳ Expires in {result['expires_in_hours']}h",
            parse_mode="Markdown"
        )

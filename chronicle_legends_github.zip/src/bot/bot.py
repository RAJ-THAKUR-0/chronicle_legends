"""
bot.py — Chronicle Legends MMORPG Bot
Main Telegram Bot Entry Point — Command Router & Handler Wiring

Dependencies:
  pip install python-telegram-bot asyncpg

Run:
  python bot.py
"""

from __future__ import annotations
import asyncio
import logging
import os
import json
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, PhotoSize
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters, ConversationHandler
)

from database import Services, get_pool
from economy import Currency, parse_currency, render_status_bar
from races import RACES, Race
from combat import CombatSession, Combatant, MonsterDefinition, DamageEngine
from inventory import InventoryService
from market import PlayerMarketService, MerchantMarketService, BlackMarketService
from guild import GuildService
from crafting import CraftingService
from admin import AdminService, parse_stat_args

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
log = logging.getLogger("bot")

BOT_TOKEN = os.environ["BOT_TOKEN"]

# Conversation states for multi-step admin monster creation
(
    MONSTER_NAME, MONSTER_DESC, MONSTER_ZONE, MONSTER_LEVEL,
    MONSTER_HP, MONSTER_ATK, MONSTER_DEF, MONSTER_SPD,
    MONSTER_XP, MONSTER_COPPER, MONSTER_PHOTO, MONSTER_CONFIRM
) = range(12)


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

async def get_services(pool) -> dict:
    return {
        "inventory": InventoryService(pool),
        "player_market": PlayerMarketService(pool),
        "merchant": MerchantMarketService(pool),
        "black_market": BlackMarketService(pool),
        "guild": GuildService(pool),
        "crafting": CraftingService(pool),
        "admin": AdminService(pool),
    }

async def status_bar(user_id: int, pool) -> str:
    async with pool.acquire() as conn:
        u = await conn.fetchrow(
            """SELECT hp_current, hp_max, mp_current, mp_max,
                      level, wallet_copper, experience, experience_next
               FROM users WHERE id=$1""", user_id
        )
    if not u:
        return ""
    return "\n" + render_status_bar(
        u["hp_current"], u["hp_max"],
        u["mp_current"], u["mp_max"],
        u["level"], u["wallet_copper"],
        u["experience"], u["experience_next"]
    )

def user_info(update: Update) -> tuple[int, str, str]:
    user = update.effective_user
    return user.id, user.username or "", user.full_name


# ─────────────────────────────────────────────
# CORE COMMANDS
# ─────────────────────────────────────────────

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid, username, name = user_info(update)
    user, created = await Services.users.get_or_create(uid, username, name, "human")

    if created:
        msg = (
            f"⚔️ **Welcome to Chronicle Legends!**\n\n"
            f"You are reborn as **{name}**.\n\n"
            f"First, choose your race:\n\n"
            f"{Race.selection_menu()}"
        )
    else:
        bar = await status_bar(uid, pool)
        msg = (
            f"⚔️ Welcome back, **{user.display_name}**!\n"
            f"Race: {user.race.title()}  |  LVL {user.level}{bar}"
        )
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_create(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    /create <race>
    Sets the user's race during character creation.
    """
    pool = ctx.bot_data["pool"]
    uid, username, name = user_info(update)
    args = ctx.args

    if not args or args[0].lower() not in RACES:
        await update.message.reply_text(Race.selection_menu(), parse_mode="Markdown")
        return

    race_key = args[0].lower()
    race     = RACES[race_key]

    async with pool.acquire() as conn:
        await conn.execute(
            """UPDATE users SET race=$1, current_zone=$2 WHERE id=$3""",
            race_key, race.start_zone, uid
        )

    await update.message.reply_text(
        f"✅ You are now a **{race.display_name}**!\n\n"
        f"{race.card()}\n\n"
        f"Your adventure begins in **{race.start_zone.replace('_',' ').title()}**!\n"
        f"Use /profile to see your stats.",
        parse_mode="Markdown"
    )


async def cmd_profile(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    user = await Services.users.get(uid)
    if not user:
        await update.message.reply_text("❌ Character not found. Use /start to begin.")
        return

    race = RACES.get(user.race)
    race_icon = race.icon if race else "🧑"

    equipped_svc = InventoryService(pool)
    equipped = await equipped_svc.get_equipped(uid)
    gear_str = "None" if not equipped else ", ".join(
        f"{i.rarity_icon}{i.display_name}" for i in equipped
    )

    bar = await status_bar(uid, pool)
    await update.message.reply_text(
        f"{race_icon} **{user.display_name}**\n"
        f"Race: {user.race.title()}  |  Zone: {user.current_zone.replace('_',' ').title()}\n"
        f"⚔️ K/D: {user.kills}/{user.deaths}\n\n"
        f"📊 **Stats**\n"
        f"STR {user.stat_str} | DEX {user.stat_dex} | INT {user.stat_int}\n"
        f"VIT {user.stat_vit} | WIS {user.stat_wis} | LUK {user.stat_luk}\n"
        f"📌 Unspent points: {user.stat_points}\n\n"
        f"💰 Wallet: {user.wallet.format()}\n"
        f"🏦 Bank:   {user.bank.format()}\n\n"
        f"🛡️ Gear: {gear_str}"
        f"{bar}",
        parse_mode="Markdown"
    )


async def cmd_inventory(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    svc  = InventoryService(pool)
    msg  = await svc.render_inventory(uid)
    bar  = await status_bar(uid, pool)
    await update.message.reply_text(msg + bar, parse_mode="Markdown")


async def cmd_bank(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    svc  = InventoryService(pool)

    if not args:
        user = await Services.users.get(uid)
        await update.message.reply_text(
            f"🏦 **Your Bank Account**\n"
            f"Balance: **{user.bank.format()}**\n\n"
            f"Commands:\n"
            f"/bank deposit [amount]    — Move money to bank\n"
            f"/bank withdraw [amount]   — Take money out\n"
            f"/bank store [item_uid]    — Store item safely\n"
            f"/bank retrieve [item_uid] — Retrieve stored item\n\n"
            f"_Bank protects against death penalty!_",
            parse_mode="Markdown"
        )
        return

    action = args[0].lower()
    if action == "deposit" and len(args) >= 2:
        amount = parse_currency(" ".join(args[1:]))
        msg = await svc.bank_deposit_currency(uid, amount)
    elif action == "withdraw" and len(args) >= 2:
        amount = parse_currency(" ".join(args[1:]))
        msg = await svc.bank_withdraw_currency(uid, amount)
    elif action == "store" and len(args) >= 2:
        msg = await svc.bank_deposit_item(uid, args[1])
    elif action == "retrieve" and len(args) >= 2:
        msg = await svc.bank_withdraw_item(uid, args[1])
    else:
        msg = "❌ Invalid bank command. See /bank for help."

    bar = await status_bar(uid, pool)
    await update.message.reply_text(msg + bar, parse_mode="Markdown")


# ─────────────────────────────────────────────
# MARKET COMMANDS
# ─────────────────────────────────────────────

async def cmd_market(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    svc  = PlayerMarketService(pool)

    if not args:
        listings = await svc.search_listings(limit=10)
        if not listings:
            await update.message.reply_text("🏪 **Market** — No active listings.", parse_mode="Markdown")
            return
        cards = "\n\n".join(l.card() for l in listings)
        await update.message.reply_text(
            f"🏪 **Player Market** ({len(listings)} listings)\n\n{cards}\n\n"
            f"/market buy [id] | /market sell [item_uid] [price] | /market search [name]",
            parse_mode="Markdown"
        )
        return

    action = args[0].lower()

    if action == "buy" and len(args) >= 2:
        msg = await svc.buy_listing(uid, int(args[1]))

    elif action == "sell" and len(args) >= 3:
        item_uid = args[1]
        price    = parse_currency(" ".join(args[2:]))
        msg      = await svc.list_item(uid, item_uid, price)

    elif action == "search":
        query    = " ".join(args[1:]) if len(args) > 1 else ""
        listings = await svc.search_listings(query=query)
        msg      = "\n\n".join(l.card() for l in listings) if listings else "No results."

    elif action == "cancel" and len(args) >= 2:
        msg = await svc.cancel_listing(uid, int(args[1]))

    else:
        msg = "❌ Usage: /market | /market buy [id] | /market sell [uid] [price]"

    bar = await status_bar(uid, pool)
    await update.message.reply_text(msg + bar, parse_mode="Markdown")


async def cmd_merchant(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    svc  = MerchantMarketService(pool)

    if not args:
        await update.message.reply_text(
            "🛒 **Merchant Market**\n"
            "_Instant buy/sell. No waiting!_\n\n"
            "/merchant sell [item_uid] [qty] — Sell to NPC (55% value)\n"
            "/merchant buy [item_id] [qty]   — Buy from NPC stock",
            parse_mode="Markdown"
        )
        return

    action = args[0].lower()
    if action == "sell" and len(args) >= 2:
        qty = int(args[2]) if len(args) >= 3 else 1
        msg = await svc.sell_to_merchant(uid, args[1], qty)
    elif action == "buy" and len(args) >= 2:
        qty = int(args[2]) if len(args) >= 3 else 1
        msg = await svc.buy_from_merchant(uid, int(args[1]), qty)
    else:
        msg = "❌ Invalid command. See /merchant."

    bar = await status_bar(uid, pool)
    await update.message.reply_text(msg + bar, parse_mode="Markdown")


async def cmd_blackmarket(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    svc  = BlackMarketService(pool)

    if not args:
        msg = await svc.get_black_market_stock()
    elif args[0].lower() == "sell" and len(args) >= 2:
        qty = int(args[2]) if len(args) >= 3 else 1
        msg = await svc.sell_to_fence(uid, args[1], qty)
    else:
        msg = "🌑 /bm sell [item_uid] [qty] | /bm to browse stock"

    bar = await status_bar(uid, pool)
    await update.message.reply_text(msg + bar, parse_mode="Markdown")


# ─────────────────────────────────────────────
# ADMIN COMMANDS
# ─────────────────────────────────────────────

async def cmd_ban(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool  = ctx.bot_data["pool"]
    uid   = update.effective_user.id
    svc   = AdminService(pool)
    args  = ctx.args
    if len(args) < 1:
        await update.message.reply_text("Usage: /ban [user_id] [reason]")
        return
    target  = int(args[0])
    reason  = " ".join(args[1:]) if len(args) > 1 else "No reason given"
    msg = await svc.ban(uid, target, reason)
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_unban(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    svc  = AdminService(pool)
    if not ctx.args:
        await update.message.reply_text("Usage: /unban [user_id]")
        return
    msg = await svc.unban(uid, int(ctx.args[0]))
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_give_item(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    if len(args) < 3:
        await update.message.reply_text("Usage: /give_item [user_id] [item_def_id] [qty]")
        return
    svc  = InventoryService(pool)
    msg  = await svc.admin_give_item(int(args[0]), int(args[1]), int(args[2]), uid)
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_give_currency(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    /give_currency [user_id] [amount]
    Admins can give currency to any player — including themselves.
    Example: /give_currency 123456789 50g 20s
             /give_currency me 1p
    """
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    if len(args) < 2:
        await update.message.reply_text(
            "Usage: /give_currency [user_id|me] [amount]\n"
            "Example: /give_currency 123456 50g\n"
            "         /give_currency me 1p"
        )
        return

    target_id = uid if args[0].lower() == "me" else int(args[0])
    amount    = parse_currency(" ".join(args[1:]))
    svc       = AdminService(pool)
    msg       = await svc.give_currency(uid, target_id, amount)
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_take_currency(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    if len(args) < 2:
        await update.message.reply_text("Usage: /take_currency [user_id] [amount]")
        return
    amount = parse_currency(" ".join(args[1:]))
    svc    = AdminService(pool)
    msg    = await svc.take_currency(uid, int(args[0]), amount)
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_set_balance(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    if len(args) < 2:
        await update.message.reply_text("Usage: /set_balance [user_id] [amount]")
        return
    amount = parse_currency(" ".join(args[1:]))
    svc    = AdminService(pool)
    msg    = await svc.set_balance(uid, int(args[0]), amount)
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_set_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    /set_stats [user_id] str:15 dex:10 hp_max:500
    /set_stats [user_id] +str:5   ← additive
    """
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    if len(args) < 2:
        await update.message.reply_text(
            "Usage: /set_stats [user_id] stat:value ...\n"
            "Stats: str dex int vit wis luk hp_max mp_max\n"
            "Example: /set_stats 123456 str:20 hp_max:500\n"
            "Additive: /set_stats 123456 +str:5"
        )
        return
    target  = int(args[0])
    changes = parse_stat_args(args[1:])
    if not changes:
        await update.message.reply_text("❌ No valid stat changes parsed.")
        return
    svc = AdminService(pool)
    msg = await svc.set_stats(uid, target, changes)
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_server_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    svc  = AdminService(pool)
    # Middleware check
    admin_check = ctx.bot_data.get("admin_middleware")
    msg = await svc.server_stats()
    await update.message.reply_text(msg, parse_mode="Markdown")


# ─────────────────────────────────────────────
# ADMIN MONSTER CREATION (Multi-step Conversation)
# ─────────────────────────────────────────────

async def cmd_create_monster_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    """Entry point for /admin_create_monster conversation."""
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    svc  = AdminService(pool)
    _, is_super = await svc.middleware._get_user_status(uid)
    is_admin, _ = await svc.middleware._get_user_status(uid)

    if not is_admin:
        await update.message.reply_text("🚫 Admin only.")
        return ConversationHandler.END

    ctx.user_data["monster_draft"] = {}
    await update.message.reply_text(
        "🐉 **Create New Monster**\n\n"
        "Step 1/10: Enter the monster's **name**:",
        parse_mode="Markdown"
    )
    return MONSTER_NAME


async def monster_get_name(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    ctx.user_data["monster_draft"]["name"] = update.message.text.strip()
    await update.message.reply_text("Step 2/10: Enter a **description** (lore/flavour text):")
    return MONSTER_DESC

async def monster_get_desc(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    ctx.user_data["monster_draft"]["description"] = update.message.text.strip()
    await update.message.reply_text("Step 3/10: Which **zone** does it spawn in? (e.g. dark_forest):")
    return MONSTER_ZONE

async def monster_get_zone(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    ctx.user_data["monster_draft"]["zone"] = update.message.text.strip().lower().replace(" ","_")
    await update.message.reply_text("Step 4/10: Monster **level** (1–999):")
    return MONSTER_LEVEL

async def monster_get_level(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        ctx.user_data["monster_draft"]["level"] = int(update.message.text.strip())
    except ValueError:
        await update.message.reply_text("❌ Enter a number."); return MONSTER_LEVEL
    await update.message.reply_text("Step 5/10: Max **HP** (e.g. 1000):")
    return MONSTER_HP

async def monster_get_hp(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        ctx.user_data["monster_draft"]["hp"] = int(update.message.text.strip())
    except ValueError:
        await update.message.reply_text("❌ Enter a number."); return MONSTER_HP
    await update.message.reply_text("Step 6/10: **Attack** power (e.g. 80):")
    return MONSTER_ATK

async def monster_get_atk(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        ctx.user_data["monster_draft"]["atk"] = int(update.message.text.strip())
    except ValueError:
        await update.message.reply_text("❌ Enter a number."); return MONSTER_ATK
    await update.message.reply_text("Step 7/10: **Defense** value (e.g. 30):")
    return MONSTER_DEF

async def monster_get_def(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        ctx.user_data["monster_draft"]["def_"] = int(update.message.text.strip())
    except ValueError:
        await update.message.reply_text("❌ Enter a number."); return MONSTER_DEF
    await update.message.reply_text("Step 8/10: **Speed** (e.g. 50):")
    return MONSTER_SPD

async def monster_get_spd(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        ctx.user_data["monster_draft"]["spd"] = int(update.message.text.strip())
    except ValueError:
        await update.message.reply_text("❌ Enter a number."); return MONSTER_SPD
    await update.message.reply_text("Step 9/10: **XP reward** and **copper drop** (e.g. 500 100-300):")
    return MONSTER_XP

async def monster_get_xp_copper(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    parts = update.message.text.strip().split()
    try:
        ctx.user_data["monster_draft"]["xp"] = int(parts[0])
        copper_range = parts[1].split("-") if len(parts) > 1 else ["0", "0"]
        ctx.user_data["monster_draft"]["copper_min"] = int(copper_range[0])
        ctx.user_data["monster_draft"]["copper_max"] = int(copper_range[-1])
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Format: [xp] [min-max]. E.g: 500 100-300")
        return MONSTER_XP

    await update.message.reply_text(
        "Step 10/10: 📸 **Send a photo** for this monster, or type `skip` to use emoji only:",
        parse_mode="Markdown"
    )
    return MONSTER_PHOTO

async def monster_get_photo(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    draft = ctx.user_data["monster_draft"]

    if update.message.photo:
        # Largest available photo size
        photo: PhotoSize = update.message.photo[-1]
        draft["photo_file_id"] = photo.file_id
        await update.message.reply_text(f"📸 Photo captured! (ID: {photo.file_id[:16]}...)")
    else:
        draft["photo_file_id"] = None

    # Show summary and confirm
    await update.message.reply_text(
        f"✅ **Monster Summary**\n\n"
        f"🐉 Name: **{draft['name']}**\n"
        f"📍 Zone: {draft['zone']}\n"
        f"⚔️ LVL {draft['level']} | HP {draft['hp']} | ATK {draft['atk']} | DEF {draft['def_']}\n"
        f"💨 SPD {draft['spd']} | ✨ {draft['xp']}xp | 💰 {draft['copper_min']}–{draft['copper_max']}c\n"
        f"📸 Photo: {'Yes' if draft.get('photo_file_id') else 'No'}\n\n"
        f"Type **confirm** to create, or **cancel** to abort:",
        parse_mode="Markdown"
    )
    return MONSTER_CONFIRM

async def monster_confirm(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    pool  = ctx.bot_data["pool"]
    uid   = update.effective_user.id
    text  = update.message.text.strip().lower()

    if text == "cancel":
        ctx.user_data.pop("monster_draft", None)
        await update.message.reply_text("❌ Monster creation cancelled.")
        return ConversationHandler.END

    if text != "confirm":
        await update.message.reply_text("Type 'confirm' or 'cancel'.")
        return MONSTER_CONFIRM

    draft = ctx.user_data["monster_draft"]
    svc   = AdminService(pool)

    msg, monster_id = await svc.create_monster(
        admin_id=uid,
        name=draft["name"],
        description=draft.get("description", ""),
        zone=draft["zone"],
        level=draft["level"],
        hp=draft["hp"],
        atk=draft["atk"],
        def_=draft["def_"],
        spd=draft["spd"],
        xp=draft["xp"],
        copper_min=draft["copper_min"],
        copper_max=draft["copper_max"],
        photo_file_id=draft.get("photo_file_id"),
    )

    # If photo was uploaded, send it back with the card
    if draft.get("photo_file_id"):
        await update.message.reply_photo(
            photo=draft["photo_file_id"],
            caption=msg,
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(msg, parse_mode="Markdown")

    ctx.user_data.pop("monster_draft", None)
    return ConversationHandler.END


async def monster_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> int:
    ctx.user_data.pop("monster_draft", None)
    await update.message.reply_text("❌ Cancelled.")
    return ConversationHandler.END


# ─────────────────────────────────────────────
# GUILD COMMANDS
# ─────────────────────────────────────────────

async def cmd_guild(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    svc  = GuildService(pool)

    if not args:
        await update.message.reply_text(
            "🏰 **Guild Commands**\n"
            "/guild create [name] [TAG] — Create a guild (50g)\n"
            "/guild info               — View your guild\n"
            "/guild deposit [amount]   — Deposit to vault\n"
            "/guild withdraw [amount]  — Withdraw from vault (officer+)"
        )
        return

    action = args[0].lower()
    if action == "create" and len(args) >= 3:
        msg = await svc.create(uid, args[1], args[2])
    elif action == "deposit" and len(args) >= 2:
        amount = parse_currency(" ".join(args[1:]))
        msg = await svc.deposit_vault(uid, amount)
    elif action == "withdraw" and len(args) >= 2:
        amount = parse_currency(" ".join(args[1:]))
        msg = await svc.withdraw_vault(uid, amount)
    elif action == "info":
        async with pool.acquire() as conn:
            guild_id = await conn.fetchval("SELECT guild_id FROM users WHERE id=$1", uid)
        msg = await svc.guild_info(guild_id) if guild_id else "❌ You're not in a guild."
    else:
        msg = "❌ Unknown guild command."

    await update.message.reply_text(msg, parse_mode="Markdown")


# ─────────────────────────────────────────────
# CRAFT COMMANDS
# ─────────────────────────────────────────────

async def cmd_craft(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    pool = ctx.bot_data["pool"]
    uid  = update.effective_user.id
    args = ctx.args
    svc  = CraftingService(pool)

    user = await Services.users.get(uid)
    if not user:
        await update.message.reply_text("❌ Character not found.")
        return

    if not args or args[0].lower() == "list":
        msg = await svc.get_recipes(uid, user.level)
        await update.message.reply_text(msg, parse_mode="Markdown")
        return

    try:
        recipe_id = int(args[0])
    except ValueError:
        await update.message.reply_text("Usage: /craft [recipe_id] | /craft list")
        return

    msg = await svc.craft(uid, recipe_id, user.race)
    bar = await status_bar(uid, pool)
    await update.message.reply_text(msg + bar, parse_mode="Markdown")


# ─────────────────────────────────────────────
# BOT MAIN
# ─────────────────────────────────────────────

def build_application() -> Application:
    app = Application.builder().token(BOT_TOKEN).build()

    # Monster creation conversation
    monster_conv = ConversationHandler(
        entry_points=[CommandHandler("admin_create_monster", cmd_create_monster_start)],
        states={
            MONSTER_NAME:    [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_name)],
            MONSTER_DESC:    [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_desc)],
            MONSTER_ZONE:    [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_zone)],
            MONSTER_LEVEL:   [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_level)],
            MONSTER_HP:      [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_hp)],
            MONSTER_ATK:     [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_atk)],
            MONSTER_DEF:     [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_def)],
            MONSTER_SPD:     [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_spd)],
            MONSTER_XP:      [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_xp_copper)],
            MONSTER_PHOTO:   [
                MessageHandler(filters.PHOTO, monster_get_photo),
                MessageHandler(filters.TEXT & ~filters.COMMAND, monster_get_photo),
            ],
            MONSTER_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, monster_confirm)],
        },
        fallbacks=[CommandHandler("cancel", monster_cancel)],
    )

    # Register all handlers
    app.add_handler(monster_conv)
    app.add_handler(CommandHandler("start",              cmd_start))
    app.add_handler(CommandHandler("create",             cmd_create))
    app.add_handler(CommandHandler("profile",            cmd_profile))
    app.add_handler(CommandHandler("inventory",          cmd_inventory))
    app.add_handler(CommandHandler("bank",               cmd_bank))
    app.add_handler(CommandHandler("market",             cmd_market))
    app.add_handler(CommandHandler("merchant",           cmd_merchant))
    app.add_handler(CommandHandler(["bm","blackmarket"], cmd_blackmarket))
    app.add_handler(CommandHandler("guild",              cmd_guild))
    app.add_handler(CommandHandler("craft",              cmd_craft))
    # Admin
    app.add_handler(CommandHandler("ban",                cmd_ban))
    app.add_handler(CommandHandler("unban",              cmd_unban))
    app.add_handler(CommandHandler("give_item",          cmd_give_item))
    app.add_handler(CommandHandler("give_currency",      cmd_give_currency))
    app.add_handler(CommandHandler("take_currency",      cmd_take_currency))
    app.add_handler(CommandHandler("set_balance",        cmd_set_balance))
    app.add_handler(CommandHandler("set_stats",          cmd_set_stats))
    app.add_handler(CommandHandler("server_stats",       cmd_server_stats))

    return app


async def main():
    pool = await get_pool()
    await Services.init()

    app = build_application()
    app.bot_data["pool"] = pool

    log.info("Chronicle Legends Bot starting...")
    await app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    asyncio.run(main())

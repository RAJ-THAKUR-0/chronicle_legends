"""
admin.py — Chronicle Legends MMORPG Bot
SuperUser Middleware & Admin Command Suite

Admin Powers:
  /ban /unban              — Player moderation
  /give_item               — Grant items to any player
  /give_currency           — Give currency to any player (or yourself)
  /take_currency           — Remove currency from any player
  /set_balance             — Set exact wallet balance
  /set_stats               — Change any player's stats (STR, DEX, etc.)
  /set_level               — Set player level directly
  /admin_create_monster    — Create monster with photo upload
  /admin_edit_monster      — Edit existing monster stats
  /admin_toggle_monster    — Enable/disable a monster
  /server_stats            — Economy & player analytics dashboard
  /broadcast               — Send announcement to all players
  /spawn_boss              — Force-spawn a boss raid
  /admin_market            — Seed black market with items
  /reset_player            — Full character wipe (with confirm)
"""

from __future__ import annotations
import asyncpg
import logging
import json
from functools import wraps
from typing import Optional, Callable, Any
from dataclasses import dataclass

from economy import Currency, format_currency, parse_currency, render_status_bar
from combat import MonsterDefinition

log = logging.getLogger("admin")


# ─────────────────────────────────────────────
# SUPERUSER MIDDLEWARE
# ─────────────────────────────────────────────

class SuperUserMiddleware:
    """
    Decorator factory for admin-gating bot command handlers.

    Usage:
        @admin.require_admin
        async def ban_command(user_id, target_id, reason):
            ...

        @admin.require_superadmin
        async def reset_player(user_id, target_id):
            ...
    """

    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool

    async def _get_user_status(self, user_id: int) -> tuple[bool, bool]:
        """Returns (is_admin, is_superadmin)."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT is_admin, is_superadmin FROM users WHERE id = $1", user_id
            )
        if not row:
            return False, False
        return row["is_admin"] or row["is_superadmin"], row["is_superadmin"]

    def require_admin(self, fn: Callable) -> Callable:
        @wraps(fn)
        async def wrapper(user_id: int, *args, **kwargs):
            is_admin, _ = await self._get_user_status(user_id)
            if not is_admin:
                return "🚫 **Access Denied** — Admin privileges required."
            return await fn(user_id, *args, **kwargs)
        return wrapper

    def require_superadmin(self, fn: Callable) -> Callable:
        @wraps(fn)
        async def wrapper(user_id: int, *args, **kwargs):
            _, is_super = await self._get_user_status(user_id)
            if not is_super:
                return "🚫 **Access Denied** — SuperAdmin privileges required."
            return await fn(user_id, *args, **kwargs)
        return wrapper


# ─────────────────────────────────────────────
# ADMIN SERVICE
# ─────────────────────────────────────────────

class AdminService:
    """
    All admin command implementations.
    All methods are async and return a formatted string response.
    """

    VALID_STATS = {"str", "dex", "int", "vit", "wis", "luk",
                   "hp_max", "mp_max", "hp_current", "mp_current"}

    def __init__(self, pool: asyncpg.Pool):
        self._pool = pool
        self.middleware = SuperUserMiddleware(pool)

    # ── Player Moderation ────────────────────────

    async def ban(
        self, admin_id: int, target_id: int,
        reason: str = "No reason given", duration_days: Optional[int] = None
    ) -> str:
        from database import UserRepository
        repo = UserRepository(self._pool)
        await repo.ban(target_id, admin_id, reason)
        user = await repo.get(target_id)
        name = user.display_name if user else f"#{target_id}"
        dur  = f"{duration_days}d" if duration_days else "Permanent"
        log.warning(f"ADMIN {admin_id} banned {target_id}: {reason}")
        return (
            f"🔨 **Player Banned**\n"
            f"👤 {name} (`{target_id}`)\n"
            f"📋 Reason: {reason}\n"
            f"⏳ Duration: {dur}"
        )

    async def unban(self, admin_id: int, target_id: int) -> str:
        from database import UserRepository
        repo = UserRepository(self._pool)
        await repo.unban(target_id, admin_id)
        return f"✅ Player `{target_id}` has been unbanned."

    # ── Currency Control ─────────────────────────

    async def give_currency(
        self, admin_id: int, target_id: int, amount: Currency, note: str = "Admin grant"
    ) -> str:
        """
        Admin gives currency to any player (including themselves).
        Creates new copper — inflationary by design, use carefully.
        """
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                target = await conn.fetchrow(
                    "SELECT display_name, wallet_copper FROM users WHERE id = $1", target_id
                )
                if not target:
                    return f"❌ User `{target_id}` not found."

                await conn.execute(
                    "UPDATE users SET wallet_copper = wallet_copper + $1 WHERE id = $2",
                    amount.copper, target_id
                )
                new_bal = Currency.from_copper(target["wallet_copper"] + amount.copper)

                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, to_user_id, amount_copper, description)
                       VALUES ('admin_grant', $1, $2, $3, $4)""",
                    admin_id, target_id, amount.copper,
                    f"Admin grant: {note}"
                )

        log.info(f"ADMIN {admin_id} gave {amount.format()} to {target_id}")
        return (
            f"💰 **Currency Granted**\n"
            f"👤 {target['display_name']} (`{target_id}`)\n"
            f"➕ Added: **{amount.format()}**\n"
            f"💼 New Balance: {new_bal.format()}\n"
            f"📋 Note: {note}"
        )

    async def take_currency(
        self, admin_id: int, target_id: int, amount: Currency, note: str = "Admin deduct"
    ) -> str:
        """Remove currency from a player's wallet."""
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                target = await conn.fetchrow(
                    "SELECT display_name, wallet_copper FROM users WHERE id = $1 FOR UPDATE",
                    target_id
                )
                if not target:
                    return f"❌ User `{target_id}` not found."

                actual_deduct = min(amount.copper, target["wallet_copper"])
                await conn.execute(
                    "UPDATE users SET wallet_copper = wallet_copper - $1 WHERE id = $2",
                    actual_deduct, target_id
                )
                remaining = Currency.from_copper(target["wallet_copper"] - actual_deduct)

                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, to_user_id, amount_copper, description)
                       VALUES ('admin_grant', $1, $2, $3, $4)""",
                    target_id, admin_id, actual_deduct, f"Admin deduct: {note}"
                )

        return (
            f"💸 **Currency Deducted**\n"
            f"👤 {target['display_name']} — Took: **{format_currency(actual_deduct)}**\n"
            f"💼 Remaining: {remaining.format()}"
        )

    async def set_balance(
        self, admin_id: int, target_id: int, amount: Currency
    ) -> str:
        """Set a player's wallet to an exact amount."""
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                target = await conn.fetchrow(
                    "SELECT display_name FROM users WHERE id = $1", target_id
                )
                if not target:
                    return f"❌ User `{target_id}` not found."

                old_bal = await conn.fetchval(
                    "SELECT wallet_copper FROM users WHERE id = $1", target_id
                )
                await conn.execute(
                    "UPDATE users SET wallet_copper = $1 WHERE id = $2",
                    amount.copper, target_id
                )
                await conn.execute(
                    """INSERT INTO transactions
                       (tx_type, from_user_id, to_user_id, amount_copper, description)
                       VALUES ('admin_grant', $1, $2, $3, 'Admin set_balance')""",
                    admin_id, target_id, amount.copper
                )

        return (
            f"⚙️ **Balance Set**\n"
            f"👤 {target['display_name']}\n"
            f"Before: {format_currency(old_bal)}  →  After: **{amount.format()}**"
        )

    # ── Stat Control ─────────────────────────────

    async def set_stats(
        self, admin_id: int, target_id: int, stat_changes: dict[str, int]
    ) -> str:
        """
        Set or add stats for a player.
        stat_changes = {"str": 15, "dex": 10}  → sets absolute values
        Prefix with + to add: {"+str": 5}        → adds 5 to current STR

        Command: /set_stats [user_id] str:15 dex:10 hp_max:500
        """
        invalid = [k.lstrip("+") for k in stat_changes if k.lstrip("+") not in self.VALID_STATS]
        if invalid:
            return f"❌ Invalid stats: {', '.join(invalid)}\nValid: {', '.join(self.VALID_STATS)}"

        async with self._pool.acquire() as conn:
            target = await conn.fetchrow(
                "SELECT display_name FROM users WHERE id = $1", target_id
            )
            if not target:
                return f"❌ User `{target_id}` not found."

            # Build dynamic UPDATE SET clause
            set_parts = []
            values    = []
            idx       = 1
            for raw_key, value in stat_changes.items():
                additive = raw_key.startswith("+")
                col      = raw_key.lstrip("+")
                db_col   = f"stat_{col}" if col in {"str","dex","int","vit","wis","luk"} else col
                if additive:
                    set_parts.append(f"{db_col} = {db_col} + ${idx}")
                else:
                    set_parts.append(f"{db_col} = ${idx}")
                values.append(value)
                idx += 1

            values.append(target_id)
            await conn.execute(
                f"UPDATE users SET {', '.join(set_parts)} WHERE id = ${idx}",
                *values
            )

        changes_str = "  ".join(
            f"{'+'if k.startswith('+') else ''}{k.lstrip('+')}={v}"
            for k, v in stat_changes.items()
        )
        log.info(f"ADMIN {admin_id} set stats for {target_id}: {stat_changes}")
        return (
            f"📊 **Stats Updated**\n"
            f"👤 {target['display_name']} (`{target_id}`)\n"
            f"Changes: `{changes_str}`"
        )

    async def set_level(self, admin_id: int, target_id: int, level: int) -> str:
        if not 1 <= level <= 999:
            return "❌ Level must be between 1 and 999."
        async with self._pool.acquire() as conn:
            target = await conn.fetchrow(
                "SELECT display_name FROM users WHERE id = $1", target_id
            )
            if not target:
                return f"❌ User `{target_id}` not found."
            await conn.execute(
                "UPDATE users SET level = $1 WHERE id = $2", level, target_id
            )
        return f"⬆️ {target['display_name']} set to **Level {level}**."

    # ── Monster Creation ─────────────────────────

    async def create_monster(
        self,
        admin_id: int,
        name: str,
        description: str,
        zone: str,
        level: int,
        hp: int,
        atk: int,
        def_: int,
        spd: int,
        xp: int,
        copper_min: int,
        copper_max: int,
        icon_emoji: str = "👾",
        photo_file_id: Optional[str] = None,
        magic_res: float = 0.0,
        phys_res: float = 0.0,
        is_boss: bool = False,
        abilities: list = None,
        loot_table: list = None,
    ) -> tuple[str, int]:
        """
        Admin creates a new monster. Supports Telegram photo upload.
        Returns (message, monster_id).

        Telegram bot handler should:
          1. Ask admin to send a photo
          2. Capture photo.file_id
          3. Pass as photo_file_id here

        Command flow: /admin_create_monster → bot prompts for details as form
        """
        abilities  = abilities or []
        loot_table = loot_table or []

        async with self._pool.acquire() as conn:
            # Ensure monster_definitions table exists (same as boss_definitions but general)
            monster_id = await conn.fetchval(
                """
                INSERT INTO monster_definitions
                  (name, description, icon_emoji, photo_file_id, zone, level,
                   hp_max, atk, def, spd, xp_reward, copper_min, copper_max,
                   magic_res, phys_res, is_boss, abilities, loot_table, created_by)
                VALUES
                  ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
                RETURNING id
                """,
                name, description, icon_emoji, photo_file_id, zone, level,
                hp, atk, def_, spd, xp, copper_min, copper_max,
                magic_res, phys_res, is_boss,
                json.dumps(abilities), json.dumps(loot_table), admin_id
            )

        boss_flag = " 👑 [BOSS]" if is_boss else ""
        photo_flag = " 📸 [Photo attached]" if photo_file_id else ""
        log.info(f"ADMIN {admin_id} created monster #{monster_id}: {name}")

        return (
            f"✅ **Monster Created!**{boss_flag}{photo_flag}\n"
            f"🆔 ID: #{monster_id}\n"
            f"{'👾' if not is_boss else '👑'} **{name}**  |  Zone: {zone}\n"
            f"❤️ HP: {hp:,}  ⚔️ ATK: {atk}  🛡️ DEF: {def_}  💨 SPD: {spd}\n"
            f"✨ XP: {xp:,}  💰 {copper_min}–{copper_max}c\n"
            f"🔥 Magic Res: {int(magic_res*100)}%  🗡️ Phys Res: {int(phys_res*100)}%\n"
            f"\n_Monster is now available for spawning in {zone}_"
        ), monster_id

    async def edit_monster(
        self, admin_id: int, monster_id: int, changes: dict
    ) -> str:
        """Edit any field of an existing monster. changes = {"hp_max": 5000, "atk": 200}"""
        ALLOWED = {"name","description","zone","level","hp_max","atk","def",
                   "spd","xp_reward","copper_min","copper_max","magic_res",
                   "phys_res","is_boss","icon_emoji","is_active"}
        invalid = [k for k in changes if k not in ALLOWED]
        if invalid:
            return f"❌ Cannot edit: {', '.join(invalid)}"

        set_parts = []
        values    = []
        for i, (k, v) in enumerate(changes.items(), 1):
            set_parts.append(f"{k} = ${i}")
            values.append(v)
        values.append(monster_id)

        async with self._pool.acquire() as conn:
            r = await conn.execute(
                f"UPDATE monster_definitions SET {', '.join(set_parts)} WHERE id = ${len(values)}",
                *values
            )
        if r == "UPDATE 0":
            return f"❌ Monster #{monster_id} not found."

        changes_str = "  ".join(f"{k}={v}" for k, v in changes.items())
        return f"✅ Monster #{monster_id} updated: `{changes_str}`"

    async def toggle_monster(self, admin_id: int, monster_id: int) -> str:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT name, is_active FROM monster_definitions WHERE id = $1", monster_id
            )
            if not row:
                return f"❌ Monster #{monster_id} not found."
            new_state = not row["is_active"]
            await conn.execute(
                "UPDATE monster_definitions SET is_active = $1 WHERE id = $2",
                new_state, monster_id
            )
        state_str = "✅ Enabled" if new_state else "❌ Disabled"
        return f"{state_str}: **{row['name']}** (#{monster_id})"

    # ── Economy Dashboard ────────────────────────

    async def server_stats(self) -> str:
        async with self._pool.acquire() as conn:
            econ = await conn.fetchrow("SELECT * FROM v_economy_stats")
            active_24h = await conn.fetchval(
                "SELECT COUNT(*) FROM users WHERE last_active > NOW() - INTERVAL '24 hours'"
            )
            active_1h = await conn.fetchval(
                "SELECT COUNT(*) FROM users WHERE last_active > NOW() - INTERVAL '1 hour'"
            )
            total_users = await conn.fetchval("SELECT COUNT(*) FROM users WHERE status = 'active'")
            bans = await conn.fetchval("SELECT COUNT(*) FROM users WHERE status = 'banned'")
            market_today = await conn.fetchrow(
                """SELECT COUNT(*) AS sales, COALESCE(SUM(price_copper * quantity),0) AS vol
                   FROM market_listings WHERE status='sold' AND sold_at > NOW()-INTERVAL '24h'"""
            )
            top_rich = await conn.fetch(
                """SELECT display_name, wallet_copper + bank_copper AS wealth
                   FROM users WHERE status='active'
                   ORDER BY wealth DESC LIMIT 5"""
            )
            raids_today = await conn.fetchval(
                "SELECT COUNT(*) FROM boss_raids WHERE spawned_at > NOW()-INTERVAL '24h'"
            )

        top_str = "\n".join(
            f"  {i+1}. {r['display_name']} — {format_currency(r['wealth'])}"
            for i, r in enumerate(top_rich)
        )

        total_supply = econ["total_supply"] or 0
        return (
            f"📊 **SERVER STATISTICS**\n"
            f"{'═'*32}\n"
            f"👥 **Players**\n"
            f"  Total: {total_users:,}  |  Banned: {bans:,}\n"
            f"  Active (1h): {active_1h:,}  |  Active (24h): {active_24h:,}\n"
            f"\n💰 **Economy**\n"
            f"  Total Supply: {format_currency(total_supply)}\n"
            f"  In Wallets:   {format_currency(econ['total_in_wallets'] or 0)}\n"
            f"  In Banks:     {format_currency(econ['total_in_banks'] or 0)}\n"
            f"  Avg Wealth:   {format_currency(int(econ['avg_wealth'] or 0))}\n"
            f"\n🏪 **Market (24h)**\n"
            f"  Sales: {market_today['sales']:,}  |  Volume: {format_currency(market_today['vol'])}\n"
            f"\n⚔️ **Boss Raids Today:** {raids_today}\n"
            f"\n🏆 **Richest Players**\n{top_str}"
        )

    # ── Black Market Seeding ─────────────────────

    async def seed_black_market(
        self, admin_id: int, item_def_id: int, enable: bool = True
    ) -> str:
        """Toggle an item's availability on the black market."""
        async with self._pool.acquire() as conn:
            item = await conn.fetchrow(
                "SELECT name FROM item_definitions WHERE id = $1", item_def_id
            )
            if not item:
                return f"❌ Item #{item_def_id} not found."
            await conn.execute(
                """UPDATE item_definitions
                   SET extra_data = jsonb_set(extra_data, '{black_market_available}', $1::jsonb)
                   WHERE id = $2""",
                json.dumps(enable), item_def_id
            )
        state = "listed on" if enable else "removed from"
        return f"🌑 **{item['name']}** is now {state} the Black Market."

    # ── Broadcast ────────────────────────────────

    async def get_all_active_user_ids(self) -> list[int]:
        """Used by bot.py to broadcast a message to all players."""
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT id FROM users WHERE status = 'active' AND last_active > NOW() - INTERVAL '30 days'"
            )
        return [r["id"] for r in rows]

    # ── Reset Player ─────────────────────────────

    async def reset_player(self, admin_id: int, target_id: int, confirm: bool = False) -> str:
        if not confirm:
            return (
                f"⚠️ **CONFIRM RESET**\n"
                f"This will wipe ALL data for user `{target_id}`:\n"
                f"• Stats, level, XP reset to defaults\n"
                f"• Wallet cleared (bank preserved)\n"
                f"• Inventory deleted\n\n"
                f"Run `/reset_player {target_id} confirm` to proceed."
            )

        async with self._pool.acquire() as conn:
            async with conn.transaction():
                target = await conn.fetchrow(
                    "SELECT display_name FROM users WHERE id = $1", target_id
                )
                if not target:
                    return f"❌ User `{target_id}` not found."

                await conn.execute("DELETE FROM inventory_items WHERE owner_id = $1", target_id)
                await conn.execute(
                    """UPDATE users SET
                         level=1, experience=0, experience_next=100,
                         stat_str=10, stat_dex=10, stat_int=10,
                         stat_vit=10, stat_wis=10, stat_luk=10,
                         stat_points=0, hp_current=100, hp_max=100,
                         mp_current=50, mp_max=50, wallet_copper=0,
                         deaths=0, kills=0, current_zone='town_square'
                       WHERE id = $1""",
                    target_id
                )

        log.warning(f"ADMIN {admin_id} RESET player {target_id}")
        return f"♻️ Player **{target['display_name']}** (`{target_id}`) has been fully reset."


# ─────────────────────────────────────────────
# ADMIN COMMAND PARSER
# ─────────────────────────────────────────────

def parse_stat_args(args: list[str]) -> dict[str, int]:
    """
    Parse 'str:15 +dex:5 hp_max:500' into {"str": 15, "+dex": 5, "hp_max": 500}
    """
    result = {}
    for arg in args:
        if ":" in arg:
            k, v = arg.split(":", 1)
            try:
                result[k.strip()] = int(v.strip())
            except ValueError:
                pass
    return result

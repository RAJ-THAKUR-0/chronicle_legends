#!/usr/bin/env bash
# =============================================================
# scripts/init_db.sh — Chronicle Legends Database Initializer
#
# Supports:
#   ✅ Supabase (recommended — free cloud database)
#   ✅ Local PostgreSQL
#   ✅ Any PostgreSQL-compatible cloud DB (Neon, Railway, etc.)
#
# Usage:
#   chmod +x scripts/init_db.sh
#   ./scripts/init_db.sh
# =============================================================

set -e

# ── Colors ────────────────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m' # No Color

print_header() {
  echo ""
  echo -e "${BOLD}${BLUE}╔══════════════════════════════════════════════╗${NC}"
  echo -e "${BOLD}${BLUE}║     Chronicle Legends — DB Setup Wizard      ║${NC}"
  echo -e "${BOLD}${BLUE}╚══════════════════════════════════════════════╝${NC}"
  echo ""
}

print_step() { echo -e "\n${BOLD}${GREEN}▶ $1${NC}"; }
print_info() { echo -e "  ${BLUE}$1${NC}"; }
print_warn() { echo -e "  ${YELLOW}⚠️  $1${NC}"; }
print_ok()   { echo -e "  ${GREEN}✅ $1${NC}"; }
print_err()  { echo -e "  ${RED}❌ $1${NC}"; }

print_header

# ── Load .env ─────────────────────────────────────────────────
print_step "Loading configuration"

if [ ! -f ".env" ]; then
  print_err ".env file not found in project root!"
  echo ""
  echo "  Run this first:"
  echo "    cp config/.env.example .env"
  echo "    nano .env   (fill in your BOT_TOKEN and DATABASE_URL)"
  echo ""
  exit 1
fi

export $(grep -v '^#' .env | grep -v '^$' | xargs)
print_ok "Loaded .env"

# ── Validate critical env vars ────────────────────────────────
if [ -z "$DATABASE_URL" ]; then
  print_err "DATABASE_URL is not set in .env!"
  exit 1
fi

if [[ "$DATABASE_URL" == *"YOUR-PASSWORD"* ]] || [[ "$DATABASE_URL" == *"xxxxxxxxxxxx"* ]]; then
  print_err "DATABASE_URL still has placeholder values!"
  echo ""
  echo "  For Supabase:"
  echo "  1. Go to https://supabase.com → your project"
  echo "  2. Settings → Database → Connection string → URI tab"
  echo "  3. Copy it, replace [YOUR-PASSWORD], paste in .env"
  echo ""
  exit 1
fi

# ── Detect database type ──────────────────────────────────────
print_step "Detecting database type"

IS_SUPABASE=false
IS_NEON=false
IS_LOCAL=false

if [[ "$DATABASE_URL" == *"supabase.co"* ]]; then
  IS_SUPABASE=true
  print_ok "Supabase detected ☁️"
elif [[ "$DATABASE_URL" == *"neon.tech"* ]]; then
  IS_NEON=true
  print_ok "Neon.tech detected ☁️"
elif [[ "$DATABASE_URL" == *"localhost"* ]] || [[ "$DATABASE_URL" == *"127.0.0.1"* ]]; then
  IS_LOCAL=true
  print_ok "Local PostgreSQL detected 🖥️"
else
  print_ok "Cloud PostgreSQL detected ☁️"
fi

# ── Parse connection details ──────────────────────────────────
# Format: postgresql://user:pass@host:port/dbname
DB_USER=$(echo "$DATABASE_URL" | sed -n 's|.*://\([^:]*\):.*|\1|p')
DB_HOST=$(echo "$DATABASE_URL" | sed -n 's|.*@\([^:/]*\).*|\1|p')
DB_PORT=$(echo "$DATABASE_URL" | sed -n 's|.*:\([0-9]*\)/.*|\1|p')
DB_NAME=$(echo "$DATABASE_URL" | sed -n 's|.*/\([^?]*\)|\1|p')
DB_PASS=$(echo "$DATABASE_URL" | sed -n 's|.*://[^:]*:\([^@]*\)@.*|\1|p')

print_info "Host:     $DB_HOST:$DB_PORT"
print_info "Database: $DB_NAME"
print_info "User:     $DB_USER"

# ── Build psql connection string ──────────────────────────────
PSQL_BASE="PGPASSWORD=$DB_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME"

# Add SSL flags for cloud databases
PSQL_SSL=""
if [ "$IS_LOCAL" = false ]; then
  PSQL_SSL="sslmode=require"
  export PGSSLMODE=require
fi

# ── Check psql is installed ───────────────────────────────────
print_step "Checking prerequisites"

if ! command -v psql &> /dev/null; then
  print_err "psql (PostgreSQL client) is not installed!"
  echo ""
  if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "  Install on Mac:    brew install postgresql"
  elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "  Install on Linux:  sudo apt install postgresql-client"
  else
    echo "  Install from:      https://www.postgresql.org/download/"
  fi
  echo ""
  echo "  💡 On Supabase: you can also run migrations directly in the"
  echo "     Supabase Dashboard → SQL Editor → paste the .sql files"
  exit 1
fi

print_ok "psql found: $(psql --version | head -1)"

# ── Test connection ───────────────────────────────────────────
print_step "Testing database connection"

if PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
   -c "SELECT 1;" > /dev/null 2>&1; then
  print_ok "Connected successfully!"
else
  print_err "Cannot connect to database!"
  echo ""
  if [ "$IS_SUPABASE" = true ]; then
    echo "  Supabase troubleshooting:"
    echo "  1. Check your password is correct in DATABASE_URL"
    echo "  2. Go to Supabase Dashboard → Settings → Database"
    echo "  3. Make sure your IP is not blocked (Settings → Auth)"
    echo "  4. Try the connection string from the dashboard directly"
  else
    echo "  Check that PostgreSQL is running and your credentials are correct."
  fi
  echo ""
  exit 1
fi

# ── Run migrations ────────────────────────────────────────────
print_step "Running database migrations"

MIGRATION_COUNT=0
for migration in database/migrations/*.sql; do
  if [ -f "$migration" ]; then
    filename=$(basename "$migration")
    echo -n "  → $filename ... "
    if PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
       -f "$migration" > /tmp/migration_out.txt 2>&1; then
      echo -e "${GREEN}done${NC}"
      MIGRATION_COUNT=$((MIGRATION_COUNT + 1))
    else
      echo -e "${RED}FAILED${NC}"
      echo ""
      print_err "Migration failed: $filename"
      cat /tmp/migration_out.txt
      echo ""
      echo "  💡 If error says 'already exists', the migration was already run."
      echo "     This is safe to ignore — re-running migrations won't break data."
      echo ""
      read -p "  Continue anyway? [y/N] " cont
      [[ "$cont" =~ ^[Yy]$ ]] || exit 1
    fi
  fi
done

print_ok "$MIGRATION_COUNT migration(s) applied."

# ── Seed data ─────────────────────────────────────────────────
print_step "Starter data"

echo ""
echo "  Do you want to load starter items, bosses, and recipes?"
echo "  (Recommended for new setups. Safe to skip if re-initializing.)"
echo ""
read -p "  Seed starter data? [y/N] " seed_confirm

if [[ "$seed_confirm" =~ ^[Yy]$ ]]; then
  SEED_COUNT=0
  for seed in database/seeds/*.sql; do
    if [ -f "$seed" ]; then
      filename=$(basename "$seed")
      echo -n "  → $filename ... "
      if PGPASSWORD="$DB_PASS" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
         -f "$seed" > /tmp/seed_out.txt 2>&1; then
        echo -e "${GREEN}done${NC}"
        SEED_COUNT=$((SEED_COUNT + 1))
      else
        echo -e "${YELLOW}skipped (may already exist)${NC}"
      fi
    fi
  done
  print_ok "$SEED_COUNT seed file(s) applied."
else
  print_info "Skipped seeding."
fi

# ── Supabase-specific tips ────────────────────────────────────
if [ "$IS_SUPABASE" = true ]; then
  echo ""
  echo -e "  ${BLUE}💡 Supabase Tips:${NC}"
  echo "  • View your data: Supabase Dashboard → Table Editor"
  echo "  • Run custom SQL: Supabase Dashboard → SQL Editor"
  echo "  • Your DB auto-backs up daily on the free plan"
  echo "  • Free projects pause after 1 week of inactivity"
  echo "    → Upgrade to Pro ($25/mo) to disable auto-pause"
  echo "    → Or ping it weekly with a cron job to keep it alive"
fi

# ── Done ──────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${GREEN}║       ✅  Database setup complete!            ║${NC}"
echo -e "${BOLD}${GREEN}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo "  Next steps:"
echo "  1. Make sure BOT_TOKEN is set in .env"
echo "  2. Make sure SUPERADMIN_IDS is set in .env (your Telegram user ID)"
echo "  3. Run the bot:"
echo ""
echo -e "     ${BOLD}./scripts/run.sh${NC}"
echo "     or: python src/bot/bot.py"
echo ""

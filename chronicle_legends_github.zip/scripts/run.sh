#!/usr/bin/env bash
# =============================================================
# scripts/run.sh — Chronicle Legends Bot Launcher
# =============================================================

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "${BOLD}${GREEN}"
echo "  ⚔️  Chronicle Legends — Starting Bot"
echo -e "${NC}"

# ── Load .env ─────────────────────────────────────────────────
if [ -f ".env" ]; then
  export $(grep -v '^#' .env | grep -v '^$' | xargs)
  echo -e "  ${GREEN}✅ Loaded .env${NC}"
else
  echo -e "  ${RED}❌ No .env file found!${NC}"
  echo "     Run: cp config/.env.example .env"
  echo "     Then fill in BOT_TOKEN and DATABASE_URL"
  exit 1
fi

# ── Quick validation ──────────────────────────────────────────
if [ -z "$BOT_TOKEN" ] || [ "$BOT_TOKEN" = "your_telegram_bot_token_here" ]; then
  echo -e "  ${RED}❌ BOT_TOKEN is not set in .env!${NC}"
  echo "     Get a token from @BotFather on Telegram"
  exit 1
fi

if [[ "$DATABASE_URL" == *"YOUR-PASSWORD"* ]] || [[ "$DATABASE_URL" == *"xxxxxxxxxxxx"* ]]; then
  echo -e "  ${RED}❌ DATABASE_URL still has placeholder values in .env!${NC}"
  echo "     Copy your real Supabase connection string from:"
  echo "     supabase.com → your project → Settings → Database → URI"
  exit 1
fi

# ── Activate virtualenv if present ───────────────────────────
if [ -d "venv" ]; then
  source venv/bin/activate
  echo -e "  ${GREEN}✅ Virtual environment activated${NC}"
fi

# ── Launch ────────────────────────────────────────────────────
echo -e "  ${GREEN}✅ Connecting to database...${NC}"
echo ""
echo -e "  ${BOLD}Bot is starting. Send /start to your bot on Telegram.${NC}"
echo -e "  Press Ctrl+C to stop."
echo ""

python src/bot/bot.py
